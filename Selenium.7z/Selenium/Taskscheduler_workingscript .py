import subprocess
import time
import os
import json
from datetime import datetime

# === Configuration ===
ReleaseFolderVersion = '1.1.101.18'
ReleaseFolderName = f"SPCAutomationCombined_{ReleaseFolderVersion}"
SourcePath = f"\\\\vboxsvr\\winshare\\{ReleaseFolderName}"
DestinationPath = f"C:\\DatalyzerIntermediate_Release\\{ReleaseFolderName}"
IISPath = f"{DestinationPath}\\SPCBackend_{ReleaseFolderVersion}"
IISSiteName = "Automation_SPC"
JsonFilePath = os.path.join(DestinationPath, f"SPCBackend_{ReleaseFolderVersion}", "QualisSPC.json")
LogDir = r"C:\Taskscheduler script\Error_Log"
link = "https://spcautomation.qualis40.io/login"
file_path = f"C:\\DatalyzerIntermediate_Release\\SPCAutomationCombined_{ReleaseFolderVersion}\\SPCBackend_{ReleaseFolderVersion}\\AutomationSpc\\src\\test\\resources\\config\\config.properties"
cmd_script_path = f"C:\\DatalyzerIntermediate_Release\\SPCAutomationCombined_{ReleaseFolderVersion}\\SPCBackend_{ReleaseFolderVersion}\\AutomationSpc\\update_config.cmd"


# === Ensure log directory exists ===
os.makedirs(LogDir, exist_ok=True)

# === Create log file with timestamp ===
log_filename = f"log_{datetime.now().strftime('%Y-%m-%d_%H%M')}.txt"
log_path = os.path.join(LogDir, log_filename)

def run_automation_script():
    #try:
        if(os.path.exists(file_path)):
            if(os.path.exists(cmd_script_path)):
                result = subprocess.run('mvn.cmd -Dtest=TestRunner01 test', capture_output=True, text=True)
                log(result)
            else:
                log(f"{cmd_script_path} does'nt exist")
        else:
            log(f"{file_path} does'nt exist")
   # except Exception as e:
        #log(f"{str(e)}. Link problem")


def log(message):
    timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
    with open(log_path, 'a') as f:
        f.write(f"{timestamp} {message}\n")
    print(f"{timestamp} {message}")

def run_powershell_tasks():
    # Check if destination already exists
    if os.path.exists(DestinationPath):
        log(f"Skipped: Destination folder already exists in {DestinationPath}")
        return

    try:
        # 1. Check and Copy Folder
        log(f"Checking if source path exists: {SourcePath}")
        check_and_copy_command = [
            "powershell",
            "-Command",
            f"if (Test-Path '{SourcePath}') {{ "
            f"Copy-Item -Path '{SourcePath}' -Destination '{DestinationPath}' -Recurse -Force "
            f"}} else {{ Write-Host 'Source path not found: {SourcePath}'; exit 1 }}"
        ]
        subprocess.run(check_and_copy_command, check=True)
        log("Publish folder copied successfully.")
    except subprocess.CalledProcessError:
        log(f"Source path not found or failed to copy from: {SourcePath}")
        return
    except Exception as e:
        log(f"Unexpected error in copying folder: {e}")
        return

    # 2. Update JSON file
    update_json_file()

    try:
        # 3. Stop IIS Website
        stop_command = ["powershell", "-Command", f"Stop-Website -Name '{IISSiteName}'"]
        subprocess.run(stop_command, check=True)
        log(f"{IISSiteName} Site stopped successfully.")
    except Exception as e:
        log(f"Error in stopping IIS Website '{IISSiteName}': {e}")

    try:
        # 4. Change IIS Physical Path
        set_path_command = [
            "powershell",
            "-Command",
            f"Import-Module WebAdministration; "
            f"Set-ItemProperty 'IIS:\\Sites\\{IISSiteName}' -Name physicalPath "
            f"-Value '{DestinationPath}\\SPCBackend_{ReleaseFolderVersion}'"
        ]
        subprocess.run(set_path_command, check=True)
        log("IIS physical path updated successfully.")
    except Exception as e:
        log(f"Error in changing IIS Physical path: {e}")

    try:
        # 5. Start IIS Website
        start_command = ["powershell", "-Command", f"Start-Website -Name '{IISSiteName}'"]
        subprocess.run(start_command, check=True)
        log(f"{IISSiteName} Site started successfully.")
    except Exception as e:
        log(f"Error in starting IIS Website '{IISSiteName}': {e}")

def update_json_file():
    try:
        if not os.path.exists(JsonFilePath):
            log(f"JSON file not found at {JsonFilePath}")
            return

        with open(JsonFilePath, 'r') as file:
            data = json.load(file)

        data["ConnectionStrings"]["ConnectionString"] = (
            "Server=192.168.122.1,51433;Database=SPCAutomation;User Id=sa;"
            "Password=SmRueU4zQVdnbUU2VUk5UWNIR2pwVk10U1llc0It;"
            "Trusted_Connection=No;Connect Timeout=180"
        )

        with open(JsonFilePath, 'w') as file:
            json.dump(data, file, indent=4)

        log("QualisSPC.json updated successfully.")
        log('Running automation script.....')
        
    except Exception as e:
        log(f"Failed to update QualisSPC.json: {e}")
        
    run_automation_script()

# === Scheduler Loop ===
while True:
    log("Starting automated IIS update process...")
    run_powershell_tasks()
    log("Waiting 1 hour for next run...\n")
    time.sleep(3600)