package Locators;

import org.openqa.selenium.By;

public class AdminLocators {


        // Data Group
        public final By AddIcon = By.xpath("(//img[@id='new'])[1]");
        public final By DataGroup_AddButton = By.xpath("//a[text()='Add Data Group ']");
        public final By DataGroup_NameInput = By.xpath("(//input[@id='AddGroup'])[1]");
        public final By DataGroup_SaveButton = By.xpath("//button[text()=' Add ']");
        public final By DataGroup_CloseButton = By.xpath("//button[text()=' Close ']");

        // Part
        public final By Part_AddButton = By.xpath("//a[text()='Add Part ']");
        public final By DataGroup_Dropdown = By.xpath("//div[@class='dx-dropdowneditor-icon']");
        public final By Part_NameInput = By.id("AddPart");
        public final By Part_SaveButton = By.xpath("//button[text()=' Add ']");
        public final By Part_CloseButton = By.xpath("//button[@aria-label='Close']");

        // Characteristic Page Locators
        public final By Add_CharButton = By.xpath("(//a[normalize-space()='Add Characteristic'])[1]");
        public final By  AddChar_NameInput= By.id("AddChar");

        public final By Char_AddButton = By.xpath("//button[text()=' Add ']");
        public final By upperSpecInput = By.id("upperlmt");
        public final By lowerSpecInput = By.id("lowerspec");
        public final By subgroupSizeInput = By.id("subgroupsize");
        public final By saveCharacteristicButton = By.xpath("(//button[text()=' Save '])[1]");
        public final By CloseCharacteristicButton = By.xpath("//div[@class='overview']//button[@type='button'][normalize-space()='Close']");


        public final By controlChartIcon = By.xpath("//img[@id='CCP']");
        public final By analysisTab = By.xpath("//a[text()='Analysis']");
        public final By defineRunDropdown = By.xpath("//select[@formcontrolname='DefineRunValue']");
        public final By defineTrendDropdown = By.xpath("//select[@formcontrolname='DefineTrendValue']");
        public final By saveButton = By.xpath("//button[text()=' Save ']");
        public final By arInput = By.id("AR");
        public final By forceUserNoteCheckbox = By.xpath("//label[@for='forceUserNoteOnOOC']//span[@class='checkmark']");
        public final By saveDefineDetailsButton = By.xpath("//button[text()=' Save ']");
        public final By closeButton = By.xpath("(//button[text()=' Close '])[1]");



        //bychar

    public final By allowall = By.xpath("//p[text()=' Allow All ']");





        //Assign para to part





    public By filesicon = By.xpath("//div[@class='iconpos-top']//div[1]//span[1]//img[1]");
    public By Addptp = By.id("new");
    public By Assignparaicon = By.xpath("//a[text()='Assign Parameters to Part ']");
    public By datadropdown= By.xpath("(//input[@role='combobox'])[1]");
    public By selectgrp= By.xpath("//div[contains(text(),'BYPartGroup')]");
    public By partdropdown = By.xpath("(//input[@role='combobox'])[2]");
    public By selectpartpara = By.xpath("//div[contains(text(),'Roof Panel')]");
    public By checkallbox = By.xpath("(//span[@class='checkmark'])[4]");
    public By kebabicon = By.xpath("//span[@class='layout-btn btn-more none']//img");
    public By assignlink = By.xpath("//a[text()='Assign']");
    public By saveassign = By.xpath("//button[text()=' Save ']");
    public By closeassign = By.xpath("//button[text()=' Close ']");
    public By source01 = By.xpath("//p[text()=' Numeric ']");
    public By source02 = By.xpath("//p[text()=' PasswordProtection ']");
    public By source03 = By.xpath("//p[text()=' Operator ']");
    public By source04 = By.xpath("//p[text()=' Lookup_Table ']");

    public By Targetsource = By.xpath("//p[text()=' Assigned for part ']");



//

    public By Kebabsatellite = By.xpath("//span[@class='inline_svg svg_highlight moreimg']//img");
    public By Addpaegsatellite = By.xpath("(//li[@class=\"dropdown-item\"])[3]");
    public By Enterpagenamesatellite = By.xpath("(//input[@placeholder='Page Name'])[1]");
    public By Addsatellitepage = By.xpath("//button[text()=' Add ']");
    public By Dragsequencname = By.xpath("//p[text()=' Function-Based Names ']");
    public By savesatellitepage = By.xpath("(//button[text()=' Save '])[1]");
    public By Sequence01 = By.xpath("(//p[contains(text(),\" Stamping Line \")])");
    public By Sequence02 = By.xpath("//p[contains(text(),\" Welding Line \")]");
    public By Sequence03 = By.xpath("//p[contains(text(),\" Paint Shop \")]");
    public By Sequence04 = By.xpath("//p[contains(text(),\" Powertrain Assembly \")]");
    public By Sequence05 = By.xpath("//p[contains(text(),\" Chassis Assembly \")]");
    public By Target01 = By.xpath("//p[contains(text(),\" BYPART01 \")]");
    public By Target02 = By.xpath("//p[contains(text(),\" BYPART02 \")]");
    public By Target03 = By.xpath("//p[contains(text(),\" BYPART03 \")]");
    public By Target04 = By.xpath("//p[contains(text(),\" BYPART04 \")]");
    public By Target05 = By.xpath("//p[contains(text(),\" BYPART05 \")]");






        // Attribute

        public final By Char_DatGroupButton = By.xpath("(//lib-devextreme-selectbox)[1]");
        public final By Part_Button = By.xpath("(//lib-devextreme-selectbox)[2]");
        public final By CharType_Dropdown = By.xpath("(//lib-devextreme-selectbox)[3]");
        public final By Attribute_Type = By.xpath("(//div[contains(text(),'Attribute')])[2]");
        public final By Add_charButton = By.xpath("(//button[normalize-space()='Add'])[1]");
        public final By defects_Tab = By.xpath("//a[text()='Defects']");
        public final By addDefect_Button = By.xpath("//span[@class='qual_plus']");
        public final By operationatb = By.xpath("//a[@id='email-tab' and text()='Operator Information']");
        public final By dropdownsheet = By.xpath("//select[@class=\"ng-untouched ng-pristine ng-valid\"]");
         public final By Cheecksheet = By.xpath("//input[@id='CheckSheet']/following-sibling::span[@class='checkmark']");

        public final By defectName_Input = By.id("defectName");
        public final By inspectionUnit = By.id("inspecunit");
        public final By Tally      = By.id("tally");
        public final By savedefect = By.xpath("(//button[@type='button'][normalize-space()='Save'])[2]");
        public final By saveDefect_Button = By.xpath("//button[contains(text(),\" Save \")]");

        // Sequence Page Locators
        public final By AddSequence_Button = By.xpath("//a[text()='Add Sequence ']");
        public final By dataGroupDropdown = By.xpath("(//div[@class='dx-dropdowneditor-icon'])[1]");
        public final By selectDataGroup = By.xpath("//div[text()='SPC_Control_Group']");
        public final By partDropdown = By.xpath("(//div[@class='dx-dropdowneditor-icon'])[2]");
        public final By selectPart = By.xpath("//div[text()='Car Spare parts']");
        public final By SequenceAddButton = By.xpath("//button[text()=' Add ']");
        public final By sequenceNameInput = By.xpath("//input[@maxlength='40']");
        public final By TimeManualDP = By.xpath("(//input[@role='combobox'])[3]");
        public final By TimeManual = By.xpath("//div[contains(text(),\"Manual\")]");

        public final By selectAllCheckbox = By.xpath("(//span[@class='checkmark'])[4]");
        public final By kebabMenu = By.xpath("//span[@class='layout-btn btn-more none']//img");
        public final By assignOption = By.xpath("//a[text()='Assign']");
        public final By SequenceSaveButton = By.xpath("//button[text()='Save']");
        public final By SequenceCloseButton = By.xpath("//button[text()=' Close ']");
        public final By EntryMode = By.xpath("(//input[@role='combobox'])[2]");
        public final By SelectMode = By.xpath("(//div[contains(text(),'By Part')])[1]");
        public final By Parametertype = By.xpath("(//input[@role='combobox'])[4]");
        public final By selectypepara = By.xpath("(//div[contains(text(),'Clear')])[1]");
        public final By carryforwardby = By.xpath("(//div[contains(text(),'Carry_Forward_First_Characteristic')])[1]");


    public final By selectypecarryforward = By.xpath("(//div[contains(text(),'Clear')])[1]");


    public final By inputlistpart = By.xpath("//select[@id=\"parameterSearhEDD\"]");

    public final By inputlistpartok = By.id("param_search_ok");
    public final By TotalInput = By.xpath("//input[@min=\"0\"]");







        // General Operations
        public final By General_Operation = By.xpath("//img[@id='GO']");
        public final By AutomaticallyRepeatSequence = By.id("AutomaticallyRepeat");
        public final By CompleteHandsfreeOperation = By.id("completehandfree");
        public final By HandsfreeOperationStopForNotes = By.id("HandsFreeNoNotes");
        public final By Part_Name = By.id("partname");
        public final By Header_Name = By.xpath("//input[@id='header2']");
        public final By date = By.id("date");
        public final By Parameter = By.id("parameter");
        public final By Parameter01 = By.xpath("//label[text()='Parameters']");
        public final By Samples = By.id("samples");
        public final By Date_Name = By.id("date");
        public final By Runs = By.id("RN");
        public final By sequencechained = By.xpath("(//input[@aria-autocomplete=\"list\"])[1]");
        public final By chainesequencevalue = By.xpath("//div[text()='Stamping Line']");
        public final By parasearch = By.xpath("(//div[@class=\"dx-dropdowneditor-icon\"])[2]");
        public final By value2match = By.xpath("//div[text()=\"Operator\"]");

    public final By chainesequencevalue2 = By.xpath("//div[text()='Cylinder Block Inspection']");




//

        public  final By NetworkIcon = By.xpath("(//img)[6]");
        public final By editIcon = By.xpath("(//img[@class=\"EDIT_BLUE\"])[1]");
        public final By editIcon01 = By.xpath("(//img[@class=\"EDIT_BLUE\"])[2]");
        public final By closeSequence = By.xpath("(//button[normalize-space()='Close'])[1]");
        public final By yes = By.xpath("(//button[normalize-space()='Yes'])[1]");


        public final By LeftEdit = By.xpath("(//span[@class=\"subgroup_edit_left\"]//img)[3]");
        public final By NoteIcon = By.xpath("//img[@class=\"NOTE\"]");

        public final By UserNote  = By.id("UserNote");
        public  final By SequencePage = By.xpath("//h5[text()='Switch Panel']");
        public  final By SequencePage1 = By.xpath("//h5[text()='Steering Wheel']");
        public  final By SequencePage2 = By.xpath("//h5[text()='Dashboard Panel']");
        public  final By SequencePage3 = By.xpath("//h5[text()='Cross Member']");
        public  final By SequencePage4 = By.xpath("//h5[text()='Wheel Alignment']");
        public  final By SequencePage5 = By.xpath("//h5[text()='Hardness']");
        public  final By SequencePage6 = By.xpath("//h5[text()='Hardness_01']");

        public  final By ParaToMatch = By.id("parametersearch");
        public  final By ParaToMatchOk = By.id("param_search_ok");




        public  final By RunSequence = By.xpath("(//div[@id='page1']/div[2]/div/table/tbody/tr/td/span/span/img)[1]");

        // Subgroup fields
        public final By AutomaticData = By.id("idDate");
        public final By AutomaticTime = By.id("idTime");
        public final By Header = By.xpath("//i[text()='Part Name : Engine block']");

        public final By Header1 = By.xpath("//i[text()='Part Number : ']");
        public final By Para01 = By.xpath("(//input[@cursorposition=\"1\"])[1]");

        public final By Para02 = By.xpath("(//input[@cursorposition=\"1\"])[2]");

        public  final By Subgroup0 = By.id("Subgroup_0");
        public  final By Subgroup02 = By.id("Subgroup_1");
        public final By subgroup03 = By.id("Subgroup_2");
        public final By subgroup04 = By.id("Subgroup_3");
        public final By subgroup05 = By.id("Subgroup_4");
        public final By subgroup06 = By.id("Subgroup_5");
        public final By subgroup07 = By.id("Subgroup_6");
        public final By subgroup08 = By.id("Subgroup_7");
        public final By subgroup09 = By.id("Subgroup_8");
        public final By subgroup10 = By.id("Subgroup_9");
        public final By subgroup11 = By.id("Subgroup_10");
        public final By subgroup12 = By.id("Subgroup_11");
        public final By subgroup13 = By.id("Subgroup_12");
        public final By subgroup14 = By.id("Subgroup_13");
        public final By subgroup15 = By.id("Subgroup_14");

        //checksheet
        public final By RadioButton01 = By.xpath("(//span[@class='checkmark'])[1]");
        public final By RadioButton02 = By.xpath("(//span[@class='checkmark'])[7]");
        public final By RadioButton03 = By.xpath("(//span[@class='checkmark'])[12]");
        public final By RadioButton04 = By.xpath("(//span[@class='checkmark'])[17]");
        public final By RadioButton05 = By.xpath("(//span[@class='checkmark'])[21]");

       // By part
       public final By BYpartvariable = By.id("sub_100");
    public final By BYpartvariable02 = By.id("sub_102");
    public final By BYpartvariable03 = By.id("sub_103");
    public final By BYpartvariable04 = By.id("sub_104");
    public final By BYpartvariable05 = By.id("sub_105");
    public final By BYpartvariable06 = By.id("sub_106");
    public final By BYpartvariable07 = By.id("sub_107");
    public final By BYpartvariable08 = By.id("sub_108");
    public final By BYpartvariable09 = By.id("sub_109");
    public final By BYpartvariable10 = By.id("sub_110");
    public final By BYpartvariable11 = By.id("sub_111");
    public final By BYpartvariable12 = By.id("sub_112");
    public final By BYpartvariable13 = By.id("sub_113");
    public final By BYpartvariable14 = By.id("sub_114");
    public final By BYpartvariable15 = By.id("sub_115");



//    public final By BYpartvariable = By.id("sub_100");


        public final By BYPartAttribute = By.id("sub_101");
        public final By BYPartAttribute02 = By.id("sub_103");
        public final By BYPartAttribute03 = By.id("sub_105");

        public final By Bypartsave = By.id("sequencebypartsave");



        public final By NoteOK = By.xpath("(//button[text()=' OK '])[1]");
        public final By EnterNote = By.id("Postnote");
        public final By SubmitNote = By.xpath("//button[text()=' Submit ']");




        public  final By Subgroup00 = By.id("Subgroup_0_0");
        public  final By Subgroup10 = By.id("Subgroup_1_0");
        public  final By Subgroup20 = By.id("Subgroup_2_0");
        public  final By Subgroup30 = By.id("Subgroup_3_0");
        public  final By Subgroup40 = By.id("Subgroup_4_0");
        public  final By TotalSubgroup0 = By.id("totSubgroup_0");
        public  final By timeCount = By.xpath("//div[@id=\"countdown-number\"]");

        //bypart


        public  final By BySubgroup00 = By.id("Subgroup_0_1_0");
        public  final By BySubgroup10 = By.id("Subgroup_1_1_0");
        public  final By BySubgroup20 = By.id("Subgroup_2_1_0");
        public  final By BySubgroup30 = By.id("Subgroup_3_1_0");
        public  final By BySubgroup40 = By.id("Subgroup_4_1_0");

        public  final By ByTotalSubgroup0 = By.id("totSubgroup_1_0");
        public  final By partok = By.cssSelector("#bypartOK_1_0");


        public  final By Tally01 = By.xpath("(//span[@class='tallyPlus']/img)[1]");
        public  final By Tally02 = By.xpath("(//span[@class='tallyPlus']/img)[2]");
        public  final By Tally03 = By.xpath("(//span[@class='tallyPlus']/img)[3]");
        public  final By Tally04 = By.xpath("(//span[@class='tallyPlus']/img)[4]");
        public  final By Tally05 = By.xpath("(//span[@class='tallyPlus']/img)[5]");

        // Buttons
        public  final By closebypart = By.xpath("//button[text()=' Close ']");
        public  final By yesbypart = By.xpath("//button[text()=' Yes ']");


        public  final By SubmitBtn = By.id("sequencebychartsave");
        public  final By popuppara = By.xpath("(//div[@class=\"modal-content ui-draggable\"])[3]");
        public  final By canpopup = By.xpath("(//button[contains(text(),\" Cancel \")])[1]\n");
        public  final By continueButton = By.xpath("//button[text()=' Continue ']");


    public By getDataGroupByName(String name) {
        return By.xpath("//div[text()='" + name + "']");
    }

        public By getDataGroupByName01(String name) {
                return By.xpath("//h5[text()='" + name + "']");
        }

}














