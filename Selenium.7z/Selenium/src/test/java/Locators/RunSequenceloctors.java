package Locators;

import org.openqa.selenium.By;

public class RunSequenceloctors {





    public static final By SequenceIcon = By.xpath("//div[2]/span/img");
    public static final By SequenceDiv = By.xpath("//h5[text()='Switch Panel']");
    public static final By AddSubgroupBtn = By.xpath("(//div[@id='page1']/div[2]/div/table/tbody/tr/td/span/span/img)[1]");

    // Subgroup fields
    public static final By Subgroup0 = By.id("Subgroup_0");
    public static final By Subgroup00 = By.id("Subgroup_0_0");
    public static final By Subgroup10 = By.id("Subgroup_1_0");
    public static final By Subgroup20 = By.id("Subgroup_2_0");
    public static final By Subgroup30 = By.id("Subgroup_3_0");
    public static final By Subgroup40 = By.id("Subgroup_4_0");
    public static final By TotalSubgroup0 = By.id("totSubgroup_0");

    // Buttons
    public static final By SubmitBtn = By.cssSelector(".subgroups_less");
    public static final By TimeDelayNextChart = By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Time delay for the next chart'])[1]/following::*[name()='svg'][1]");
}

