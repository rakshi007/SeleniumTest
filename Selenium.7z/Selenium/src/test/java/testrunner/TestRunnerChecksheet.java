package testrunner;


import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"src/test/resources/feature/DageAttribute.feature"},
        glue = {"stepdefinitions", "Hooks"},
        dryRun = false,
        plugin = {
                "pretty",
                "html:target/cucumber-reports.html",
                "rerun:target/failed_scenarios.txt", // Logs failed scenarios
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
        },
        tags = "@RunThis"
)
public class TestRunnerChecksheet {
}
