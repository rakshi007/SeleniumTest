package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.DriverFactory;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.TestCase02Page;
import util.ConfigReader;
import util.ExtentReportManager;

public class TestStatus02 {

	
	
	
	private TestCase02Page tc = new TestCase02Page(DriverFactory.getDriver());

	ConfigReader configReader = new ConfigReader();
	

	 private ExtentTest test;

	  {
	        // Initialize a new test
		  {
		        this.test = ExtentReportManager.getTest();
		    }
	        test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
	    }
	
	  ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();
	
	
	
	
	
	@When("user click on network icon to verify test")
	public void user_click_on_network_icon_to_verify_test() {
	  tc.network1();
	 
	   ExtentCucumberAdapter.addTestStepLog("user clicked on network icon");

	}

	@Then("user click on page name for edit and to verify testcase003")
	public void user_click_on_page_name_for_edit_and_to_verify_testcase003() throws InterruptedException {
		Thread.sleep(1000);
	 tc.clickvaripage();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on page name to enter edit");

	}

	
	
	
	@Then("user click on edit icon to verify testcase003")
	public void user_click_on_edit_icon_to_verify_testcase003() {
	  tc.editpencil();
	  ExtentCucumberAdapter.addTestStepLog("user clicked edit icon to enter sample data values");
	}

	@Then("user click on date input field to verify testcase003")
	public void user_click_on_date_input_field_to_verify_testcase003() {
	  tc.date();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on date input field");
	}

	@Then("user click on time input field to verify testcase003")
	public void user_click_on_time_input_field_to_verify_testcase003() {
	  tc.time();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on time input field");
	}


	@Then("user enter subgroup size1 to verify testcase003")
	public void user_enter_subgroup_size1_to_verify_testcase003() {
	  tc.subgroup1();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data one");
	}

	@Then("user enter subgroup size2 to verify testcase003")
	public void user_enter_subgroup_size2_to_verify_testcase003() {
	  tc.subgroup2();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data two");
	  
	}
	  
	  @Then("user click on save button to varify require para entry  testcase003")
		public void user_click_on_save_button_to_varify_require_para_entry_testcase003() {
		  tc.savere();
		  ExtentCucumberAdapter.addTestStepLog("user clicked on save button ");
		}

		@Then("user click on ok button on the popup  testcase003")
		public void user_click_on_ok_button_on_the_popup_testcase003() throws InterruptedException {
		  tc.clickok();
		  ExtentCucumberAdapter.addTestStepLog("user clicked on ok button ");
		}
	
		@Then("user enter value for require parameter field  to verify testcase003 for first data")
		public void user_enter_value_for_require_parameter_field_to_verify_testcase003_for_first_data() {
		   tc.parameterdp2();
		   ExtentCucumberAdapter.addTestStepLog("user entered require parameter entries ");
		}
		
		

	@Then("user click on save button for chart01 to verify testcase003")
	public void user_click_on_save_button_for_chart01_to_verify_testcase003() {
	  tc.savechart();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on save button ");
	}

	@Then("user fetch the  of the page to verify testcase003")
	public void user_fetch_the__of_the_page_to_verify_testcase003() {
	  tc.getText();
	  ExtentCucumberAdapter.addTestStepLog("user fetch the  of subgroup 1");
	}

	
	//2
	@Then("user click on time2 input field to verify testcase003")
	public void user_click_on_time2_input_field_to_verify_testcase003() throws InterruptedException {
		  Thread.sleep(1000);
		tc.time2();
	  
	    ExtentCucumberAdapter.addTestStepLog("user clicked on time input field");
	}



	

	@Then("user enter subgroup size12 to verify testcase003")
	public void user_enter_subgroup_size12_to_verify_testcase003() throws InterruptedException {
		 Thread.sleep(1000);
	  tc.subgroup22();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data one");
	}

	@Then("user enter subgroup size22 to verify testcase003")
	public void user_enter_subgroup_size22_to_verify_testcase003() throws InterruptedException {
		 Thread.sleep(1000);
	  tc.subgroup3();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data two");
	  
	}


@Then("user fetch the datavalues01 to verify testcase03")
public void user_fetch_the_datavalues01_to_verify_testcase03() {
   tc.validateDataValues01();
}
	

	@Then("user click on save2 button for chart01 to verify  testcase003")
	public void user_click_on_save2_button_for_chart01_to_verify_testcase003() throws InterruptedException {
		 Thread.sleep(1000);
	  tc.savechart2();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on save button ");
	}

	@Then("user fetch the 2 of the page  to verify  testcase003")
	public void user_fetch_the_2_of_the_page_to_verify_testcase003() throws InterruptedException {
	
		Thread.sleep(2000);
	  tc.getText2();
	  ExtentCucumberAdapter.addTestStepLog("user fetch the  of subgroup 2");
	}
	
	
	
	//3

	@Then("user click on time3 input field to verify   testcase003")
	public void user_click_on_time3_input_field_to_verify_testcase003() throws InterruptedException {
		 Thread.sleep(1000);
	  tc.time3();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on time input field");
	}

	@Then("user enter subgroup size3 to verify   testcase003")
	public void user_enter_subgroup_size3_to_verify_testcase003() {
	  tc.subgroup13();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data one");
	}

	@Then("user enter subgroup size33 to verify   testcase003")
	public void user_enter_subgroup_size33_to_verify_testcase003() {
	  tc.subgroup33();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data two");
	}

@Then("user fetch the datavalues02 to verify testcase03")
public void user_fetch_the_datavalues02_to_verify_testcase03() {
    tc.validateDataValues02();
}
	
	
	
	
	@Then("user click on save3 button for chart01 to verify   testcase003")
	public void user_click_on_save3_button_for_chart01_to_verify_testcase003() {
	  tc.savechart3();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on save button ");
	}

	@Then("user fetch the 3 of the page  to verify   testcase003")
	public void user_fetch_the_3_of_the_page_to_verify_testcase003() throws InterruptedException {
		Thread.sleep(1000);
	  tc.getText3();
	  ExtentCucumberAdapter.addTestStepLog("user fetch the  of subgroup 3");
	}
	
	
	
	
	
	
	//4

	@Then("user click on time4 input field to verify  testcase003")
	public void user_click_on_time4_input_field_to_verify_testcase003() throws InterruptedException {
		 Thread.sleep(1000);
	  tc.time4();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on time input field");
	}

	@Then("user enter subgroup size4 to verify  testcase003")
	public void user_enter_subgroup_size4_to_verify_testcase003() {
	  tc.subgroup4();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data one");
	}

	@Then("user enter subgroup size44 to verify  testcase003")
	public void user_enter_subgroup_size44_to_verify_testcase003() {
	  tc.subgroup44();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data two");
	}
	
	@Then("user fetch the datavalues03 to verify testcase03")
	public void user_fetch_the_datavalues03_to_verify_testcase03() {
		 tc.validateDataValues03();
	}

	@Then("user click on save4 button for chart01 to  testcase003")
	public void user_click_on_save4_button_for_chart01_to_testcase003() {
	  tc.savechart4();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on save button ");
	}

	@Then("user fetch the 4 of the page  to verify  testcase003")
	public void user_fetch_the_4_of_the_page_to_verify_testcase003() throws InterruptedException {
		Thread.sleep(1000);
	  tc.getText4();
	  ExtentCucumberAdapter.addTestStepLog("user fetch the  of subgroup 4");
	}

	
	
	
	
	//5
	@Then("user click on time5 input field to verify  testcase003")
	public void user_click_on_time5_input_field_to_verify_testcase003() throws InterruptedException {
		Thread.sleep(1000);
	  tc.time5();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on time input field");
	}

	@Then("user enter subgroup size5 to verify  testcase003")
	public void user_enter_subgroup_size5_to_verify_testcase003() {
	  tc.subgroup5();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data one");
	}

	@Then("user enter subgroup size55 to verify  testcase003")
	public void user_enter_subgroup_size55_to_verify_testcase003() {
	  tc.subgroup55();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data two");
	}
	

@Then("user fetch the datavalues04 to verify testcase03")
public void user_fetch_the_datavalues04_to_verify_testcase03() {
	 tc.validateDataValues04();
}


	@Then("user click on save5 button for chart01 to verify  testcase003")
	public void user_click_on_save5_button_for_chart01_to_verify_testcase003() {
	  tc.savechart5();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on save button ");
	}

	@Then("user fetch the 5 of the page  to verify  testcase003")
	public void user_fetch_the_5_of_the_page_to_verify_testcase003() throws InterruptedException {
		Thread.sleep(1000);
	  tc.getText5();
	  ExtentCucumberAdapter.addTestStepLog("user fetch the  of subgroup 5");
	}
	
	
	
	
	//6

	@Then("user click on time6 inputfield to verify  testcase003")
	public void user_click_on_time6_inputfield_to_verify_testcase003() throws InterruptedException {
	  tc.time6();
	  Thread.sleep(1000);
	  ExtentCucumberAdapter.addTestStepLog("user clicked on time input field");
	}

	@Then("user enter subgroup size6  to verify  testcase003")
	public void user_enter_subgroup_size6_to_verify_testcase003() {
	  tc.subgroup66();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data one");
	}

	@Then("user enter subgroup size66  to verify  testcase003")
	public void user_enter_subgroup_size66_to_verify_testcase003() {
	  tc.subgroup6();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data two");
	}
	
	@Then("user fetch the datavalues05 to verify testcase03")
	public void user_fetch_the_datavalues05_to_verify_testcase03() {
		 tc.validateDataValues05();
	}

	@Then("user click on save6 button for chart01 to verify  testcase003")
	public void user_click_on_save6_button_for_chart01_to_verify_testcase003() {
	  tc.savechar6();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on save button ");
	}



	


	@Then("user fetch the 6 of the page  to verify  testcase003")
	public void user_fetch_the_6_of_the_page_to_verify_testcase003() throws InterruptedException {
		Thread.sleep(1000);
	  tc.getText6();
	  ExtentCucumberAdapter.addTestStepLog("user fetch the  of subgroup 6");
	}

	
	
	//7
	
	@Then("user click on time7 input field to verify  testcase003")
	public void user_click_on_time7_input_field_to_verify_testcase003() throws InterruptedException {
	  tc.time7();
	  Thread.sleep(1000);
	  ExtentCucumberAdapter.addTestStepLog("user clicked on time input field");
	}

	@Then("user enter subgroup size7  to verify  testcase003")
	public void user_enter_subgroup_size7_to_verify_testcase003() {
	  tc.subgroup77();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data one");
	}

	@Then("user enter subgroup size77  to verify  testcase003")
	public void user_enter_subgroup_size77_to_verify_testcase003() {
	  tc.subgroup7();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data two");
	}
	
	@Then("user fetch the datavalues06 to verify testcase03")
	public void user_fetch_the_datavalues06_to_verify_testcase03() {
		 tc.validateDataValues06();
	}
	

	@Then("user click on save7 button for chart01 to verify  testcase003")
	public void user_click_on_save7_button_for_chart01_to_verify_testcase003() throws InterruptedException {
	  tc.savechart7();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on save button ");
	}


//	@Then("user clicks on ok button to verify avg run down")
//	public void user_clicks_on_ok_button_to_verify_avg_run_down() throws InterruptedException {
//		tc.okbutton();
//	}
//
//	@Then("user select cause from casue dropdown to verify avg run down")
//	public void user_select_cause_from_casue_dropdown_to_verify_avg_run_down() throws InterruptedException {
//		tc.causeselect();
//	}
//
//	@Then("user clicks on submit button to verify abg run down")
//	public void user_clicks_on_submit_button_to_verify_abg_run_down() throws InterruptedException {
//		tc.submitcauses();
//	}

	@Then("user fetch the 7 of the page  to verify  testcase003")
	public void user_fetch_the_7_of_the_page_to_verify_testcase003() {
	  tc.getText7();
	  ExtentCucumberAdapter.addTestStepLog("user fetch the  of subgroup 7");
	}

	@Then("user fetch the datavalues07 to verify testcase03")
	public void user_fetch_the_datavalues07_to_verify_testcase03() {
		 tc.validateDataValues07();
	}

	
	
	
	
}
