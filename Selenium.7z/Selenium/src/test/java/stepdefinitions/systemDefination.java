package stepdefinitions;

import DriverFactory.DriverFactory;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pages.GlobalPage;
import pages.InSubgroupPage;
import util.ConfigReader;
import util.ExtentReportManager;

public class systemDefination {

    private GlobalPage tc = new GlobalPage(DriverFactory.getDriver());
    ConfigReader configReader = new ConfigReader();
    private ExtentTest test;

    {
        this.test = ExtentReportManager.getTest();
        test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
    }

    ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();



    @Given("when user creates general setting")
    public void when_user_creates_general_setting() {
     tc.SystemD();
    }

    @Then("user creates email tab")
    public void user_creates_email_tab() {
        tc.Email();
    }


}
