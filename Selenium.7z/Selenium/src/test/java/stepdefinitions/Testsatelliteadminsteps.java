package stepdefinitions;

import DriverFactory.DriverFactory;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import io.cucumber.java.en.Given;
import pages.GlobalPage;
import pages.NetworkPage;
import util.ConfigReader;
import util.ExtentReportManager;

public class Testsatelliteadminsteps {


    private NetworkPage tc = new NetworkPage(DriverFactory.getDriver());
    ConfigReader configReader = new ConfigReader();
    private ExtentTest test;

    {
        this.test = ExtentReportManager.getTest();
        test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
    }

    ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();

    @Given("when user add edit delete given satellite pages")
    public void when_user_add_edit_delete_given_satellite_pages() {

    }


    @Given("when user add edit pages in satellite")
    public void when_user_add_edit_pages_in_satellite() {
        tc.Editpage();
    }


    @Given("when user validates rearrange satellite")
    public void when_user_validates_rearrange_satellite() {
        tc.rearranger();
    }

    @Given("when user rearrange given pages")
    public void when_user_rearrange_given_pages() {
        tc.rearrangepage();
    }

}
