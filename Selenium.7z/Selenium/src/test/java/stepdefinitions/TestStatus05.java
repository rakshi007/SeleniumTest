package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.DriverFactory;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.TestCase05Page;
import util.ConfigReader;
import util.ExtentReportManager;

public class TestStatus05 {

	private TestCase05Page tc = new TestCase05Page(DriverFactory.getDriver());

	ConfigReader configReader = new ConfigReader();

	private ExtentTest test;

	{
		// Initialize a new test
		{
			this.test = ExtentReportManager.getTest();
		}
		test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
	}

	ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();



	@When("user clicks on network icon to verify  hug SPC status")
	public void user_clicks_on_network_icon_to_verify_hug_spc_status() throws InterruptedException {
		tc.network1();

	}

	@Then("user clicks on page name for edit to verify  hug SPC status")
	public void user_clicks_on_page_name_for_edit_to_verify_hug_spc_status() {
		tc.clickvaripage();
	}

	@Then("user clicks on edit icon to verify  hug SPC status")
	public void user_clicks_on_edit_icon_to_verify_hug_spc_status() {
	tc.editpencil();
	}

	@When("user clicks on date input field to verify  hug Avg status")
	public void user_clicks_on_date_input_field_to_verify_hug_avg_status() {
		tc.date();
	}

	@Then("user clicks on time1 input field to verify  hug Avg status")
	public void user_clicks_on_time1_input_field_to_verify_hug_avg_status() {
		tc.time1();
	}

	@Then("user enters subgroup size for one1 to verify  hug Avg status")
	public void user_enters_subgroup_size_for_one1_to_verify_hug_avg_status() throws InterruptedException {
		tc.subgroup01();
	}

	@Then("user enters subgroup size for two2 to verify  hug Avg status")
	public void user_enters_subgroup_size_for_two2_to_verify_hug_avg_status() throws InterruptedException {
		tc.subgroup02();
	}

	@Then("user clicks on save button for chart1 to verify  hug Avg status")
	public void user_clicks_on_save_button_for_chart1_to_verify_hug_avg_status() {
		tc.savechart01();
	}

	@Then("user fetches the {int} of the page to verify  hug Avg status")
	public void user_fetches_the_of_the_page_to_verify_hug_avg_status(Integer int1) {
	tc.getText();
	}

	@When("user clicks on time2 input field to verify  hug Avg status")
	public void user_clicks_on_time2_input_field_to_verify_hug_avg_status() throws InterruptedException {
		tc.time2();
	}

	@Then("user enters subgroup size for one3 to verify  hug Avg status")
	public void user_enters_subgroup_size_for_one3_to_verify_hug_avg_status() throws InterruptedException {
		tc.subgroup11();
	}

	@Then("user enters subgroup size for two4 to verify  hug Avg status")
	public void user_enters_subgroup_size_for_two4_to_verify_hug_avg_status() throws InterruptedException {
		tc.subgroup12();
	}

	@Then("user fetches the validation data01 to verify  hug Avg status")
	public void user_fetches_the_validation_data01_to_verify_hug_avg_status() {
tc.validateDataValues01();

	}

	@Then("user enters verify allow all by entering alpha numeric value to verify  hug Avg status")
	public void user_enters_verify_allow_all_by_entering_alpha_numeric_value_to_verify_hug_avg_status() {
tc.parameterdp3();
	}

	@Then("user clicks on save button for chart2 to verify  hug Avg status")
	public void user_clicks_on_save_button_for_chart2_to_verify_hug_avg_status() {
		tc.Savechart02();
	}

	@When("user clicks on time3 input field to verify  hug Avg status")
	public void user_clicks_on_time3_input_field_to_verify_hug_avg_status() {
		tc.time3();
	}

	@Then("user enters subgroup size for one5 to verify  hug Avg status")
	public void user_enters_subgroup_size_for_one5_to_verify_hug_avg_status() {
		tc.subgroup21();
	}

	@Then("user enters subgroup size for two6 to verify  hug Avg status")
	public void user_enters_subgroup_size_for_two6_to_verify_hug_avg_status() {
		tc.savechart331();
	}

	@Then("user fetches the validation data02 to verify  hug Avg status")
	public void user_fetches_the_validation_data02_to_verify_hug_avg_status() {
		tc.validateDataValues02();
	}

	@Then("user clicks on save button for chart3 to verify  hug Avg status")
	public void user_clicks_on_save_button_for_chart3_to_verify_hug_avg_status() {
		tc.savechart331();
	}

	@Then("user fetches the status of the page to verify  hug Avg status")
	public void user_fetches_the_status_of_the_page_to_verify_hug_avg_status() {
		tc.getText3();
	}

	@When("user clicks on time4 input field to verify  hug Avg status")
	public void user_clicks_on_time4_input_field_to_verify_hug_avg_status() {
		tc.time4();
	}

	@Then("user enters subgroup size for one7 to verify  hug Avg status")
	public void user_enters_subgroup_size_for_one7_to_verify_hug_avg_status() {
		tc.subgroup31();
	}

	@Then("user enters subgroup size for two8 to verify  hug Avg status")
	public void user_enters_subgroup_size_for_two8_to_verify_hug_avg_status() {
		tc.subgroup32();
	}

	@Then("user fetches the validation data03 to verify  hug Avg status")
	public void user_fetches_the_validation_data03_to_verify_hug_avg_status() {
		tc.validateDataValues03();
	}

	@Then("user clicks on save button for chart4 to verify  hug Avg status")
	public void user_clicks_on_save_button_for_chart4_to_verify_hug_avg_status() {
		tc.savechart4();
	}

	@Then("user fetches the status {int} of the page to verify  hug Avg status")
	public void user_fetches_the_status_of_the_page_to_verify_hug_avg_status(Integer int1) {
		tc.getText4();
	}


	@When("user clicks on time5 input field to verify  hug Avg status")
	public void user_clicks_on_time5_input_field_to_verify_hug_avg_status() {
		tc.time5();
	}

	@Then("user enters subgroup size for one9 to verify  hug Avg status")
	public void user_enters_subgroup_size_for_one9_to_verify_hug_avg_status() {
	tc.subgroup41();
	}

	@Then("user enters subgroup size for two10 to verify  hug Avg status")
	public void user_enters_subgroup_size_for_two10_to_verify_hug_avg_status() {
		tc.subgroup42();
	}

	@Then("user fetches the validation data04 to verify  hug Avg status")
	public void user_fetches_the_validation_data04_to_verify_hug_avg_status() {
		tc.validateDataValues04();
	}

	@Then("user clicks on save button for chart5 to verify  hug Avg status")
	public void user_clicks_on_save_button_for_chart5_to_verify_hug_avg_status() throws InterruptedException {
		tc.savechart5();
	}



	@When("user clicks on time6 input field to verify  hug Avg status")
	public void user_clicks_on_time6_input_field_to_verify_hug_avg_status() {
		tc.time6();
	}

	@Then("user enters subgroup size for one11 to verify  hug Avg status")
	public void user_enters_subgroup_size_for_one11_to_verify_hug_avg_status() {
		tc.subgroup61();
	}

	@Then("user enters subgroup size for two12 to verify  hug Avg status")
	public void user_enters_subgroup_size_for_two12_to_verify_hug_avg_status() {
		tc.subgroup62();
	}

	@Then("user fetches the validation data05 to verify  hug Avg status")
	public void user_fetches_the_validation_data05_to_verify_hug_avg_status() {
		tc.validateDataValues05();
	}

	@Then("user clicks on save button for chart6 to verify  hug Avg status")
	public void user_clicks_on_save_button_for_chart6_to_verify_hug_avg_status() throws InterruptedException {
		tc.savechart6();
	}

	@When("user clicks on time7 input field to verify  hug Avg status")
	public void user_clicks_on_time7_input_field_to_verify_hug_avg_status() {
		tc.time7();
	}

	@Then("user enters subgroup size for one13 to verify  hug Avg status")
	public void user_enters_subgroup_size_for_one13_to_verify_hug_avg_status() {
		tc.subgroup71();
	}

	@Then("user enters subgroup size for two14 to verify  hug Avg status")
	public void user_enters_subgroup_size_for_two14_to_verify_hug_avg_status() {
		tc.subgroup72();
	}

	@Then("user fetches the validation data06 to verify  hug Avg status")
	public void user_fetches_the_validation_data06_to_verify_hug_avg_status() {
		tc.validateDataValues06();
	}

	@Then("user clicks on save button for chart7 to verify  hug Avg status")
	public void user_clicks_on_save_button_for_chart7_to_verify_hug_avg_status() throws InterruptedException {
		tc.savechart71();
	}

	@When("user clicks on time08 input field to verify  hug Avg status")
	public void user_clicks_on_time08_input_field_to_verify_hug_avg_status() {
		tc.time8();
	}

	@Then("user enters subgroup size for one15 to verify  hug Avg status")
	public void user_enters_subgroup_size_for_one15_to_verify_hug_avg_status() {
		tc.subgroup81();
	}

	@Then("user enters subgroup size for two16 to verify  hug Avg status")
	public void user_enters_subgroup_size_for_two16_to_verify_hug_avg_status() {
		tc.subgroup82();
	}

	@Then("user fetches the validation data07 to verify  hug Avg status")
	public void user_fetches_the_validation_data07_to_verify_hug_avg_status() {
		tc.validateDataValues07();
	}

	@Then("user clicks on save button for chart8 to verify  hug Avg status")
	public void user_clicks_on_save_button_for_chart8_to_verify_hug_avg_status() throws InterruptedException {
		tc.savechart81();
	}

	@Then("user clicks on cancel button for chart08 to verify  hug Avg status")
	public void user_clicks_on_cancel_button_for_chart08_to_verify_hug_avg_status() throws InterruptedException {
		tc.Cancel8();
	}

	@Then("user fetches the validation data08 to verify  hug Avg status")
	public void user_fetches_the_validation_data08_to_verify_hug_avg_status() {
		tc.validateDataValues08();
	}






}
