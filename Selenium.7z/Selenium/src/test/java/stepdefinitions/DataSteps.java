package stepdefinitions;

import io.cucumber.java.en.Then;

public class DataSteps {


    @Then("user should see grid coulumn")
    public void user_should_see_grid_coulumn() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }
}
