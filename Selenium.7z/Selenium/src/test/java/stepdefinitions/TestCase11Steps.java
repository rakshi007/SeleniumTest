package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.DriverFactory;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.TestCase10Page;
import pages.TestCase11Page;
import util.ConfigReader;
import util.ExtentReportManager;

public class TestCase11Steps {

	private TestCase11Page tc = new TestCase11Page(DriverFactory.getDriver());

	ConfigReader configReader = new ConfigReader();

	 private ExtentTest test;

	  {
	        // Initialize a new test
		  {
		        this.test = ExtentReportManager.getTest();
		    }
	        test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
	    }

	  ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();
	
	
	
	
	
	@When("user is on home page to Verify PPK ")
	public void user_is_on_home_page_to_verify_ppk_() {


	}

	@When("The user clicks on the Add Icon to start the process to Verify PPK ")
	public void the_user_clicks_on_the_add_icon_to_start_the_process_to_verify_ppk_() {
tc.addnew1();

	}

	@Then("The user clicks on the Add Characteristic link to open the form to Verify PPK ")
	public void the_user_clicks_on_the_add_characteristic_link_to_open_the_form_to_verify_ppk_() throws InterruptedException {
tc.AddCharLink();

	}

	@Then("The user Expands the Data Group Name dropdown to view the list of data groups to Verify PPK ")
	public void the_user_expands_the_data_group_name_dropdown_to_view_the_list_of_data_groups_to_verify_ppk_() throws InterruptedException {
tc.DDN();

	}

	@Then("The user Selects the desired data group from the dropdown to Verify PPK  ")
	public void the_user_selects_the_desired_data_group_from_the_dropdown_to_verify_ppk_() throws InterruptedException {

tc.DG();
	}

	@Then("The user Opens the Part dropdown to view the list of available parts to Verify PPK  ")
	public void the_user_opens_the_part_dropdown_to_view_the_list_of_available_parts_to_verify_ppk_() throws InterruptedException {
tc.PN();

	}

	@Then("The user Selects the appropriate part from the dropdown to Verify PPK  ")
	public void the_user_selects_the_appropriate_part_from_the_dropdown_to_verify_ppk_() throws InterruptedException {

tc.PART();
	}

	@Then("The userEnters the Characteristic Name in the respective input field to Verify PPK  ")
	public void the_user_enters_the_characteristic_name_in_the_respective_input_field_to_verify_ppk_() throws InterruptedException {
tc.Char();

	}

	@Then("The user Clicks the Add button to confirm the characteristic details to Verify PPK  ")
	public void the_user_clicks_the_add_button_to_confirm_the_characteristic_details_to_verify_ppk_() throws InterruptedException {
tc.AD();

	}

	@Then("The user Inputs the Upper Spec value in the corresponding input field to Verify PPK  ")
	public void the_user_inputs_the_upper_spec_value_in_the_corresponding_input_field_to_verify_ppk_() throws InterruptedException {
Thread.sleep(2000);
		tc.upperspec();

	}

	@Then("The user Provides the Lower Spec value in the respective input field to Verify PPK  ")
	public void the_user_provides_the_lower_spec_value_in_the_respective_input_field_to_verify_ppk_() throws InterruptedException {
tc.lowerspec();

	}

	@Then("the userSpecifies the Subgroup Size to define grouping to Verify PPK  ")
	public void the_user_specifies_the_subgroup_size_to_define_grouping_to_verify_ppk_() throws InterruptedException {
tc.subsize();

	}

	@Then("user clicks on save button to save charteristics data to Verify PPK  ")
	public void user_clicks_on_save_button_to_save_charteristics_data_to_verify_ppk_() throws InterruptedException {
tc.savechar();

	}

	@Then("user clicks on control chart preference tab to Verify PPK  ")
	public void user_clicks_on_control_chart_preference_tab_to_verify_ppk_() throws InterruptedException {
tc.Histogram();

	}

	@Then("user clicks on analysis tab to verify PPK  ")
	public void user_clicks_on_analysis_tab_to_verify_ppk_() throws InterruptedException {
tc.calculation();

	}

	@Then("user clicks on CPK checkbox to verify PPK  ")
	public void user_clicks_on_cpk_checkbox_to_verify_ppk_() throws InterruptedException {

tc.PPKCH();
	}

	@Then("user Enters the CPK value to verify PPK  ")
	public void user_enters_the_cpk_value_to_verify_ppk_() throws InterruptedException {
tc.ppkvalue();

	}

	@Then("the user The user clicks the Save button to Verify PPK  ")
	public void the_user_the_user_clicks_the_save_button_to_verify_ppk_() throws InterruptedException {
tc.saveDD();

	}

	@Then("the user The user clicks the Close button to Verify PPK  ")
	public void the_user_the_user_clicks_the_close_button_to_verify_ppk_() throws InterruptedException {
tc.closechar();

	}

	@Then("the user clicks on the Files button to navigate to the sequence section  to Verify PPK  ")
	public void the_user_clicks_on_the_files_button_to_navigate_to_the_sequence_section_to_verify_ppk_() {
tc.addseqlink();

	}

	@Then("the user clicks on the expand button next to the Files icon to reveal more options to Verify PPK  ")
	public void the_user_clicks_on_the_expand_button_next_to_the_files_icon_to_reveal_more_options_to_verify_ppk_() {
tc.expand();

	}

	@Then("the user selects a group name from the grid by clicking on it to Verify PPK  ")
	public void the_user_selects_a_group_name_from_the_grid_by_clicking_on_it_to_verify_ppk_() {
tc.DDG1();

	}

	@Then("the user clicks on the arrow icon to expand the available options to Verify PPK  ")
	public void the_user_clicks_on_the_arrow_icon_to_expand_the_available_options_to_verify_ppk_() {
tc.DDd();

	}

	@Then("the user clicks on the Sequence link to open the sequence configuration page to Verify PPK  ")
	public void the_user_clicks_on_the_sequence_link_to_open_the_sequence_configuration_page_to_verify_ppk_() {
tc.Sequenc();

	}

	@Then("the user right-clicks on the sequence name to access additional options to Verify PPK  ")
	public void the_user_right_clicks_on_the_sequence_name_to_access_additional_options_to_verify_ppk_() throws InterruptedException {
tc.Sequenc1();

	}

	@Then("the user selects Edit Sequence by clicking on it to Verify PPK  ")
	public void the_user_selects_edit_sequence_by_clicking_on_it_to_verify_ppk_() {
tc.editsequence();

	}

	@Then("the user rearranges the characteristics by dragging and dropping them into the desired order to Verify PPK  ")
	public void the_user_rearranges_the_characteristics_by_dragging_and_dropping_them_into_the_desired_order_to_verify_ppk_() {
tc.draganddrop();

	}

	@Then("the user saves the changes by clicking the Save button to Verify PPK  ")
	public void the_user_saves_the_changes_by_clicking_the_save_button_to_verify_ppk_() {
tc.save();

	}

	@Then("the user closes the sequence configuration by clicking the Close button to Verify PPK  ")
	public void the_user_closes_the_sequence_configuration_by_clicking_the_close_button_to_verify_ppk_() {
tc.close1();

	}

	
	
}
