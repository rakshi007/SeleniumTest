package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.DriverFactory;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import pages.TestCase03Page;
import util.ConfigReader;
import util.ExtentReportManager;


public class Testcase03Steps {
	
	private TestCase03Page tc = new TestCase03Page(DriverFactory.getDriver());

	ConfigReader configReader = new ConfigReader();
	
	 private ExtentTest test;

	  {
	        // Initialize a new test
		  {
		        this.test = ExtentReportManager.getTest();
		    }
	        test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
	    }
	
	  ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();
	  
	
	
	@When("user clicks on the add icon to initiate adding a characteristic")
	public void user_clicks_on_the_add_icon_to_initiate_adding_a_characteristic() {
	       tc.addnew1();
	       ExtentCucumberAdapter.addTestStepLog("user clicked on add link button");
	}

	@Then("user clicks on the Add Characteristic link to proceed to the characteristic form")
	public void user_clicks_on_the_add_characteristic_link_to_proceed_to_the_characteristic_form() throws InterruptedException {
	     tc.AddCharLink();
	     ExtentCucumberAdapter.addTestStepLog("user clicked on Add characteristics link");
	}

	@Then("user clicks on the data group name dropdown to view available data groups")
	public void user_clicks_on_the_data_group_name_dropdown_to_view_available_data_groups() throws InterruptedException {
	  tc.DDN();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on datagroup dropdown");
	}

	@Then("user selects a data group from the dropdown to associate with the characteristic")
	public void user_selects_a_data_group_from_the_dropdown_to_associate_with_the_characteristic() throws InterruptedException {
	tc.DG();
	 ExtentCucumberAdapter.addTestStepLog("user selected data group from  dropdown");
	}

	@Then("user clicks on the part dropdown to view available parts")
	public void user_clicks_on_the_part_dropdown_to_view_available_parts() throws InterruptedException {
	   tc.PN();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on parts dropdown");
	}

	@Then("user selects a part from the dropdown to link with the characteristic")
	public void user_selects_a_part_from_the_dropdown_to_link_with_the_characteristic() throws InterruptedException {
	tc.PART();
	 ExtentCucumberAdapter.addTestStepLog("user selected part from part dropdown");
	}

	@Then("user enters the Characteristic Name in the input field")
	public void user_enters_the_characteristic_name_in_the_input_field() throws InterruptedException {
	tc.Char();
	 ExtentCucumberAdapter.addTestStepLog("user entered Characteristic Name in the input field");
	}

	@Then("user clicks on the add button to confirm the characteristic details")
	public void user_clicks_on_the_add_button_to_confirm_the_characteristic_details() throws InterruptedException {
	tc.AD();
	 ExtentCucumberAdapter.addTestStepLog("user entered clicked add button");
	}

	@Then("user enters the Upper Spec value in the specified input field")
	public void user_enters_the_upper_spec_value_in_the_specified_input_field() throws InterruptedException {
	Thread.sleep(2000);
	   tc.upperspec();
	   ExtentCucumberAdapter.addTestStepLog("user entered upper spec value");
	}

	@Then("user enters the Lower Spec value in the specified input field")
	public void user_enters_the_lower_spec_value_in_the_specified_input_field() throws InterruptedException {
	tc.lowerspec();
	ExtentCucumberAdapter.addTestStepLog("user entered lower spec value");
	}

	@Then("user enters the Subgroup Size value to define grouping")
	public void user_enters_the_subgroup_size_value_to_define_grouping() throws InterruptedException {
	tc.subsize();
	 ExtentCucumberAdapter.addTestStepLog("user entered subgroup size value");
	}

	@Then("user clicks on the save button to save the characteristic")
	public void user_clicks_on_the_save_button_to_save_the_characteristic() throws InterruptedException {
	tc.savechar();
	 ExtentCucumberAdapter.addTestStepLog("user clicked on  save button to save charecterstics");
	}
	private By actiontab = By.xpath("//img[@id=\"AN\"]");
	private By addicon = By.xpath("(//img[@class='imgStyle1'])[1]");
	private By Entercasue = By.xpath("//input[@id='AddCauseAction']");
	private By savecause = By.xpath("//button[@class=\"btn add\"]");


	@Then("user clicks on action tab to add action")
	public void user_clicks_on_action_tab_to_add_action() throws InterruptedException {
         tc.actiontab();
	}



	@Then("user clicks on add action icon")
	public void user_clicks_on_add_action_icon() throws InterruptedException {
    tc.addicon();
	}

	@Then("user enters action name")
	public void user_enters_action_name() throws InterruptedException {
tc.Enteraction();
	}

	@Then("user clicks on submit button")
	public void user_clicks_on_submit_button() throws InterruptedException {
  tc.saveaction();
	}


	@Then("user clicks on Control Chart Preferences to configure chart settings")
	public void user_clicks_on_control_chart_preferences_to_configure_chart_settings() throws InterruptedException {
	tc.controlcahrt();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on control chart preferences menu");
	}

	@Then("user clicks on the Analysis tab to access analysis options")
	public void user_clicks_on_the_analysis_tab_to_access_analysis_options() throws InterruptedException {
	   tc.Analisys();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on analisys tab");
	}

	@Then("user clicks on the Define Run dropdown to specify run preferences")
	public void user_clicks_on_the_define_run_dropdown_to_specify_run_preferences() throws InterruptedException {
	tc.DefieRun();
	  ExtentCucumberAdapter.addTestStepLog("user select define run from the dropdown");
	}

	@Then("user clicks on the Define Trend Down option for trend configuration")
	public void user_clicks_on_the_define_trend_down_option_for_trend_configuration() throws InterruptedException {
	tc.DefineTrend();
	  ExtentCucumberAdapter.addTestStepLog("user select define trend down from dropdown");
	}

	@Then("user clicks on the save button to save chart preferences")
	public void user_clicks_on_the_save_button_to_save_chart_preferences() throws InterruptedException {
	tc.saveDD();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on  save button to save control chart preferences");
	}

	@Then("user clicks on alarms and restrictions tab")
	public void user_clicks_on_alarms_and_restrictions_tab() throws InterruptedException {
		tc.alarmstab();
		Thread.sleep(2000);
	}

	@Then("user clicks on Force action note on out of control or alarm condition checkbox")
	public void user_clicks_on_force_action_note_on_out_of_control_or_alarm_condition_checkbox() throws InterruptedException {
		tc.restication();
	}

	@Then("user cliks on save button to save the alarms settigs")
	public void user_cliks_on_save_button_to_save_the_alarms_settigs() throws InterruptedException {
		tc.saverr();
	}




	@Then("user clicks on the close button to exit the configuration page")
	public void user_clicks_on_the_close_button_to_exit_the_configuration_page() throws InterruptedException {
	tc.closechar();
	 ExtentCucumberAdapter.addTestStepLog("user clicked closed button after saving control chart preferences");

	}

	
	
	
	//creating 
	
	
	@Then("user clicks on the configuration to access settings")
	public void user_clicks_on_the_configuration_to_access_settings() {
	       tc.clickconfiguration01();
	       ExtentCucumberAdapter.addTestStepLog("user clicked on configuration link to create parameters ");
	}

	@Then("user clicks on the Add Parameter link to add a new parameter")
	public void user_clicks_on_the_add_parameter_link_to_add_a_new_parameter() throws InterruptedException {
	tc.clickaddpara1();
	 ExtentCucumberAdapter.addTestStepLog("user clicked on add parameetr icon to create parameters ");
	}

	@Then("user enters the parameter name for the checkbox field")
	public void user_enters_the_parameter_name_for_the_checkbox_field() {
	   tc.sendparaname01();
	   ExtentCucumberAdapter.addTestStepLog("user entered parameter name");
	}

	@Then("user clicks on the Highlight Contents on Entry checkbox to enable it")
	public void user_clicks_on_the_highlight_contents_on_entry_checkbox_to_enable_it() {
	tc.Highlites();
	 ExtentCucumberAdapter.addTestStepLog("user clicked on Highlight Contents on Entry check box ");
	}

	@Then("user clicks on the save button to save the Highlight Contents on Entry parameter")
	public void user_clicks_on_the_save_button_to_save_the_highlight_contents_on_entry_parameter() {
	tc.save01();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on save button to save parameter ");
	}

	@Then("user clicks on the close button to exit the parameter configuration")
	public void user_clicks_on_the_close_button_to_exit_the_parameter_configuration() {
	   tc.close01();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on close button after saving parameter");
	}

	
//	para02
	
	
	@When("user clicks on the Add Parameter link to initiate the parameter creation process")
	public void user_clicks_on_the_add_parameter_link_to_initiate_the_parameter_creation_process() {
	tc.clickaddpara2();
	 ExtentCucumberAdapter.addTestStepLog("user clicked on add parameter link to create parameter");
	}

	@Then("user enters the parameter name in the Parameter Name input field")
	public void user_enters_the_parameter_name_in_the_parameter_name_input_field() {
	tc.sendparaname41();
	 ExtentCucumberAdapter.addTestStepLog("user entered parameter name in input textfiled ");
	}

	@Then("user selects the Increment radio button to enable increment automation")
	public void user_selects_the_increment_radio_button_to_enable_increment_automation() throws InterruptedException {
	tc.incrementradio();
	 ExtentCucumberAdapter.addTestStepLog("user clicked on increment radio button");
	}

	

	@Then("user clicks on the Go button to proceed with the parameter configuration")
	public void user_clicks_on_the_go_button_to_proceed_with_the_parameter_configuration() throws InterruptedException {
	    tc.go();
	    ExtentCucumberAdapter.addTestStepLog("user clicked on go button");
	}




	@Then("user enters the prefix value in the Prefix input field")
	public void user_enters_the_prefix_value_in_the_prefix_input_field() {
	   tc.Prefix();
	   ExtentCucumberAdapter.addTestStepLog("user user enters prefix value");
	}

	@Then("user enters the start value in the Start Value input field")
	public void user_enters_the_start_value_in_the_start_value_input_field() {
	tc.StartValue();
	 ExtentCucumberAdapter.addTestStepLog("user user enters start value");
	}

	@Then("user enters the increment value in the Increment Value input field")
	public void user_enters_the_increment_value_in_the_increment_value_input_field() {
	   tc.Increment();
	   ExtentCucumberAdapter.addTestStepLog("user user enters increment value");
	}

	@Then("user enters the suffix value in the Suffix input field")
	public void user_enters_the_suffix_value_in_the_suffix_input_field() {
	   tc.Suffix();
	   ExtentCucumberAdapter.addTestStepLog("user user enters suffix value");
	}

	@Then("user clicks on the Save button to save the increment-automated parameter")
	public void user_clicks_on_the_save_button_to_save_the_increment_automated_parameter() {
	tc.saveP();
	 ExtentCucumberAdapter.addTestStepLog("user clicked on save button to save increment-automated parameter");
	}

	@Then("user clicks on the Close button to finalize and exit the parameter configuration")
	public void user_clicks_on_the_close_button_to_finalize_and_exit_the_parameter_configuration() throws InterruptedException {
	   tc.closeC();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on close button after saving parameter ");
Thread.sleep(1000);
	}

	
	//para to part
	
	
	@Given("the user initiates the parameter addition process by clicking the Files icon01.")
	public void the_user_initiates_the_parameter_addition_process_by_clicking_the_files_icon01() {
	   tc.filesicon();
	}

	@When("the user clicks the Add icon to begin adding a new parameter01.")
	public void the_user_clicks_the_add_icon_to_begin_adding_a_new_parameter01() {
	   tc.Addptp();
	}

	@Then("the user verifies the assignment by clicking the Assign Parameter to Part link01.")
	public void the_user_verifies_the_assignment_by_clicking_the_assign_parameter_to_part_link01() {
	 tc.Assignparaicon();
	}

	@Then("the user views available groups by clicking the Group dropdown01.")
	public void the_user_views_available_groups_by_clicking_the_group_dropdown01() {
	   tc.datadropdown();
	}

	@Then("the user selects the appropriate data group from the dropdown01.")
	public void the_user_selects_the_appropriate_data_group_from_the_dropdown01() {
	  tc.selectgrp();
	}

	@Then("views available parts by clicking the Part dropdown01.")
	public void views_available_parts_by_clicking_the_part_dropdown01() {
	  tc.partdropdown();
	}

	@Then("the user selects the part to which the parameter will be added01.")
	public void the_user_selects_the_part_to_which_the_parameter_will_be_added01() {
	 tc.selectpartpara();
	}

	@Then("drags and drops previously used parameters into the part01.")
	public void drags_and_drops_previously_used_parameters_into_the_part01() {
	   tc.checkallbox();
	}

	@Then("the user drags and drops the required parameter into the part01.")
	public void the_user_drags_and_drops_the_required_parameter_into_the_part01() {
	  tc.checkallbox1();
	}

	@Then("confirms the addition by clicking the Save button01.")
	public void confirms_the_addition_by_clicking_the_save_button01() {
	   tc.saveassign();
	}
	@Then("the user clicks the Assign button to save the parameters.")
	public void the_user_clicks_the_assign_button_to_save_the_parameters() throws InterruptedException {
		Thread.sleep(2000);
	  tc.assignlink();
	}
	@Then("the user completes the process by clicking the Close button01.")
	public void the_user_completes_the_process_by_clicking_the_close_button01() {
	   tc.closeassign();
	}

	
	
	
	
	
	
	//sequence
	
	
	
	@Given("the user clicks on the Files button01.")
	public void the_user_clicks_on_the_files_button01() {
	  tc.addseqlink();
	}

	@When("the user expands the Files menu by clicking the expand button next to the Files icon01.")
	public void the_user_expands_the_files_menu_by_clicking_the_expand_button_next_to_the_files_icon01() {
	   tc.expand();
	}

	@Then("the user selects a group name from the grid by clicking on it01.")
	public void the_user_selects_a_group_name_from_the_grid_by_clicking_on_it01() {
	   tc.DDG1();
	}

	@Then("expands the options by clicking the arrow icon01.")
	public void expands_the_options_by_clicking_the_arrow_icon01() {
	tc.DDd();
	}

	@Then("the user opens the sequence by clicking the Sequence link01.")
	public void the_user_opens_the_sequence_by_clicking_the_sequence_link01() {
	tc.Sequenc();
	}

	@Then("accesses additional options by right-clicking on the sequence name01.")
	public void accesses_additional_options_by_right_clicking_on_the_sequence_name01() throws InterruptedException {
	    tc.Sequenc1();
	}

	@Then("the user selects Edit Sequence from the context menu01.")
	public void the_user_selects_edit_sequence_from_the_context_menu01() {
	   tc.editsequence();
	}

	@Then("rearranges the characteristics by dragging and dropping them01.")
	public void rearranges_the_characteristics_by_dragging_and_dropping_them01() {
		tc.draganddrop();
	}

	@Then("the user saves the changes by clicking the Save button01.")
	public void the_user_saves_the_changes_by_clicking_the_save_button01() {
     tc.save();

	}

	@Then("completes the process by clicking the Close button01.")
	public void completes_the_process_by_clicking_the_close_button01() {
		tc.close1();
	}



	
	
	
	
	
	
	
	
	
	
	//
	@Then("user clicks on the page name to edit the chart")
	public void user_clicks_on_the_page_name_to_edit_the_chart() {
	
	   
	}

	@Then("user clicks on the Edit icon to access the chart edit options")
	public void user_clicks_on_the_edit_icon_to_access_the_chart_edit_options() {
	
	   
	}

	@Then("user clicks on the Date input field to modify the date")
	public void user_clicks_on_the_date_input_field_to_modify_the_date() {
	
	   
	}

	@Then("user clicks on the Time input field to modify the time")
	public void user_clicks_on_the_time_input_field_to_modify_the_time() {
	
	   
	}

	@Then("user enters value for sub group one")
	public void user_enters_value_for_sub_group_one() {
	
	   
	}

	@Then("user enters value for sub group two")
	public void user_enters_value_for_sub_group_two() {
	
	   
	}

	@Then("user enters value for sub group three")
	public void user_enters_value_for_sub_group_three() {
	
	   
	}

	@Then("user enters value for sub group four")
	public void user_enters_value_for_sub_group_four() {
	
	   
	}
	

   @Then("user enters values for Highlight Contents on Entry")
   public void user_enters_values_for_highlight_contents_on_entry() {
   
   }

	@Then("user hovers over the Highlight Contents on Entry parameter for review")
	public void user_hovers_over_the_highlight_contents_on_entry_parameter_for_review() {
	
	   
	}

	@Then("user saves the changes for the Chart by clicking on the Save button")
	public void user_saves_the_changes_for_the_chart_by_clicking_on_the_save_button() {
	
	   
	}

	@Then("user verifies the update by checking the pages  for the latest changes")
	public void user_verifies_the_update_by_checking_the_pages__for_the_latest_changes() {
	
	   
	}

	@Then("user clicks on the Time input field for Chart")
	public void user_clicks_on_the_time_input_field_for_chart() {
	
	   
	}

	@Then("user enters the first subgroup size for Chart")
	public void user_enters_the_first_subgroup_size_for_chart() {
	
	   
	}

	@Then("user enters the second subgroup size for Chart")
	public void user_enters_the_second_subgroup_size_for_chart() {
	
	   
	}

	@Then("user enters the third subgroup size for Chart")
	public void user_enters_the_third_subgroup_size_for_chart() {
	
	   
	}

	@Then("user enters the fourth subgroup size for Chart")
	public void user_enters_the_fourth_subgroup_size_for_chart() {
	
	   
	}

	@Then("user clicks on the Save button for the Chart and confirms the update")
	public void user_clicks_on_the_save_button_for_the_chart_and_confirms_the_update() {
	
	   
	}

	@Then("user validates the page  to check if the changes have been reflected")
	public void user_validates_the_page__to_check_if_the_changes_have_been_reflected() {
	
	   
	}




}
