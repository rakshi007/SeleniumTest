package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.DriverFactory;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.TestCase08Page;
import util.ConfigReader;
import util.ExtentReportManager;

public class TestStatus08 {

	private TestCase08Page tc = new TestCase08Page(DriverFactory.getDriver());

	ConfigReader configReader = new ConfigReader();


	 private ExtentTest test;

	  {
	        // Initialize a new test
		  {
		        this.test = ExtentReportManager.getTest();
		    }
	        test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
	    }

	  ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();

	@When("user clicks on network icon to verify  to verify Out of Specification")
	public void user_clicks_on_network_icon_to_verify_to_verify_out_of_specification() throws InterruptedException {
		Thread.sleep(2000);


	}
	@Then("user clicks on page name for edit to verify  Out of Specification")
	public void user_clicks_on_page_name_for_edit_to_verify_out_of_specification() {
		tc.clickvaripage();
	}
	@Then("user clicks on edit icon to verify  Out of Specification")
	public void user_clicks_on_edit_icon_to_verify_out_of_specification() {
		tc.editpencil();
	}
	@When("user clicks on date input field  to verify Out of Specification")
	public void user_clicks_on_date_input_field_to_verify_out_of_specification() {
		tc.date();
	}
	@Then("user clicks on time1 input field  to verify Out of Specification")
	public void user_clicks_on_time1_input_field_to_verify_out_of_specification() {
		tc.time();
	}
	@Then("user enters subgroup size for one11  to verify Out of Specification")
	public void user_enters_subgroup_size_for_one11_to_verify_out_of_specification() {
		tc.subgroup01();
	}
	@Then("user enters subgroup size for two12  to verify Out of Specification")
	public void user_enters_subgroup_size_for_two12_to_verify_out_of_specification() {
		tc.subgroup02();
	}
	@Then("user fetch the parameters values to verify Out of Specification")
	public void user_fetch_the_parameters_values_to_verify_out_of_specification() {
		tc.default01();
	}
	@Then("user clicks on save button for chart1  to verify Out of Specification")
	public void user_clicks_on_save_button_for_chart1_to_verify_out_of_specification() {
		tc.savechart01();
	}
	@Then("user fetches the {int} of the page  to verify Out of Specification")
	public void user_fetches_the_of_the_page_to_verify_out_of_specification(Integer int1) {
		tc.getText();
	}
	//02

	@When("user clicks on time2 input field  to verify Out of Specification")
	public void user_clicks_on_time2_input_field_to_verify_out_of_specification() throws InterruptedException {
		Thread.sleep(1000);
		tc.time2();
	}
	@Then("user enters subgroup size for one21  to verify Out of Specification")
	public void user_enters_subgroup_size_for_one21_to_verify_out_of_specification() {
		tc.subgroup11();
	}
	@Then("user enters subgroup size for two22 to verify Out of Specification")
	public void user_enters_subgroup_size_for_two22_to_verify_out_of_specification() throws InterruptedException {
		tc.subgroup12();
	}
	@Then("user enters parameter value in always clear field01 to verify Out of Specification")
	public void user_enters_parameter_value_in_always_clear_field01_to_verify_out_of_specification() {
		tc.ALL1();
	}

	@Then("user fetches the validation data01  to verify Out of Specification")
	public void user_fetches_the_validation_data01_to_verify_out_of_specification() {
		tc.validateDataValues01();
	}
	@Then("user clicks on save button for chart2  to verify Out of Specification")
	public void user_clicks_on_save_button_for_chart2_to_verify_out_of_specification() throws InterruptedException {
		tc.Savechart02();
	}


	@Then("user fetches the page status02  to verify Out of Specification")
	public void user_fetches_the_page_status02_to_verify_out_of_specification() {
		tc.GetText02();
	}
	@When("user clicks on time3 input field  to verify Out of Specification")
	public void user_clicks_on_time3_input_field_to_verify_out_of_specification() throws InterruptedException {
		Thread.sleep(1000);
		tc.time3();
	}
	@Then("user enters subgroup size for one31  to verify Out of Specification")
	public void user_enters_subgroup_size_for_one31_to_verify_out_of_specification() {
		tc.subgroup31();
	}
	@Then("user enters subgroup size for two32 to verify Out of Specification")
	public void user_enters_subgroup_size_for_two32_to_verify_out_of_specification() {
		tc.subgroup32();
	}
	@Then("user fetches the validation data02  to verify Out of Specification")
	public void user_fetches_the_validation_data02_to_verify_out_of_specification() {
		tc.validateDataValues02();
	}
	@Then("user enters parameter value in always clear field02 to verify Out of Specification")
	public void user_enters_parameter_value_in_always_clear_field02_to_verify_out_of_specification() {
		tc.ALL2();
	}
	@Then("user clicks on save button for chart3  to verify Out of Specification")
	public void user_clicks_on_save_button_for_chart3_to_verify_out_of_specification() {
		tc.savechart331();
	}


	@Then("user fetches the page status03  to verify Out of Specification")
	public void user_fetches_the_page_status03_to_verify_out_of_specification() {
		tc.getText3();
	}

	@When("user clicks on time4 input field  to verify Out of Specification")
	public void user_clicks_on_time4_input_field_to_verify_out_of_specification() throws InterruptedException {
		Thread.sleep(2000);
		tc.time4();
	}
	@Then("user enters subgroup size for one41  to verify Out of Specification")
	public void user_enters_subgroup_size_for_one41_to_verify_out_of_specification() {
		tc.subgroup41();
	}
	@Then("user enters subgroup size for two42  to verify Out of Specification")
	public void user_enters_subgroup_size_for_two42_to_verify_out_of_specification() {
		tc.subgroup42();
	}
	@Then("user enters data values in parameters to verify Out of Specification")
	public void user_enters_data_values_in_parameters_to_verify_out_of_specification() {
		tc.default02();
	}
	@Then("user fetches the validation data03  to verify Out of Specification")
	public void user_fetches_the_validation_data03_to_verify_out_of_specification() {
		tc.validateDataValues03();
	}
	@Then("user clicks on save button for chart4  to verify Out of Specification")
	public void user_clicks_on_save_button_for_chart4_to_verify_out_of_specification() {
		tc.savechart4();
	}

	@Then("user fetches the page status04  to verify Out of Specification")
	public void user_fetches_the_page_status04_to_verify_out_of_specification() {
		tc.getText4();
	}

	@When("user clicks on time5 input field  to verify Out of Specification")
	public void user_clicks_on_time5_input_field_to_verify_out_of_specification() throws InterruptedException {
		Thread.sleep(1000);
		tc.time5();
	}
	@Then("user enters subgroup size for one51  to verify Out of Specification")
	public void user_enters_subgroup_size_for_one51_to_verify_out_of_specification() {
		tc.subgroup41();
	}
	@Then("user enters subgroup size for two52  to verify Out of Specification")
	public void user_enters_subgroup_size_for_two52_to_verify_out_of_specification() {
		tc.subgroup42();
	}
	@Then("user enters parameter value in always clear field03 to verify Out of Specification")
	public void user_enters_parameter_value_in_always_clear_field03_to_verify_out_of_specification() throws InterruptedException {
		tc.ALL3();
	}
	@Then("user fetches the validation data53  to verify Out of Specification")
	public void user_fetches_the_validation_data53_to_verify_out_of_specification() {
		tc.validateDataValues04();
	}
	@Then("user clicks on save button for chart54  to verify Out of Specification")
	public void user_clicks_on_save_button_for_chart54_to_verify_out_of_specification() throws InterruptedException {
		tc.savechart5();
	}

	@Then("user fetches the page status05  to verify Out of Specification")
	public void user_fetches_the_page_status05_to_verify_out_of_specification() {
		tc.getText5();
	}

	@When("user clicks on time6 input field  to verify Out of Specification")
	public void user_clicks_on_time6_input_field_to_verify_out_of_specification() throws InterruptedException {
		Thread.sleep(2000);
		tc.time6();
	}
	@Then("user enters subgroup size for one61  to verify Out of Specification")
	public void user_enters_subgroup_size_for_one61_to_verify_out_of_specification() {
		tc.subgroup61();
	}
	@Then("user enters subgroup size for two62  to verify Out of Specification")
	public void user_enters_subgroup_size_for_two62_to_verify_out_of_specification() throws InterruptedException {

		Thread.sleep(2000);
		tc.subgroup62();
	}

	@Then("user enters parameter value in always clear field04 to verify Out of Specification")
	public void user_enters_parameter_value_in_always_clear_field04_to_verify_out_of_specification() throws InterruptedException {
		tc.ALL4();
	}
	@Then("user fetches the validation data05  to verify Out of Specification")
	public void user_fetches_the_validation_data05_to_verify_out_of_specification() {
		tc.validateDataValues05();
	}
	@Then("user clicks on save button for chart6  to verify Out of Specification")
	public void user_clicks_on_save_button_for_chart6_to_verify_out_of_specification() throws InterruptedException {
		tc.savechart6();
	}


	@Then("user clicks on ok button to enter user note to verify out of specification")
	public void user_clicks_on_ok_button_to_enter_user_note_to_verify_out_of_specification() throws InterruptedException {
		tc.ok();
		
	}

	@Then("user enters username input field to verify out of specification")
	public void user_enters_username_input_field_to_verify_out_of_specification() throws InterruptedException {
		tc.user01();
		
	}

	@Then("user select cause from dropdown to verify out of specification")
	public void user_select_cause_from_dropdown_to_verify_out_of_specification() throws InterruptedException {
		tc.cause();
		
	}

	@Then("user select action from dropdown to verify out of specification")
	public void user_select_action_from_dropdown_to_verify_out_of_specification() throws InterruptedException {
		tc.action();
		
	}

	@Then("user enetr user note in given text field to verify out of specification")
	public void user_enetr_user_note_in_given_text_field_to_verify_out_of_specification() throws InterruptedException {
		tc.usernote();
		
	}

	@Then("user clicks on add button to add note and to  verify out of specification")
	public void user_clicks_on_add_button_to_add_note_and_to_verify_out_of_specification() throws InterruptedException {
		
		tc.add01();
	}

	@Then("user enters username02 input field to verify out of specification")
	public void user_enters_username02_input_field_to_verify_out_of_specification() throws InterruptedException {
		
		tc.user02();
	}

	@Then("user select cause02 from dropdown to verify out of specification")
	public void user_select_cause02_from_dropdown_to_verify_out_of_specification() throws InterruptedException {
		tc.cause2();
		
	}

	@Then("user select action02 from dropdown to verify out of specification")
	public void user_select_action02_from_dropdown_to_verify_out_of_specification() throws InterruptedException {
		tc.action2();
		
	}

	@Then("user enetr user note02 in given text field to verify out of specification")
	public void user_enetr_user_note02_in_given_text_field_to_verify_out_of_specification() throws InterruptedException {
		tc.usernote2();

	}

	@Then("user clicks on add button02 to add note and to  verify out of specification")
	public void user_clicks_on_add_button02_to_add_note_and_to_verify_out_of_specification() throws InterruptedException {
		tc.add02();
		
	}



	@Then("user enters username03 input field to verify out of specification")
	public void user_enters_username03_input_field_to_verify_out_of_specification() throws InterruptedException {
		tc.user03();
	}

	@Then("user select cause03 from dropdown to verify out of specification")
	public void user_select_cause03_from_dropdown_to_verify_out_of_specification() throws InterruptedException {
		tc.cause3();
		
	}

	@Then("user select actions03 from dropdown to verify out of specification")
	public void user_select_actions03_from_dropdown_to_verify_out_of_specification() throws InterruptedException {
		tc.action3();
	}

	@Then("user enter user note03 in given text field to verify out of specification")
	public void user_enter_user_note03_in_given_text_field_to_verify_out_of_specification() throws InterruptedException {
		tc.usernote3();
	}



	@Then("user click on add button to verify out of specification")
	public void user_click_on_add_button_to_verify_out_of_specification() throws InterruptedException {
    tc.add03();

	}

	@Then("user click on remeasure button to verify out of specification")
	public void user_click_on_remeasure_button_to_verify_out_of_specification() throws InterruptedException {
        tc.Remeasure();
	}

	@Then("user adding remeasure data01 to verify out of specification")
	public void user_adding_remeasure_data01_to_verify_out_of_specification() throws InterruptedException {
   tc.Add01();
	}

	@Then("user adding remeasure data02 to verify out of specification")
	public void user_adding_remeasure_data02_to_verify_out_of_specification() throws InterruptedException {
 tc.Add02();
	}

	@Then("user click on calculate button to verify out of specification")
	public void user_click_on_calculate_button_to_verify_out_of_specification() throws InterruptedException {
     tc.Calculate();
	}

	@Then("user click on save button for remeasure action to verify out of specification")
	public void user_click_on_save_button_for_remeasure_action_to_verify_out_of_specification() throws InterruptedException {
      tc.SavereMeasure();
	}


	@Then("user clicks on sumbit button to add notes")
	public void user_clicks_on_sumbit_button_to_add_notes() throws InterruptedException {
		tc.submitnote();
		
	}
	@Then("user clicks on close button and add notes user")
	public void user_clicks_on_close_button_and_add_notes_user() throws InterruptedException {
       tc.closebutton();
	}

	@Then("user clicks on yes button to verify out of specification")
	public void user_clicks_on_yes_button_to_verify_out_of_specification() throws InterruptedException {
          tc.yesbutton();
	}

	@Then("user clicks on edit icon to add edit delete notes")
	public void user_clicks_on_edit_icon_to_add_edit_delete_notes() {
           tc.Edit08();
	}

	@Then("user clicks on slash button to verify user note")
	public void user_clicks_on_slash_button_to_verify_user_note() throws InterruptedException {
	Thread.sleep(1000);
		tc.backward();
	}

	@Then("user clicks on note icon to add delete edit notes")
	public void user_clicks_on_note_icon_to_add_delete_edit_notes() throws InterruptedException {
		
		tc.note();
	}

	@Then("user clicks on delete button to delete note")
	public void user_clicks_on_delete_button_to_delete_note() throws InterruptedException {
		
		tc.deletenote();
	}

	@Then("user clicks on ok button to delete note")
	public void user_clicks_on_ok_button_to_delete_note() throws InterruptedException {
	tc.oknote();
	}


	@Then("user enter user name in textput field")
	public void user_enter_user_name_in_textput_field() throws InterruptedException {
		tc.user04();

		
	}

	@Then("user select new cause from cause dropdown")
	public void user_select_new_cause_from_cause_dropdown() throws InterruptedException {
		tc.cause4();

	}

	@Then("user select new action note from action dropdown")
	public void user_select_new_action_note_from_action_dropdown() throws InterruptedException {
		tc.action4();
		
	}

	@Then("user user enter user note02")
	public void user_user_enter_user_note02() throws InterruptedException {
		tc.usernote4();
		
	}

	@Then("user clicks on save button to save new note")
	public void user_clicks_on_save_button_to_save_new_note() throws InterruptedException {
		
		tc.savechart7();
	}



	@Then("user fetches the page status06  to verify Out of Specification")
	public void user_fetches_the_page_status06_to_verify_out_of_specification() {
		tc.getText6();
	}
	@Then("user fetches the validation data06  to verify Out of Specification")
	public void user_fetches_the_validation_data06_to_verify_out_of_specification() {
		tc.validateDataValues06();
	}









}
