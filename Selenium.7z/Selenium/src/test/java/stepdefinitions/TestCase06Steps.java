package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.DriverFactory;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.TestCase06Page;
import util.ConfigReader;
import util.ExtentReportManager;

public class TestCase06Steps {

	
	
	private TestCase06Page tc = new TestCase06Page(DriverFactory.getDriver());

	ConfigReader configReader = new ConfigReader();

	 private ExtentTest test;

	  {
	        // Initialize a new test
		  {
		        this.test = ExtentReportManager.getTest();
		    }
	        test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
	    }

	  ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();

	
	
	
	
	
	
	@When("The user clicks on the Add Icon to start the process Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_add_icon_to_start_the_process_shift_up(Integer int1, Integer int2) {
tc.addnew1();

	}

	@Then("The user clicks on the Add Characteristic link to open the form Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_add_characteristic_link_to_open_the_form_shift_up(Integer int1, Integer int2) throws InterruptedException {

tc.AddCharLink();
	}

	@Then("The user Expands the Data Group Name dropdown to view the list of data groups Shift {int}\\/{int} Up")
	public void the_user_expands_the_data_group_name_dropdown_to_view_the_list_of_data_groups_shift_up(Integer int1, Integer int2) throws InterruptedException {
tc.DDN();

	}

	@Then("The user Selects the desired data group from the dropdown Shift {int}\\/{int} Up")
	public void the_user_selects_the_desired_data_group_from_the_dropdown_shift_up(Integer int1, Integer int2) throws InterruptedException {
tc.DG();

	}

	@Then("The user Opens the Part dropdown to view the list of available parts Shift {int}\\/{int} Up")
	public void the_user_opens_the_part_dropdown_to_view_the_list_of_available_parts_shift_up(Integer int1, Integer int2) throws InterruptedException {
tc.PN();

	}

	@Then("The user Selects the appropriate part from the dropdown Shift {int}\\/{int} Up")
	public void the_user_selects_the_appropriate_part_from_the_dropdown_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.PART();

	}

	@Then("The userEnters the Characteristic Name in the respective input field Shift {int}\\/{int} Up")
	public void the_user_enters_the_characteristic_name_in_the_respective_input_field_shift_up(Integer int1, Integer int2) throws InterruptedException {
tc.Char();

	}

	@Then("The user Clicks the Add button to confirm the characteristic details Shift {int}\\/{int} Up")
	public void the_user_clicks_the_add_button_to_confirm_the_characteristic_details_shift_up(Integer int1, Integer int2) throws InterruptedException {

tc.AD();
	}

	@Then("The user Inputs the Upper Spec value in the corresponding input field Shift {int}\\/{int} Up")
	public void the_user_inputs_the_upper_spec_value_in_the_corresponding_input_field_shift_up(Integer int1, Integer int2) throws InterruptedException {
Thread.sleep(2000);
		tc.upperspec();

	}

	@Then("The user Provides the Lower Spec value in the respective input field Shift {int}\\/{int} Up")
	public void the_user_provides_the_lower_spec_value_in_the_respective_input_field_shift_up(Integer int1, Integer int2) throws InterruptedException {
tc.lowerspec();

	}

	@Then("the userSpecifies the Subgroup Size to define grouping Shift {int}\\/{int} Up")
	public void the_user_specifies_the_subgroup_size_to_define_grouping_shift_up(Integer int1, Integer int2) throws InterruptedException {

tc.subsize();
	}

	@Then("the user The user clicks the Save button to save the characteristic details Shift {int}\\/{int} Up")
	public void the_user_the_user_clicks_the_save_button_to_save_the_characteristic_details_shift_up(Integer int1, Integer int2) throws InterruptedException {
tc.savechar();

	}

	@Then("the user Clicks on Control Chart Preferences to open chart configuration settings Shift {int}\\/{int} Up")
	public void the_user_clicks_on_control_chart_preferences_to_open_chart_configuration_settings_shift_up(Integer int1, Integer int2) throws InterruptedException {
tc.controlchart();

	}

	@Then("the user Accesses the Analysis Tab to view analysis options Shift {int}\\/{int} Up")
	public void the_user_accesses_the_analysis_tab_to_view_analysis_options_shift_up(Integer int1, Integer int2) throws InterruptedException {

tc.Analisys();
	}
	
	
	@Then("user click on shift analysis check box to validate Shift {int}\\/{int} Up")
	public void user_click_on_shift_analysis_check_box_to_validate_shift_up(Integer int1, Integer int2) throws InterruptedException {
	  tc.shiftyup();
	}

	@Then("the user Clicks on the Define Run dropdown and selects the desired option Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_define_run_dropdown_and_selects_the_desired_option_shift_up(Integer int1, Integer int2) throws InterruptedException {
tc.DefieRun();

	}

	@Then("the user Configures the trend by selecting the Define Trend Down option Shift {int}\\/{int} Up")
	public void the_user_configures_the_trend_by_selecting_the_define_trend_down_option_shift_up(Integer int1, Integer int2) throws InterruptedException {

tc.DefineTrend();
	}

	@Then("the user The user clicks the Save button to save the configured chart preferences Shift {int}\\/{int} Up")
	public void the_user_the_user_clicks_the_save_button_to_save_the_configured_chart_preferences_shift_up(Integer int1, Integer int2) throws InterruptedException {
tc.saveDD();

	}

	@Then("the user The user clicks the Close button to exit the configuration page Shift {int}\\/{int} Up")
	public void the_user_the_user_clicks_the_close_button_to_exit_the_configuration_page_shift_up(Integer int1, Integer int2) throws InterruptedException {
tc.closechar();

	}

	@Then("the user navigates to Settings by clicking the Configuration option to validate Shift {int}\\/{int} Up")
	public void the_user_navigates_to_settings_by_clicking_the_configuration_option_to_validate_shift_up(Integer int1, Integer int2) {

tc.clickconfiguration01();
	}

	@When("the user initiates the parameter creation process by clicking on the Add Parameter link  to validate Shift {int}\\/{int} Up")
	public void the_user_initiates_the_parameter_creation_process_by_clicking_on_the_add_parameter_link_to_validate_shift_up(Integer int1, Integer int2) throws InterruptedException {

tc.clickaddpara1();
	}

	@Then("the user enters a name in the Parameter Name input field to validate Shift {int}\\/{int} Up")
	public void the_user_enters_a_name_in_the_parameter_name_input_field_to_validate_shift_up(Integer int1, Integer int2) {
tc.sendparaname01();

	}

	@Then("the user enables the functionality by selecting identity radio button to validate Shift {int}\\/{int} Up")
	public void the_user_enables_the_functionality_by_selecting_identity_radio_button_to_validate_shift_up(Integer int1, Integer int2) throws InterruptedException {
tc.identity();

	}


	@Then("the user saves the parameter configuration by clicking the Save button to validate Shift {int}\\/{int} Up")
	public void the_user_saves_the_parameter_configuration_by_clicking_the_save_button_to_validate_shift_up(Integer int1, Integer int2) {
		tc.save01();

	}

	@Then("the user finalizes the process by clicking the Close button to validate Shift {int}\\/{int} Up")
	public void the_user_finalizes_the_process_by_clicking_the_close_button_to_validate_shift_up(Integer int1, Integer int2) {

		tc.close01();
	}

	
	
	@Then("the user clicks on the Files icon to initiate the process of adding a parameter to the part to validate Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_files_icon_to_initiate_the_process_of_adding_a_parameter_to_the_part_to_validate_shift_up(Integer int1, Integer int2) throws InterruptedException {
	 tc.filesicon();

	}

	@Then("the user clicks on the Add icon to start the parameter addition process to validate Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_add_icon_to_start_the_parameter_addition_process_to_validate_shift_up(Integer int1, Integer int2) {
	 tc.Addptp();

	}

	@Then("the user verifies the assignment by clicking on the Assign Parameter to Part link to validate Shift {int}\\/{int} Up")
	public void the_user_verifies_the_assignment_by_clicking_on_the_assign_parameter_to_part_link_to_validate_shift_up(Integer int1, Integer int2) {
	 tc.Assignparaicon();

	}

	@Then("the user clicks on the Group dropdown to view the available groups to validate Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_group_dropdown_to_view_the_available_groups_to_validate_shift_up(Integer int1, Integer int2) {
	 tc.datadropdown();

	}

	@Then("the user selects the data group from the dropdown to specify the group to validate Shift {int}\\/{int} Up")
	public void the_user_selects_the_data_group_from_the_dropdown_to_specify_the_group_to_validate_shift_up(Integer int1, Integer int2) {
	 tc.selectgrp();

	}

	@Then("the user clicks on the Part dropdown to view the available parts to validate Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_part_dropdown_to_view_the_available_parts_to_validate_shift_up(Integer int1, Integer int2) {
	tc.partdropdown(); 

	}

	@Then("the user selects the part to which the parameter will be added to validate Shift {int}\\/{int} Up")
	public void the_user_selects_the_part_to_which_the_parameter_will_be_added_to_validate_shift_up(Integer int1, Integer int2) {
	 tc.selectpartpara();

	}

	@Then("the user drags and drops the previously used parameters into the part to validate Shift {int}\\/{int} Up")
	public void the_user_drags_and_drops_the_previously_used_parameters_into_the_part_to_validate_shift_up(Integer int1, Integer int2) {
	 tc.checkallbox1();

	}

	@Then("the user drags and drops the required parameter into the part to validate Shift {int}\\/{int} Up")
	public void the_user_drags_and_drops_the_required_parameter_into_the_part_to_validate_shift_up(Integer int1, Integer int2) {
	 tc.checkallbox();

	}

	@Then("the user confirms the addition of the parameter by clicking on the Save button to validate Shift {int}\\/{int} Up")
	public void the_user_confirms_the_addition_of_the_parameter_by_clicking_on_the_save_button_to_validate_shift_up(Integer int1, Integer int2) {
	 tc.saveassign();

	}

	@Then("the user exits the parameter addition process by clicking the Close button to validate Shift {int}\\/{int} Up")
	public void the_user_exits_the_parameter_addition_process_by_clicking_the_close_button_to_validate_shift_up(Integer int1, Integer int2) {
	 tc.closeassign();

	}

	
	
	
	
	
	@Then("the user clicks on the Files button to navigate to the sequence section Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_files_button_to_navigate_to_the_sequence_section_shift_up(Integer int1, Integer int2) {
tc.addseqlink();

	}

	@Then("the user clicks on the expand button next to the Files icon to reveal more options Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_expand_button_next_to_the_files_icon_to_reveal_more_options_shift_up(Integer int1, Integer int2) {
tc.expand();

	}

	@Then("the user selects a group name from the grid by clicking on it Shift {int}\\/{int} Up")
	public void the_user_selects_a_group_name_from_the_grid_by_clicking_on_it_shift_up(Integer int1, Integer int2) {
tc.DDG1();

	}

	@Then("the user clicks on the arrow icon to expand the available options Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_arrow_icon_to_expand_the_available_options_shift_up(Integer int1, Integer int2) {
tc.DDd();

	}

	@Then("the user clicks on the Sequence link to open the sequence configuration page Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_sequence_link_to_open_the_sequence_configuration_page_shift_up(Integer int1, Integer int2) {
tc.Sequenc();

	}

	@Then("the user right-clicks on the sequence name to access additional options Shift {int}\\/{int} Up")
	public void the_user_right_clicks_on_the_sequence_name_to_access_additional_options_shift_up(Integer int1, Integer int2) throws InterruptedException {

tc.Sequenc1();
	}

	@Then("the user selects Edit Sequence by clicking on it Shift {int}\\/{int} Up")
	public void the_user_selects_edit_sequence_by_clicking_on_it_shift_up(Integer int1, Integer int2) {

tc.editsequence();
	}

	@Then("the user rearranges the characteristics by dragging and dropping them into the desired order Shift {int}\\/{int} Up")
	public void the_user_rearranges_the_characteristics_by_dragging_and_dropping_them_into_the_desired_order_shift_up(Integer int1, Integer int2) {
tc.draganddrop();

	}

	@Then("the user saves the changes by clicking the Save button Shift {int}\\/{int} Up")
	public void the_user_saves_the_changes_by_clicking_the_save_button_shift_up(Integer int1, Integer int2) {

tc.save();
	}

	@Then("the user closes the sequence configuration by clicking the Close button Shift {int}\\/{int} Up")
	public void the_user_closes_the_sequence_configuration_by_clicking_the_close_button_shift_up(Integer int1, Integer int2) {
tc.close1();

	}



}
