package stepdefinitions;

import org.openqa.selenium.By;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.DriverFactory;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.TestCase05Page;
import util.ConfigReader;
import util.ExtentReportManager;

public class TestCase05Steps {

	private TestCase05Page tc = new TestCase05Page(DriverFactory.getDriver());

	ConfigReader configReader = new ConfigReader();

	 private ExtentTest test;

	  {
	        // Initialize a new test
		  {
		        this.test = ExtentReportManager.getTest();
		    }
	        test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
	    }

	  ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();

	
	
	
	
@When("The user clicks on the Add Icon to start the process.")
public void the_user_clicks_on_the_add_icon_to_start_the_process() {
   tc.addnew1();
}

@Then("The user clicks on the Add Characteristic link to open the form.")
public void the_user_clicks_on_the_add_characteristic_link_to_open_the_form() throws InterruptedException  {
   tc.AddCharLink();
}

@Then("The user Expands the Data Group Name dropdown to view the list of data groups.")
public void the_user_expands_the_data_group_name_dropdown_to_view_the_list_of_data_groups() throws InterruptedException {
   tc.DDN();
}

@Then("The user Selects the desired data group from the dropdown.")
public void the_user_selects_the_desired_data_group_from_the_dropdown() throws InterruptedException {
   tc.DG();
}

@Then("The user Opens the Part dropdown to view the list of available parts.")
public void the_user_opens_the_part_dropdown_to_view_the_list_of_available_parts() throws InterruptedException {
   tc.PN();
}

@Then("The user Selects the appropriate part from the dropdown.")
public void the_user_selects_the_appropriate_part_from_the_dropdown() throws InterruptedException {
   tc.PART();
}

@Then("The userEnters the Characteristic Name in the respective input field.")
public void the_user_enters_the_characteristic_name_in_the_respective_input_field() throws InterruptedException {
   tc.Char();
}

@Then("The user Clicks the Add button to confirm the characteristic details.")
public void the_user_clicks_the_add_button_to_confirm_the_characteristic_details() throws InterruptedException {
   tc.AD();
}

@Then("The user Inputs the Upper Spec value in the corresponding input field.")
public void the_user_inputs_the_upper_spec_value_in_the_corresponding_input_field() throws InterruptedException {
	Thread.sleep(2000);
   tc.upperspec();
}

@Then("The user Provides the Lower Spec value in the respective input field.")
public void the_user_provides_the_lower_spec_value_in_the_respective_input_field() throws InterruptedException {
   tc.lowerspec();
}

@Then("the userSpecifies the Subgroup Size to define grouping.")
public void the_user_specifies_the_subgroup_size_to_define_grouping() throws InterruptedException {
   tc.subsize();
}

@Then("the user The user clicks the Save button to save the characteristic details.")
public void the_user_the_user_clicks_the_save_button_to_save_the_characteristic_details() throws InterruptedException {
   tc.savechar();
}

@Then("the user Clicks on Control Chart Preferences to open chart configuration settings.")
public void the_user_clicks_on_control_chart_preferences_to_open_chart_configuration_settings() throws InterruptedException {
	Thread.sleep(1000);
   tc.controlcahrt();
}

@Then("the user Accesses the Analysis Tab to view analysis options.")
public void the_user_accesses_the_analysis_tab_to_view_analysis_options() throws InterruptedException {
   tc.Analisys();
}

@Then("the user Clicks on the Define Run dropdown and selects the desired optio")
public void the_user_clicks_on_the_define_run_dropdown_and_selects_the_desired_optio() throws InterruptedException {
   tc.DefieRun();
}

@Then("the user Configures the trend by selecting the Define Trend Down option.")
public void the_user_configures_the_trend_by_selecting_the_define_trend_down_option() throws InterruptedException {
   tc.DefineTrend();
}

@Then("user click on Hugging Average dropdown and select value")
public void user_click_on_hugging_average_dropdown_and_select_value() throws InterruptedException {
   tc.Hugging();
}

@Then("user click on Hugging Control Limit {int} sides dropdown and select value,                                              ;")
public void user_click_on_hugging_control_limit_sides_dropdown_and_select_value(Integer int1) throws InterruptedException {
   tc.Control();
}

@Then("the user The user clicks the Save button to save the configured chart preferences.")
public void the_user_the_user_clicks_the_save_button_to_save_the_configured_chart_preferences() throws InterruptedException {
   tc.saveDD();
}

@Then("the user The user clicks the Close button to exit the configuration page.")
public void the_user_the_user_clicks_the_close_button_to_exit_the_configuration_page() throws InterruptedException {
   tc.closechar();
}





//parameter 1 data and time




@Then("the user navigates to Settings by clicking the Configuration option.")
public void the_user_navigates_to_settings_by_clicking_the_configuration_option() {
	tc.clickconfiguration01();
}


@When("the user initiates the parameter creation process by clicking on the Add Parameter link")
public void the_user_initiates_the_parameter_creation_process_by_clicking_on_the_add_parameter_link() throws InterruptedException {
	Thread.sleep(1000);
   tc.clickaddpara1();
}



@Then("the user enters a name in the Parameter Name input field.")
public void the_user_enters_a_name_in_the_parameter_name_input_field() {
	tc.sendparaname41();
}

@Then("the user enables the functionality by selecting the Date\\/Time radio button.")
public void the_user_enables_the_functionality_by_selecting_the_date_time_radio_button() throws InterruptedException {
	tc.datatime();
}

@Then("the user confirms the parameter configuration by clicking the Go button.")
public void the_user_confirms_the_parameter_configuration_by_clicking_the_go_button() throws InterruptedException {
	tc.go();
}

@Then("the user enters the Date and Time format in the designated field.")
public void the_user_enters_the_date_and_time_format_in_the_designated_field() throws InterruptedException {
	tc.data();
}

@Then("the user tests the format by clicking the Test button.")
public void the_user_tests_the_format_by_clicking_the_test_button() throws InterruptedException {
	tc.Test();
}

@Then("the user saves the parameter configuration by clicking the Save button.")
public void the_user_saves_the_parameter_configuration_by_clicking_the_save_button() {
	tc.saveP();
}

@Then("the user finalizes the process by clicking the Close button.")
public void the_user_finalizes_the_process_by_clicking_the_close_button() {
	tc.closeC();
}







private By clickconfiguration02 = By.xpath("(//img)[8]");
private By clickaddpara02 = By.xpath("(//img[@class='imgStyle1'])[1]");
	private By sendparaname02 = By.xpath("(//input[@maxlength=\"40\"])[1]");
	 private By datatime02 = By.xpath("(//input[@type=\"radio\"])[6]");
   private By go02 = By.xpath("//button[text()=' Go']");
   private By data02 = By.id("datetimeFormat");
   private By Test02 = By.xpath("(//button[@class=\"btn save\"])[1]");
   private By saveP02 = By.xpath("//button[normalize-space()='Save']");
   private By closeC02 = By.xpath("//button[text()='Close']");
   














//parameter 2 data and time


@When("the user starts the parameter creation process by clicking the Add Parameter link.")
public void the_user_starts_the_parameter_creation_process_by_clicking_the_add_parameter_link() {
  tc.clickaddpara07();
}

@Then("the user provides a name in the Parameter Name input field.")
public void the_user_provides_a_name_in_the_parameter_name_input_field() {
	tc.sendparaname07();
    }

@Then("enables the functionality by selecting the Date\\/Time radio button.")
public void enables_the_functionality_by_selecting_the_date_time_radio_button() throws InterruptedException {
  tc.datatime07();
}

@Then("confirms the configuration by clicking the Go button.")
public void confirms_the_configuration_by_clicking_the_go_button() throws InterruptedException {
    tc.go07();
}

@Then("the user specifies the Date and Time format in the designated field.")
public void the_user_specifies_the_date_and_time_format_in_the_designated_field() throws InterruptedException {
  tc.data07();
}

@Then("tests the format by clicking the Test button.")
public void tests_the_format_by_clicking_the_test_button() throws InterruptedException {
   tc.Test07();
}

@Then("saves the parameter configuration by clicking the Save button.")
public void saves_the_parameter_configuration_by_clicking_the_save_button() {
	tc.saveP07();
}

@Then("the user completes the process by clicking the Close button.")
public void the_user_completes_the_process_by_clicking_the_close_button() {
    tc.closeC07();
}





//parameter allow radio button

@Then("the user initiates parameter creation by clicking the Add Parameter link.")
public void the_user_initiates_parameter_creation_by_clicking_the_add_parameter_link() {
	tc.clickaddpara1();
}


@Then("the user enters the parameter name in the designated input field.")
public void the_user_enters_the_parameter_name_in_the_designated_input_field() {
	tc.sendparaname01();
}

@Then("the user enables the parameter by selecting the Allow radio button.")
public void the_user_enables_the_parameter_by_selecting_the_allow_radio_button() {
	tc.allowall();
}



@Then("the user saves the parameter allow all configuration by clicking the Save button .")
public void the_user_saves_the_parameter_allow_all_configuration_by_clicking_the_save_button() {
    tc.save01();
}


@Then("the user exits the parameter configuration by clicking the Close button.")
public void the_user_exits_the_parameter_configuration_by_clicking_the_close_button() {
	tc.close01();
}




//assign para to part


@Then("the user clicks on the Files icon to initiate the process of adding a parameter to the part.")
public void the_user_clicks_on_the_files_icon_to_initiate_the_process_of_adding_a_parameter_to_the_part() throws InterruptedException {
	tc.filesicon();
}

@Then("the user clicks on the Add icon to start the parameter addition process.")
public void the_user_clicks_on_the_add_icon_to_start_the_parameter_addition_process() throws InterruptedException {
	tc.Addptp();
}

@Then("the user verifies the assignment by clicking on the Assign Parameter to Part link.")
public void the_user_verifies_the_assignment_by_clicking_on_the_assign_parameter_to_part_link() {
	tc.Assignparaicon();
}

@Then("the user clicks on the Group dropdown to view the available groups.")
public void the_user_clicks_on_the_group_dropdown_to_view_the_available_groups() {
	tc.datadropdown();
}

@Then("the user selects the data group from the dropdown to specify the group.")
public void the_user_selects_the_data_group_from_the_dropdown_to_specify_the_group() {
	tc.selectgrp();
}

@Then("the user clicks on the Part dropdown to view the available parts.")
public void the_user_clicks_on_the_part_dropdown_to_view_the_available_parts() {
	tc.partdropdown();
}

@Then("the user selects the part to which the parameter will be added.")
public void the_user_selects_the_part_to_which_the_parameter_will_be_added() {
	tc.selectpartpara();
}

@Then("the user drags and drops the previously used parameters into the part.")
public void the_user_drags_and_drops_the_previously_used_parameters_into_the_part() {
	tc.checkallbox1();
}

@Then("the user drags and drops the required parameter into the part.")
public void the_user_drags_and_drops_the_required_parameter_into_the_part() {
	tc.checkallbox();
}

@Then("the user confirms the addition of the parameter by clicking on the Save button.")
public void the_user_confirms_the_addition_of_the_parameter_by_clicking_on_the_save_button() {
	tc.saveassign();
}

@Then("the user exits the parameter addition process by clicking the Close button.")
public void the_user_exits_the_parameter_addition_process_by_clicking_the_close_button() {
	tc.closeassign();
}











@Then("the user clicks on the Files button to navigate to the sequence section.")
public void the_user_clicks_on_the_files_button_to_navigate_to_the_sequence_section() {
	tc.addseqlink();
}

@Then("the user clicks on the expand button next to the Files icon to reveal more options.")
public void the_user_clicks_on_the_expand_button_next_to_the_files_icon_to_reveal_more_options() {
	tc.expand();
}


@Then("the user selects a group name from the grid by clicking on it.")
public void the_user_selects_a_group_name_from_the_grid_by_clicking_on_it() throws InterruptedException {
	Thread.sleep(2000);
	 tc.DDG1();
}

@Then("the user clicks on the arrow icon to expand the available options.")
public void the_user_clicks_on_the_arrow_icon_to_expand_the_available_options() {
	 tc.DDd();
}

@Then("the user clicks on the Sequence link to open the sequence configuration page.")
public void the_user_clicks_on_the_sequence_link_to_open_the_sequence_configuration_page() {
	tc.Sequenc();
}


@Then("the user right-clicks on the sequence name to access additional options.")
public void the_user_right_clicks_on_the_sequence_name_to_access_additional_options() throws InterruptedException {
	tc.Sequenc1();
}

@Then("the user selects Edit Sequence by clicking on it.")
public void the_user_selects_edit_sequence_by_clicking_on_it() {
	tc.editsequence();
}

@Then("the user rearranges the characteristics by dragging and dropping them into the desired order.")
public void the_user_rearranges_the_characteristics_by_dragging_and_dropping_them_into_the_desired_order() {
	tc.draganddrop();
}

@Then("the user saves the changes by clicking the Save button.")
public void the_user_saves_the_changes_by_clicking_the_save_button() {
	tc.save();
}

@Then("the user closes the sequence configuration by clicking the Close button.")
public void the_user_closes_the_sequence_configuration_by_clicking_the_close_button() {
	tc.close01();
}


}
