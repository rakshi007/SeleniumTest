package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.DriverFactory;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.TestCase10Page;
import util.ConfigReader;
import util.ExtentReportManager;

public class TestStatus10 {
	private TestCase10Page tc = new TestCase10Page(DriverFactory.getDriver());

	ConfigReader configReader = new ConfigReader();

	 private ExtentTest test;

	  {
	        // Initialize a new test
		  {
		        this.test = ExtentReportManager.getTest();
		    }
	        test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
	    }

	  ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();

	@When("user clicks on network icon to verify CPK Value")
	public void user_clicks_on_network_icon_to_verify_cpk_value() {
tc.network1();

	}

	@Then("user clicks on page name for edit to verify CPK Value")
	public void user_clicks_on_page_name_for_edit_to_verify_cpk_value() {
tc.clickvaripage();

	}

	@Then("user clicks on edit icon to verify CPK Value")
	public void user_clicks_on_edit_icon_to_verify_cpk_value() {
tc.editpencil();

	}

	@When("user clicks on date input field  to verify CPK Value")
	public void user_clicks_on_date_input_field_to_verify_cpk_value() {
tc.date();

	}

	@Then("user clicks on time1 input field  to verify CPK Value")
	public void user_clicks_on_time1_input_field_to_verify_cpk_value() {
tc.time();

	}

	@Then("user enters subgroup size for one11  to verify CPK Value")
	public void user_enters_subgroup_size_for_one11_to_verify_cpk_value() {
tc.subgroup01();

	}

	@Then("user enters subgroup size for two12  to verify CPK Value")
	public void user_enters_subgroup_size_for_two12_to_verify_cpk_value() {
tc.subgroup02();

	}

	@Then("user clicks on save button for chart1  to verify CPK Value")
	public void user_clicks_on_save_button_for_chart1_to_verify_cpk_value() {

tc.savechart01();
	}

	
	@Then("user fetches the 01 of the page  to verify CPK Value")
	public void user_fetches_the_01_of_the_page_to_verify_cpk_value() {
tc.getText();

	}

	@When("user clicks on time2 input field  to verify CPK Value")
	public void user_clicks_on_time2_input_field_to_verify_cpk_value() {
tc.time2();

	}

	@Then("user enters subgroup size for one21  to verify CPK Value")
	public void user_enters_subgroup_size_for_one21_to_verify_cpk_value() {

tc.subgroup11();
	}

	@Then("user enters subgroup size for two22 to verify CPK Value")
	public void user_enters_subgroup_size_for_two22_to_verify_cpk_value() throws InterruptedException {
tc.subgroup12();

	}

	@Then("user fetches the validation data01  to verify CPK Value")
	public void user_fetches_the_validation_data01_to_verify_cpk_value() {
tc.validateDataValues01();

	}

	@Then("user clicks on save button for chart2  to verify CPK Value")
	public void user_clicks_on_save_button_for_chart2_to_verify_cpk_value() throws InterruptedException {
tc.Savechart02();

	}
	
	@Then("user click on cancel button01 to verify CPK ")
	public void user_click_on_cancel_button01_to_verify_cpk_() {
	  tc.cancel01();
	}

	@Then("user fetches the 02 of the page  to verify CPK Value")
	public void user_fetches_the_02_of_the_page_to_verify_cpk_value() {

tc.GetText02();
	}

	@When("user clicks on time3 input field  to verify CPK Value")
	public void user_clicks_on_time3_input_field_to_verify_cpk_value() {
tc.time3();

	}

	@Then("user enters subgroup size for one31  to verify CPK Value")
	public void user_enters_subgroup_size_for_one31_to_verify_cpk_value() {
tc.subgroup21();

	}

	@Then("user enters subgroup size for two32 to verify CPK Value")
	public void user_enters_subgroup_size_for_two32_to_verify_cpk_value() {
tc.subgroup22();

	}

	@Then("user fetches the validation data02  to verify CPK Value")
	public void user_fetches_the_validation_data02_to_verify_cpk_value() {
tc.validateDataValues02();

	}

	@Then("user clicks on save button for chart3  to verify CPK Value")
	public void user_clicks_on_save_button_for_chart3_to_verify_cpk_value() {

tc.savechart331();
	}
	
	@Then("user click on cancel button02 to verify CPK ")
	public void user_click_on_cancel_button02_to_verify_cpk_() {
	    tc.cancel02();
	}


	@Then("user fetches the 03 of the page  to verify CPK Value")
	public void user_fetches_the_03_of_the_page_to_verify_cpk_value() {

tc.getText3();
	}

	@When("user clicks on time4 input field  to verify CPK Value")
	public void user_clicks_on_time4_input_field_to_verify_cpk_value() {

tc.time4();
	}

	@Then("user enters subgroup size for one41  to verify CPK Value")
	public void user_enters_subgroup_size_for_one41_to_verify_cpk_value() {
tc.subgroup31();

	}

	@Then("user enters subgroup size for two42  to verify CPK Value")
	public void user_enters_subgroup_size_for_two42_to_verify_cpk_value() {
tc.subgroup32();

	}

	@Then("user fetches the validation data03  to verify CPK Value")
	public void user_fetches_the_validation_data03_to_verify_cpk_value() {
tc.validateDataValues03();

	}

	@Then("user clicks on save button for chart4  to verify CPK Value")
	public void user_clicks_on_save_button_for_chart4_to_verify_cpk_value() {

tc.savechart4();
	}

	@Then("user click on cancel button03 to verify CPK ")
	public void user_click_on_cancel_button03_to_verify_cpk_() {
	   tc.cancel03();
	}
	@Then("user fetches the 04 of the page  to verify CPK Value")
	public void user_fetches_the_04_of_the_page_to_verify_cpk_value() {

tc.getText4();
	}

	@When("user clicks on time5 input field  to verify CPK Value")
	public void user_clicks_on_time5_input_field_to_verify_cpk_value() {
tc.time5();

	}

	@Then("user enters subgroup size for one51  to verify CPK Value")
	public void user_enters_subgroup_size_for_one51_to_verify_cpk_value() {

tc.subgroup41();
	}

	@Then("user enters subgroup size for two52  to verify CPK Value")
	public void user_enters_subgroup_size_for_two52_to_verify_cpk_value() {
tc.subgroup42();

	}

	@Then("user fetches the validation data04  to verify CPK Value")
	public void user_fetches_the_validation_data04_to_verify_cpk_value() {
tc.validateDataValues04();

	}

	@Then("user clicks on save button for chart54  to verify CPK Value")
	public void user_clicks_on_save_button_for_chart54_to_verify_cpk_value() throws InterruptedException {
tc.savechart5();

	}

	@Then("user click on cancel button04 to verify CPK ")
	public void user_click_on_cancel_button04_to_verify_cpk_() {
	   tc.cancel04();
	}
	
	
	@Then("user fetches the 05 of the page  to verify CPK Value")
	public void user_fetches_the_05_of_the_page_to_verify_cpk_value() {

tc.getText5();
	}

	@Then("user fetches the validation chart data05 to verify CPK Value")
	public void user_fetches_the_validation_chart_data05_to_verify_cpk_value() {

tc.validateDataValues05();
	}



}
