package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.DriverFactory;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.Testcase01page;
import util.ConfigReader;
import util.ExtentReportManager;

public class Testcase01steps {

	
	
	private Testcase01page tc = new Testcase01page(DriverFactory.getDriver());

	ConfigReader configReader = new ConfigReader();
	
	 private ExtentTest test;


	  {
	        // Initialize a new test
		  {
		        this.test = ExtentReportManager.getTest();
		    }
	        test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
	    }
	
	  ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();

	//datagroup
	
	@When("user is on home page to verify TestCase02")
	public void user_is_on_home_page_to_verify_test_case02() {

		 ExtentCucumberAdapter.addTestStepLog("user is on home page");

		test.info("user is on home page");

	}

	@Then("user click on add link button to create data group to verify TestCase02")
	public void user_click_on_add_link_button_to_create_data_group_to_verify_test_case02() {
test.pass("user click on add icon button");
tc.addnew11();
		
	}

	@Then("user click on add data group link to verify TestCase02")
	public void user_click_on_add_data_group_link_to_verify_test_case02() throws InterruptedException {
	   tc.clickaddgrp();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on data group button");
	
	}

	@Then("user enter data group name to verify TestCase02")
	public void user_enter_data_group_name_to_verify_test_case02() {
		 ExtentCucumberAdapter.addTestStepLog("User entered group name");
	   tc.entergrpname();
	}

	@Then("user click on add link to save the datagroup to verify TestCase02")
	public void user_click_on_add_link_to_save_the_datagroup_to_verify_test_case02() {
	   tc.clickaddbtn();
		
	   ExtentCucumberAdapter.addTestStepLog("user clicked on add button to save the data group");
		//part
		
	   
	}

	@When("user click on add link to create part to verify TestCase02")
	public void user_click_on_add_link_to_create_part_to_verify_test_case02() {
	   
	   tc.addnew1();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on add link to create part");
	}

	@Then("user click on add part to create part to verify TestCase02")
	public void user_click_on_add_part_to_create_part_to_verify_test_case02() throws InterruptedException {
		Thread.sleep(1000);
	   tc.clickpart1();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on part link to creat part");
	   
	}

	@Then("user click on datagroup dropdown to select datagroup to verify TestCase02")
	public void user_click_on_datagroup_dropdown_to_select_datagroup_to_verify_test_case02() {
	   tc.selectdropdown();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on datagroup dropdown");
	}

	@Then("user select datagroup to verify TestCase02")
	public void user_select_datagroup_to_verify_test_case02() {
	   tc.selectgroup();
	   ExtentCucumberAdapter.addTestStepLog("user selected datagroup to add part");
	}

	@Then("user enter part name in the text field to verify TestCase02")
	public void user_enter_part_name_in_the_text_field_to_verify_test_case02() {
	   
	   tc.enterpartname();
	   ExtentCucumberAdapter.addTestStepLog("user entered partname in the text field");
	}

	@Then("user click on add button to save the part to verify TestCase02")
	public void user_click_on_add_button_to_save_the_part_to_verify_test_case02() {
	   tc.clickAdd();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on save button to save part");
	}
	
	
	
	
	
	
	//char
	
	
	
	
	
	

	@Then("user enter char name to verify testcase02")
	public void user_enter_char_name_to_verify_testcase02() throws InterruptedException {
	   tc.addchar();
	   ExtentCucumberAdapter.addTestStepLog("user entered charecteristic name in input text filed");
	}

	@Then("user click on add button to verify testcase02")
	public void user_click_on_add_button_to_verify_testcase02() {
	   tc.charaaddbutton();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on add button");
	}

	@Then("user enter upperspc to verify testcase02")
	public void user_enter_upperspc_to_verify_testcase02() {
	   tc.upperspec();
	   ExtentCucumberAdapter.addTestStepLog("user entered upper spec value");
	}

	@Then("user enter lower spec to verify testcase02")
	public void user_enter_lower_spec_to_verify_testcase02() {
	   tc.lowerspec();
	   ExtentCucumberAdapter.addTestStepLog("user entered lower spec value");
	}

	@Then("user enter Subgrop size to verify testcase02")
	public void user_enter_subgrop_size_to_verify_testcase02() {
	   tc.subsize();
	   ExtentCucumberAdapter.addTestStepLog("user entered subgroup size value");
	}

	@Then("user click on save button to verify testcase02")
	public void user_click_on_save_button_to_verify_testcase02() {
	   tc.savechar();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on  save button to save charecterstics");
	}


	@Then("user clicks on alarms and resrtication to varify testcase{int}")
	public void userClicksOnAlarmsAndResrticationToVarifyTestcase(int arg0) throws InterruptedException {
		tc.alram();
	}

	@Then("user clicks on check box UNOOC to verify testcase02")
	public void user_clicks_on_check_box_unooc_to_verify_testcase02() throws InterruptedException {
        tc.funcation1();
	}
	@Then("user clicks on save button to save alarms and resrtication settrings")
	public void user_clicks_on_save_button_to_save_alarms_and_resrtication_settrings() throws InterruptedException {
      tc.savechar1();
	}

		@Then("user click on close button to verifyTestCase02")
	public void user_click_on_close_button_to_verify_test_case02() throws InterruptedException {
	   
		tc.closechar();
		  ExtentCucumberAdapter.addTestStepLog("user clicked closed button after saving charecterstics");
		
		
		
		
		
		//para 
		
		
	   
	}

	@Then("user click on configuration icon for numeric parameter to verify testcase02")
	public void user_click_on_configuration_icon_for_numeric_parameter_to_verify_testcase02() throws InterruptedException {
	   tc.clickconfiguration01();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on configuration link to create parameters ");
	}

	@Then("user click on add parameter link for numeric parameter to verify TestCase02")
	public void user_click_on_add_parameter_link_for_numeric_parameter_to_verify_test_case02() throws InterruptedException {
	   tc.clickaddpara2();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on add parameetr icon to create parameters ");
	   
	}

	@Then("user enter parameter name for numeric parameter to verify verify TestCase02")
	public void user_enter_parameter_name_for_numeric_parameter_to_verify_verify_test_case02() {
	   tc.sendparaname2();
	   ExtentCucumberAdapter.addTestStepLog("user entered parameter name");
	}

	@Then("user click on Require Parameter Entry check box to for numeric parameter verify TestCase02")
	public void user_click_on_require_parameter_entry_check_box_to_for_numeric_parameter_verify_test_case02() {
	   tc.numericRD();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on numeric only check box ");
	}

	@Then("user enter click on save for numeric parameter to verify TestCase02")
	public void user_enter_click_on_save_for_numeric_parameter_to_verify_test_case02() {
	   tc.save2();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on save button to save parameter ");
	}

	@Then("user enter click on close button for numeric parameter to verify TestCase02")
	public void user_enter_click_on_close_button_for_numeric_parameter_to_verify_test_case02() {
	   
	   tc.close2();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on close button after saving parameter");
	}
	
	
	
	//password

	@Then("user click on add parameter link for password protection to verify testcase02")
	public void user_click_on_add_parameter_link_for_password_protection_to_verify_testcase02() {
	   tc.clickaddpara4();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on add parameter link to create parameter");
	}

	@Then("user enter parameter name to verify testcase02")
	public void user_enter_parameter_name_to_verify_testcase02() {
	   tc.sendparaname4();
	   ExtentCucumberAdapter.addTestStepLog("user entered parameter name in input textfiled ");
	}

	@Then("user click on password protection check box to verify testcase02")
	public void user_click_on_password_protection_check_box_to_verify_testcase02() {
	   tc.password();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on password protection check box ");
	}

	@Then("user enter first parameter entries to verify testcase02")
	public void user_enter_first_parameter_entries_to_verify_testcase02() {
		 ExtentCucumberAdapter.addTestStepLog("user entered 1st parameter entry ");
	   tc.ADDPARA1();
	}

	@Then("user enter enter password to verify testcase02")
	public void user_enter_enter_password_to_verify_testcase02() {
		 ExtentCucumberAdapter.addTestStepLog("user entered password in pasword textfield ");
	   tc.Enterpassword();
	}

	@Then("user enter re-enter password to verify testcase02")
	public void user_enter_re_enter_password_to_verify_testcase02() {
		 ExtentCucumberAdapter.addTestStepLog("user entered re-enterpassword in textfield ");
	   tc.ReEnterpassword();
	}

	@Then("user click on addicon1 for password protection to verify testcase02")
	public void user_click_on_addicon1_for_password_protection_to_verify_testcase02() throws InterruptedException {
	   Thread.sleep(1000);
	   
	   tc.ppa1();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on add icon");
	}

	@Then("user enter second parameter entries to verify testcase02")
	public void user_enter_second_parameter_entries_to_verify_testcase02() {
	   tc.ADDPARA2();
	   ExtentCucumberAdapter.addTestStepLog("user entered 2nd parameter entry ");
	}

	@Then("user enter enter password for second time to verify testcase02")
	public void user_enter_enter_password_for_second_time_to_verify_testcase02() {
	   tc.Enterpassword2();
	   ExtentCucumberAdapter.addTestStepLog("user entered password in pasword textfield ");
	}

	@Then("user enter re-enter password second time to verify testcase02")
	public void user_enter_re_enter_password_second_time_to_verify_testcase02() {
	   tc.ReEnterpassword2();
	   ExtentCucumberAdapter.addTestStepLog("user entered re-enterpassword in textfield ");
	}

	@Then("user click on addicon2 for password protection to verify testcase02")
	public void user_click_on_addicon2_for_password_protection_to_verify_testcase02() throws InterruptedException {
		Thread.sleep(1000);
	   tc.ppa2();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on add icon");
	}
	
	@Then("user click on save button to save password protection parameter")
	public void user_click_on_save_button_to_save_password_protection_parameter() {
	  tc.save4();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on save button to save parameter");
	}

	@Then("user click on close button to save password protection parameter")
	public void user_click_on_close_button_to_save_password_protection_parameter() {
	    tc.close4();
	    ExtentCucumberAdapter.addTestStepLog("user clicked on close button after saving parameter ");
	}


	
	
	
	
	//para to part

	@Then("user click on files icons to add parameter to part to verify TestCase02")
	public void user_click_on_files_icons_to_add_parameter_to_part_to_verify_test_case02() throws InterruptedException {
		Thread.sleep(1000);
	     tc.filesicon();
	     ExtentCucumberAdapter.addTestStepLog("user clicked on files tab");
	}

	@Then("user click on add icon for adding para to part to verify TestCase02")
	public void user_click_on_add_icon_for_adding_para_to_part_to_verify_test_case02() throws InterruptedException {
		Thread.sleep(1000);
	   tc.Addptp();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on add icon to assign parameter to part");
	}

	@Then("user click on assign para to part  to verify testcase02")
	public void user_click_on_assign_para_to_part_to_verify_testcase02() {
	   tc.Assignparaicon();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on assign parameter to part to link");
	   
	}

	@Then("user click on group dropdown to verify TestCase02")
	public void user_click_on_group_dropdown_to_verify_test_case02() {
	   tc.datadropdown();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on datagroup dropdown to assign parameter");
	   
	}

	@Then("user select data group to verify testcase02")
	public void user_select_data_group_to_verify_testcase02() {
	   tc.selectgrp();
	   ExtentCucumberAdapter.addTestStepLog("user selected  datagroup from dropdown");
	}

	@Then("user click on part dropdown to verify testcase02")
	public void user_click_on_part_dropdown_to_verify_testcase02() {
	   tc.partdropdown();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on part dropdown "); 
	}

	@Then("user select part for adding para to part to verify  testcase02")
	public void user_select_part_for_adding_para_to_part_to_verify_testcase02() {
	   tc.selectpartpara();
	   ExtentCucumberAdapter.addTestStepLog("user selected part from dropdown");
	}

	@Then("user click on all check box to verify  testcase02")
	public void user_click_on_all_check_box_to_verify_testcase02() throws InterruptedException {
		Thread.sleep(2000);
	   tc.checkallbox();
	   ExtentCucumberAdapter.addTestStepLog("user drag and dropped the parameter");
	   
	}

	@Then("user click on save button for adding para to part to verify  testcase02")
	public void user_click_on_save_button_for_adding_para_to_part_to_verify_testcase02() {
	   tc.saveassign();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on save button to save parameter to part");
	}

	@Then("user click on close button  for adding para to part to verify  testcase02")
	public void user_click_on_close_button_for_adding_para_to_part_to_verify_testcase02() {
	   tc.closeassign();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on close button after saving parameter to part");
	}

	
	
	
	
	
//sequence	
	
	
	
	@Then("user click add icon for squences to verify  testcase02")
	public void user_click_add_icon_for_squences_to_verify_testcase02() throws Exception {
		Thread.sleep(1000);
	   tc.addseqlink();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on add icon to create sequence");
	   
	}

	@Then("user click on add sequence to verify  testcase02")
	public void user_click_on_add_sequence_to_verify_testcase02() {
	   tc.addsequece();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on add sequence button ");
	}

	@Then("user click on data group drop dropdown to verify testcase02")
	public void user_click_on_data_group_drop_dropdown_to_verify_testcase02() {
	   tc.clickdatagroup();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on datagroup dropdown ");
	}
	
	@Then("user select datagroup from dropdown to verify testcase02")
	public void user_select_datagroup_from_dropdown_to_verify_testcase02() {
	    tc.selectdatagrp();
	    ExtentCucumberAdapter.addTestStepLog("user selected datagroup from dropdown ");
	}

	@Then("user click on part drop-down to verify testcase02")
	public void user_click_on_part_drop_down_to_verify_testcase02() {
	    tc.clickpart();
	    ExtentCucumberAdapter.addTestStepLog("user clicked on part dropdown ");
	}
	

	@Then("user select part to verify testcase02")
	public void user_select_part_to_verify_testcase02() {
	    tc.selectpart();
	    ExtentCucumberAdapter.addTestStepLog("user selected part from dropdown ");
	}

	@Then("user click on add button in the popup to verify  testcase02")
	public void user_click_on_add_button_in_the_popup_to_verify_testcase02() {
	    tc.clickonadd();
	    ExtentCucumberAdapter.addTestStepLog("user clicked on add button ");
	   
	}

	@Then("user Enter sequence name to verify  testcase02")
	public void user_enter_sequence_name_to_verify_testcase02() throws InterruptedException {
		Thread.sleep(1000);
	   tc.EnterSequencename();
	   ExtentCucumberAdapter.addTestStepLog("user entered sequence name in sequence name text field");
	}

	@Then("user click on all check boxes to verify  testcase02")
	public void user_click_on_all_check_boxes_to_verify_testcase02() {
	   tc.SelectallCB();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on check box");
	}

	@Then("user click on kebab menu to verify  testcase02")
	public void user_click_on_kebab_menu_to_verify_testcase02() {
	   tc.Kebab();
	   ExtentCucumberAdapter.addTestStepLog("user click on kebab menu to add sequence");
	}
	
	@Then("user click on assign link to verify  testcase02")
	public void user_click_on_assign_link_to_verify_testcase02() {
	   tc.assign();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on assign link ");
	}

	@Then("user click on save button to verify  testcase02")
	public void user_click_on_save_button_to_verify_testcase021() {
	   tc.save();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on save button to save sequence");
	}

	@Then("user click on close button to verify  testcase02")
	public void user_click_on_close_button_to_verify_testcase02() throws InterruptedException {
		Thread.sleep(1000);
	   
	   tc.close1();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on close button after saving sequence ");
	}
	
	
	
	
	
	
	
	
	
	//network

	@Then("user click on network icon to verify testcase02")
	public void user_click_on_network_icon_to_verify_testcase02() {
	   tc.network();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on networkpage menu to create page");
	  	}
	
	@Then("user click on ok button on the network page")
	public void user_click_on_ok_button_on_the_network_page() throws InterruptedException {
		Thread.sleep(1000);
	   tc.oknetwork();
	}
	
	

	@Then("user click on Add satellite icon to verify testcase02")
	public void user_click_on_add_satellite_icon_to_verify_testcase02() throws InterruptedException {
		Thread.sleep(2000);
	   tc.addsatellite();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on add setellite icon");
	}

	@Then("user click on Add satellite link to verify testcase02")
	public void user_click_on_add_satellite_link_to_verify_testcase02() {
	   
	   tc.satellite();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on add satellite link ");
	}

	@Then("user enter satellite name to verify testcase02")
	public void user_enter_satellite_name_to_verify_testcase02() {
	   tc.Entersatellitename();
	   ExtentCucumberAdapter.addTestStepLog("user entered satellite name");
	   
	}

	@Then("user click on add icon to save satellite to verify testcase02")
	public void user_click_on_add_icon_to_save_satellite_to_verify_testcase02() {
	   tc.Addsetellite();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on add satellite button");
	   
	}

	@Then("user click on Add kebab icon to verify testcase02")
	public void user_click_on_add_kebab_icon_to_verify_testcase02() {
	   tc.Kebabsatellite();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on kebeb icon");
	}

	@Then("user click on Addpage link to verify testcase02")
	public void user_click_on_addpage_link_to_verify_testcase02() {
	  tc.Addpaegsatellite();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on addpage link");
	}

	@Then("user enter satellite page name to verify testcase02")
	public void user_enter_satellite_page_name_to_verify_testcase02() throws InterruptedException {
		Thread.sleep(1000);
	   tc.Enterpagenamesatellite();
	   ExtentCucumberAdapter.addTestStepLog("user entered satellite page name");
	   
	}

	@Then("user click on  add link page name to verify testcase02")
	public void user_click_on_add_link_page_name_to_verify_testcase02() {
	   tc.Addsatellitepage();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on add page name link");
	}

	@Then("user click on sequence check box to verify testcase02")
	public void user_click_on_sequence_check_box_to_verify_testcase02() {
	   
	   tc.Dragsequencname();
	   ExtentCucumberAdapter.addTestStepLog("user drag and drapped sequence to page");
	}

	@Then("user click save sequence button to verify testcase02")
	public void user_click_save_sequence_button_to_verify_testcase02() {
		ExtentCucumberAdapter.addTestStepLog("user clicked on save button ");
	   tc.savesatellitepage();
	}
	

	@Then("user click on page name for edit and to verify testcase02")
	public void user_click_on_page_name_for_edit_and_to_verify_testcase02() {
	   tc.clickvaripage();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on page name to enter edit");
	}
	
	
	
	
	
	
	
	
	
	
	
	//1

	@Then("user click on edit icon to verify  Testcase02")
	public void user_click_on_edit_icon_to_verify_testcase02() throws InterruptedException {
	   tc.editpencil();
	   Thread.sleep(1000);
	   ExtentCucumberAdapter.addTestStepLog("user clicked edit icon to enter sample data values");
	}

	@Then("user click on date input field to verify testcase02")
	public void user_click_on_date_input_field_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.date();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on date input field");
	}

	@Then("user click on time input field to verify testcase02")
	public void user_click_on_time_input_field_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.time();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on time input field");
	}

	@Then("user enter subgroup size1 to verify testcase02")
	public void user_enter_subgroup_size1_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.subgroup1();
	   ExtentCucumberAdapter.addTestStepLog("user entered value for sample data one");
	   
	}

	@Then("user enter subgroup size2 to verify testcase02")
	public void user_enter_subgroup_size2_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   
	    tc.subgroup2();
	    ExtentCucumberAdapter.addTestStepLog("user entered value for sample data two");
	}

	@Then("user click on save1 button for chart01 to verify testcase02")
	public void user_click_on_save1_button_for_chart01_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
		  
	   tc.savechart();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on save button ");
	}

	@Then("user fetch the 1 of the page  to verify testcase02")
	public void user_fetch_the_1_of_the_page_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.getText();
	   ExtentCucumberAdapter.addTestStepLog("user fetch the  of subgroup 1");
	}
	
	
	//2

	@Then("user click on time2 inputfield to verify testcase02")
	public void user_click_on_time2_inputfield_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.time2();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on time input field");
	}

	@Then("user enter subgroup size12 to verify testcase02")
	public void user_enter_subgroup_size12_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.subgroup22();
	   ExtentCucumberAdapter.addTestStepLog("user entered value for sample data one");
	  	}
	

	@Then("user enter subgroup size22 to verify testcase02")
	public void user_enter_subgroup_size22_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   
	   tc.subgroup3();
	   ExtentCucumberAdapter.addTestStepLog("user entered value for sample data two");
	  	
	}

	@Then("user click on password protection dropdown to verify testcase02")
	public void user_click_on_password_protection_dropdown_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.parameterdp();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on password protection dropdown");
	  	}
	
	

	@Then("user enter password to validate to verify testcase02")
	public void user_enter_password_to_validate_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.ppenter();
	   ExtentCucumberAdapter.addTestStepLog("user entered password to validate");
	  	}

	@Then("user click on validate button to verify testcase02")
	public void user_click_on_validate_button_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.validate();
	   
	   ExtentCucumberAdapter.addTestStepLog("user clicked on validate button to verify password");
	  	}

	@Then("user click on save2 button for chart01 to verify testcase02")
	public void user_click_on_save2_button_for_chart01_to_verify_testcase02() throws InterruptedException {
		
		tc.savechart2();
		 ExtentCucumberAdapter.addTestStepLog("user clicked on save button");
			
	}

	@Then("user fetch the datavalues01 to verify testcase02")
	public void user_fetch_the_datavalues01_to_verify_testcase02() {
tc.validateDataValues01();
	}

	@Then("user fetch the 2 of the page  to verify testcase02")
	public void user_fetch_the_2_of_the_page_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(3000);
	   tc.getText2();
	   ExtentCucumberAdapter.addTestStepLog("user fetch the  of subgroup 2");
	}
	
	
	//3

	@Then("user click on time3 inputfield to verify testcase02")
	public void user_click_on_time3_inputfield_to_verify_testcase02() throws InterruptedException {
		  
	   tc.time3();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on time input field");
	}

	@Then("user enter subgroup size3 to verify testcase02")
	public void user_enter_subgroup_size3_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.subgroup13();
	   ExtentCucumberAdapter.addTestStepLog("user entered value for sample data one");
	}

	@Then("user enter subgroup size33 to verify testcase02")
	public void user_enter_subgroup_size33_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   
	   tc.subgroup33();
	   ExtentCucumberAdapter.addTestStepLog("user entered value for sample data two");
	}
	
	@Then("user enter Numeric Values to Verify Testcase02")
	public void user_enter_numeric_values_to_verify_testcase02() {
	  tc.NumricValu();
	}
	@Then("user fetch the datavalues02 to verify testcase02")
	public void user_fetch_the_datavalues02_to_verify_testcase02() {
tc.validateDataValues02();
	}

	@Then("user click on save3 button for chart01 to verify testcase02")
	public void user_click_on_save3_button_for_chart01_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.savechart3();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on save button");
	}

	@Then("user fetch the 3 of the page  to verify testcase02")
	public void user_fetch_the_3_of_the_page_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.getText3();
	   ExtentCucumberAdapter.addTestStepLog("user fetch the  of subgroup 3");
		//4
		
	}

	@Then("user click on time4 inputfield to verify testcase02")
	public void user_click_on_time4_inputfield_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.time4();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on time input field");
	}

	@Then("user enter subgroup size4 to verify testcase02")
	public void user_enter_subgroup_size4_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.subgroup4();
	   ExtentCucumberAdapter.addTestStepLog("user entered value for sample data one");
	}

	@Then("user enter subgroup size44 to verify testcase02")
	public void user_enter_subgroup_size44_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.subgroup44();
	   ExtentCucumberAdapter.addTestStepLog("user entered value for sample data two");
	}

	
	@Then("user fetch the datavalues03 to verify testcase02")
	public void user_fetch_the_datavalues03_to_verify_testcase02() {
	    tc.validateDataValues03();
	}
	@Then("user click on save4 button for chart01 to verify testcase02")
	public void user_click_on_save4_button_for_chart01_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.savechart4();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on save button");
	}

	@Then("user fetch the 4 of the page  to verify testcase02")
	public void user_fetch_the_4_of_the_page_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   
	   tc.getText4();
	   ExtentCucumberAdapter.addTestStepLog("user fetch the  of subgroup 4");
	   
	}
	
	//5

	@Then("user click on time5 inputfield to verify testcase02")
	public void user_click_on_time5_inputfield_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.time5();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on time input field");
	}

	@Then("user enter subgroup size5 to verify testcase02")
	public void user_enter_subgroup_size5_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.subgroup5();
	   ExtentCucumberAdapter.addTestStepLog("user entered value for sample data one");
	}

	@Then("user enter subgroup size55to verify testcase02")
	public void user_enter_subgroup_size55to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.subgroup55();
	   ExtentCucumberAdapter.addTestStepLog("user entered value for sample data two");
	}
	

	@Then("user fetch the datavalues04 to verify testcase02")
	public void user_fetch_the_datavalues04_to_verify_testcase02() {
	    tc.validateDataValues04();
	}
	@Then("user click on save5 button for chart01 to verify testcase02")
	public void user_click_on_save5_button_for_chart01_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.savechart5();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on save button");
	}

	@Then("user fetch the 5 of the page  to verify testcase02")
	public void user_fetch_the_5_of_the_page_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.getText5();
	   ExtentCucumberAdapter.addTestStepLog("user fetch the  of subgroup 5");  
	}

	
	//6
	
	@Then("user click on time6 input field to verify testcase02")
	public void user_click_on_time6_input_field_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.time6();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on time input field");
	}

	@Then("user enter subgroup size6 to verify testcase02")
	public void user_enter_subgroup_size6_to_verify_testcase02() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.subgroup66();
	   ExtentCucumberAdapter.addTestStepLog("user entered value for sample data one");
	}

	@Then("user enter subgroup size66 to verify testcase02 for verify")
	public void user_enter_subgroup_size66_to_verify_testcase02_for_verify() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.subgroup6();
	   ExtentCucumberAdapter.addTestStepLog("user entered value for sample data two");
	}
	
	@Then("user fetch the datavalues05 to verify testcase02")
	public void user_fetch_the_datavalues05_to_verify_testcase02() {
	   tc.validateDataValues05();
	}

	@Then("user click on save6 button for chart01 to verify testcase02 for verify")
	public void user_click_on_save6_button_for_chart01_to_verify_testcase02_for_verify() throws InterruptedException {
		  Thread.sleep(1000);
	   tc.savechar6();
	   ExtentCucumberAdapter.addTestStepLog("user entered value for sample data one");
	}
	   @Then("user click on cancel button to verify testcase02")
	   public void user_click_on_cancel_button_to_verify_testcase02() throws InterruptedException {
		   Thread.sleep(2000);
	      tc.okUN();
	      ExtentCucumberAdapter.addTestStepLog("user clicked on cancel button");
	   }


	@Then("user clicks on ok button to varify chartnote")
	public void user_clicks_on_ok_button_to_varify_chartnote() {
		tc.okUN();

	}

	@Then("user enters user note to verify usernote text field")
	public void user_enters_user_note_to_verify_usernote_text_field() {
        tc.UNA();
	}

	@Then("user clicks on sumbit button to save the user note")
	public void user_clicks_on_sumbit_button_to_save_the_user_note() {
         tc.notesave();
	}



	@Then("user fetch the 6 of the page  to verify testcase02 for verify")
	public void user_fetch_the_6_of_the_page_to_verify_testcase02_for_verify() throws InterruptedException {
		  Thread.sleep(1000);
      tc.getText6();
      ExtentCucumberAdapter.addTestStepLog("user fetch the  of subgroup 6");
	}
	
	@Then("user fetch the datavalues06 to verify testcase02")
	public void user_fetch_the_datavalues06_to_verify_testcase02() {
	   tc.validateDataValues06();
	}


}
