package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.DriverFactory;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.TestCase07Page;
import util.ConfigReader;
import util.ExtentReportManager;

public class TestCase07Steps {
	
	

	private TestCase07Page tc = new TestCase07Page(DriverFactory.getDriver());

	ConfigReader configReader = new ConfigReader();

	 private ExtentTest test;

	  {
	        // Initialize a new test
		  {
		        this.test = ExtentReportManager.getTest();
		    }
	        test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
	    }

	  ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();

	

	@When("The user clicks on the Add Icon to start the process  to verify Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_add_icon_to_start_the_process_to_verify_shift_up(Integer int1, Integer int2) {
		 tc.addnew1();

	}

	@Then("The user clicks on the Add Characteristic link to open the form  to verify Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_add_characteristic_link_to_open_the_form_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.AddCharLink();

	}

	@Then("The user Expands the Data Group Name dropdown to view the list of data groups  to verify Shift {int}\\/{int} Up")
	public void the_user_expands_the_data_group_name_dropdown_to_view_the_list_of_data_groups_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {

		tc.DDN();
	}

	@Then("The user Selects the desired data group from the dropdown  to verify Shift {int}\\/{int} Up")
	public void the_user_selects_the_desired_data_group_from_the_dropdown_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.DG();

	}

	@Then("The user Opens the Part dropdown to view the list of available parts  to verify Shift {int}\\/{int} Up")
	public void the_user_opens_the_part_dropdown_to_view_the_list_of_available_parts_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.PN();

	}

	@Then("The user Selects the appropriate part from the dropdown  to verify Shift {int}\\/{int} Up")
	public void the_user_selects_the_appropriate_part_from_the_dropdown_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.PART();

	}

	@Then("The userEnters the Characteristic Name in the respective input field  to verify Shift {int}\\/{int} Up")
	public void the_user_enters_the_characteristic_name_in_the_respective_input_field_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.Char();

	}

	@Then("The user Clicks the Add button to confirm the characteristic details  to verify Shift {int}\\/{int} Up")
	public void the_user_clicks_the_add_button_to_confirm_the_characteristic_details_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.AD();

	}

	@Then("The user Inputs the Upper Spec value in the corresponding input field  to verify Shift {int}\\/{int} Up")
	public void the_user_inputs_the_upper_spec_value_in_the_corresponding_input_field_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		Thread.sleep(1000);
		tc.upperspec();

	}

	@Then("The user Provides the Lower Spec value in the respective input field  to verify Shift {int}\\/{int} Up")
	public void the_user_provides_the_lower_spec_value_in_the_respective_input_field_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {

		tc.lowerspec();
	}

	@Then("the userSpecifies the Subgroup Size to define grouping  to verify Shift {int}\\/{int} Up")
	public void the_user_specifies_the_subgroup_size_to_define_grouping_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {

		tc.subsize();
	}

	@Then("the user The user clicks the Save button to save the characteristic details  to verify Shift {int}\\/{int} Up")
	public void the_user_the_user_clicks_the_save_button_to_save_the_characteristic_details_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.savechar();

	}

	@Then("the user Clicks on Control Chart Preferences to open chart configuration settings  to verify Shift {int}\\/{int} Up")
	public void the_user_clicks_on_control_chart_preferences_to_open_chart_configuration_settings_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		Thread.sleep(1000);
		
		tc.controlcahrt();

	}

	@Then("the user Accesses the Analysis Tab to view analysis options  to verify Shift {int}\\/{int} Up")
	public void the_user_accesses_the_analysis_tab_to_view_analysis_options_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		Thread.sleep(1000);
		tc.Analisys();
	}
	
	
	@Then("user click on 	3 of {int} in zone A check box to verify Shift {int}\\/{int} Up")
	public void user_click_on_3_of_in_zone_a_check_box_to_verify_shift_up(Integer int1, Integer int2, Integer int3) throws InterruptedException {
	    tc.zoneb();
	}
	

	@Then("the user Clicks on the Define Run dropdown and selects the desired option  to verify Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_define_run_dropdown_and_selects_the_desired_option_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.DefieRun();

	}

	@Then("the user Configures the trend by selecting the Define Trend Down option  to verify Shift {int}\\/{int} Up")
	public void the_user_configures_the_trend_by_selecting_the_define_trend_down_option_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.DefineTrend();

	}

	@Then("the user The user clicks the Save button to save the configured chart preferences  to verify Shift {int}\\/{int} Up")
	public void the_user_the_user_clicks_the_save_button_to_save_the_configured_chart_preferences_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.saveDD();

	}

	@Then("the user The user clicks the Close button to exit the configuration page  to verify Shift {int}\\/{int} Up")
	public void the_user_the_user_clicks_the_close_button_to_exit_the_configuration_page_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.closechar();

	}

	@Then("the user navigates to Settings by clicking the Configuration option  to verify Shift {int}\\/{int} Up")
	public void the_user_navigates_to_settings_by_clicking_the_configuration_option_to_verify_shift_up(Integer int1, Integer int2) {
		tc.clickconfiguration01();

	}

	@When("the user initiates the parameter creation process by clicking on the Add Parameter link  to verify Shift {int}\\/{int} Up")
	public void the_user_initiates_the_parameter_creation_process_by_clicking_on_the_add_parameter_link_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		
		Thread.sleep(1000);
		tc.clickaddpara1();

	}

	@Then("the user enters a name in the Parameter Name input field  to verify Shift {int}\\/{int} Up")
	public void the_user_enters_a_name_in_the_parameter_name_input_field_to_verify_shift_up(Integer int1, Integer int2) {
		tc.sendparaname11();

	}

	@Then("the user enter parameter01 value  to verify Shift {int}\\/{int} Up")
	public void the_user_enter_parameter01_value_to_verify_shift_up(Integer int1, Integer int2) {
		tc.apppara01();


	}

	@Then("the user click on add icon01  to verify Shift {int}\\/{int} Up")
	public void the_user_click_on_add_icon01_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.addicon01();

	}

	@Then("the user enter parameter02 value  to verify Shift {int}\\/{int} Up")
	public void the_user_enter_parameter02_value_to_verify_shift_up(Integer int1, Integer int2) {
		tc.apppara02();

	}

	@Then("the user click on add icon02  to verify Shift {int}\\/{int} Up")
	public void the_user_click_on_add_icon02_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {

		tc.addicon02();
	}

	@Then("the user enter parameter03 value  to verify Shift {int}\\/{int} Up")
	public void the_user_enter_parameter03_value_to_verify_shift_up(Integer int1, Integer int2) {

		tc.apppara03();
	}

	@Then("the user click on add icon03  to verify Shift {int}\\/{int} Up")
	public void the_user_click_on_add_icon03_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.addicon03();

	}

	@Then("the user enter parameter04 value  to verify Shift {int}\\/{int} Up")
	public void the_user_enter_parameter04_value_to_verify_shift_up(Integer int1, Integer int2) {
		tc.apppara04();

	}

	@Then("the user click on add icon04  to verify Shift {int}\\/{int} Up")
	public void the_user_click_on_add_icon04_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.addicon04();

	}

	@Then("the user saves the parameter configuration by clicking the Save button  to verify Shift {int}\\/{int} Up")
	public void the_user_saves_the_parameter_configuration_by_clicking_the_save_button_to_verify_shift_up(Integer int1, Integer int2) {
		tc.save01();

	}

	
	@Then("the user finalizes the process by clicking the Close button  to verify Shift {int}\\/{int} Up")
	public void the_user_finalizes_the_process_by_clicking_the_close_button_to_verify_shift_up(Integer int1, Integer int2) {
		tc.close01();

	}

	
	
	
	
	@When("the user starts the parameter creation process by clicking the Add Parameter link  to verify Shift {int}\\/{int} Up")
	public void the_user_starts_the_parameter_creation_process_by_clicking_the_add_parameter_link_to_verify_shift_up(Integer int1, Integer int2) {
		tc.clickaddpara2();

	}

	@Then("the user provides a name in the Parameter Name input field  to verify Shift {int}\\/{int} Up")
	public void the_user_provides_a_name_in_the_parameter_name_input_field_to_verify_shift_up(Integer int1, Integer int2) {

		tc.sendparaname07();
	}

	@Then("enables the functionality by selecting the lookup radio button  to verify Shift {int}\\/{int} Up")
	public void enables_the_functionality_by_selecting_the_lookup_radio_button_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.lookup();


	}

	@Then("confirms the configuration by clicking the Go button  to verify Shift {int}\\/{int} Up")
	public void confirms_the_configuration_by_clicking_the_go_button_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.go07();

	}

	@Then("user clicks on parameters drop down  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_parameters_drop_down_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.dropdown();

	}

	@Then("user select source parameter from the dropdown  to verify Shift {int}\\/{int} Up")
	public void user_select_source_parameter_from_the_dropdown_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {

		tc.source();
	}

	@Then("user clicks on Edit icon01  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_edit_icon01_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.edit01();

	}

	@Then("user enters values for 1st parameter entry  to verify Shift {int}\\/{int} Up")
	public void user_enters_values_for_1st_parameter_entry_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.sendvalue01();

	}

	@Then("user clicks on Edit icon02  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_edit_icon02_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.edit02();

	}

	@Then("user enters values for 2st parameter entry  to verify Shift {int}\\/{int} Up")
	public void user_enters_values_for_2st_parameter_entry_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {

		tc.sendvalue02();
	}

	@Then("user clicks on Edit icon03  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_edit_icon03_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.edit03();

	}

	@Then("user enters values for 3st parameter entry  to verify Shift {int}\\/{int} Up")
	public void user_enters_values_for_3st_parameter_entry_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		tc.sendvalue03();

	}


	@Then("saves the parameter configuration by clicking the Save button  to verify Shift {int}\\/{int} Up")
	public void saves_the_parameter_configuration_by_clicking_the_save_button_to_verify_shift_up(Integer int1, Integer int2) {
		tc.saveP();

	}

	@Then("the user completes the process by clicking the Close button  to verify Shift {int}\\/{int} Up")
	public void the_user_completes_the_process_by_clicking_the_close_button_to_verify_shift_up(Integer int1, Integer int2) {
		tc.closeC();

	}

	@Then("the user clicks on the Files icon to initiate the process of adding a parameter to the part  to verify Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_files_icon_to_initiate_the_process_of_adding_a_parameter_to_the_part_to_verify_shift_up(Integer int1, Integer int2) {


		   tc.filesicon();
	}

	@Then("the user clicks on the Add icon to start the parameter addition process  to verify Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_add_icon_to_start_the_parameter_addition_process_to_verify_shift_up(Integer int1, Integer int2) {

		tc.Addptp();
	}

	@Then("the user verifies the assignment by clicking on the Assign Parameter to Part link  to verify Shift {int}\\/{int} Up")
	public void the_user_verifies_the_assignment_by_clicking_on_the_assign_parameter_to_part_link_to_verify_shift_up(Integer int1, Integer int2) {

		tc.Assignparaicon();
	}

	@Then("the user clicks on the Group dropdown to view the available groups  to verify Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_group_dropdown_to_view_the_available_groups_to_verify_shift_up(Integer int1, Integer int2) {
		 tc.datadropdown();

	}

	@Then("the user selects the data group from the dropdown to specify the group  to verify Shift {int}\\/{int} Up")
	public void the_user_selects_the_data_group_from_the_dropdown_to_specify_the_group_to_verify_shift_up(Integer int1, Integer int2) {
		tc.selectgrp();

	}

	@Then("the user clicks on the Part dropdown to view the available parts  to verify Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_part_dropdown_to_view_the_available_parts_to_verify_shift_up(Integer int1, Integer int2) {

		tc.partdropdown();
	}

	@Then("the user selects the part to which the parameter will be added  to verify Shift {int}\\/{int} Up")
	public void the_user_selects_the_part_to_which_the_parameter_will_be_added_to_verify_shift_up(Integer int1, Integer int2) {

		tc.partdropdown();
	}

	@Then("the user drags and drops the previously used parameters into the part  to verify Shift {int}\\/{int} Up")
	public void the_user_drags_and_drops_the_previously_used_parameters_into_the_part_to_verify_shift_up(Integer int1, Integer int2) {

		tc.checkallbox1();
	}

	@Then("the user drags and drops the required parameter into the part  to verify Shift {int}\\/{int} Up")
	public void the_user_drags_and_drops_the_required_parameter_into_the_part_to_verify_shift_up(Integer int1, Integer int2) {

		tc.checkallbox();
	}

	@Then("the user confirms the addition of the parameter by clicking on the Save button  to verify Shift {int}\\/{int} Up")
	public void the_user_confirms_the_addition_of_the_parameter_by_clicking_on_the_save_button_to_verify_shift_up(Integer int1, Integer int2) {
		tc.saveassign();

	}

	@Then("the user exits the parameter addition process by clicking the Close button  to verify Shift {int}\\/{int} Up")
	public void the_user_exits_the_parameter_addition_process_by_clicking_the_close_button_to_verify_shift_up(Integer int1, Integer int2) {

		tc.closeassign();
	}

	@Then("the user clicks on the Files button to navigate to the sequence section  to verify Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_files_button_to_navigate_to_the_sequence_section_to_verify_shift_up(Integer int1, Integer int2) {
		tc.addseqlink();

	}

	@Then("the user clicks on the expand button next to the Files icon to reveal more options  to verify Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_expand_button_next_to_the_files_icon_to_reveal_more_options_to_verify_shift_up(Integer int1, Integer int2) {

		tc.expand();
	}

	@Then("the user selects a group name from the grid by clicking on it  to verify Shift {int}\\/{int} Up")
	public void the_user_selects_a_group_name_from_the_grid_by_clicking_on_it_to_verify_shift_up(Integer int1, Integer int2) {

		tc.DDG1();
	}

	@Then("the user clicks on the arrow icon to expand the available options  to verify Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_arrow_icon_to_expand_the_available_options_to_verify_shift_up(Integer int1, Integer int2) {
		tc.DDd();

	}

	@Then("the user clicks on the Sequence link to open the sequence configuration page  to verify Shift {int}\\/{int} Up")
	public void the_user_clicks_on_the_sequence_link_to_open_the_sequence_configuration_page_to_verify_shift_up(Integer int1, Integer int2) {
		tc.Sequenc();

	}

	@Then("the user right-clicks on the sequence name to access additional options  to verify Shift {int}\\/{int} Up")
	public void the_user_right_clicks_on_the_sequence_name_to_access_additional_options_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {

		tc.Sequenc1();
	}

	@Then("the user selects Edit Sequence by clicking on it  to verify Shift {int}\\/{int} Up")
	public void the_user_selects_edit_sequence_by_clicking_on_it_to_verify_shift_up(Integer int1, Integer int2) {
		tc.editsequence();

	}

	@Then("the user rearranges the characteristics by dragging and dropping them into the desired order  to verify Shift {int}\\/{int} Up")
	public void the_user_rearranges_the_characteristics_by_dragging_and_dropping_them_into_the_desired_order_to_verify_shift_up(Integer int1, Integer int2) {

		tc.draganddrop();
	}

	@Then("the user saves the changes by clicking the Save button  to verify Shift {int}\\/{int} Up")
	public void the_user_saves_the_changes_by_clicking_the_save_button_to_verify_shift_up(Integer int1, Integer int2) {
		tc.save();

	}

	@Then("the user closes the sequence configuration by clicking the Close button  to verify Shift {int}\\/{int} Up")
	public void the_user_closes_the_sequence_configuration_by_clicking_the_close_button_to_verify_shift_up(Integer int1, Integer int2) {
		tc.close1();

	}
}
