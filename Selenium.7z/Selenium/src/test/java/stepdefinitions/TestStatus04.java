package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.DriverFactory;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.TestCase04Page;
import util.ConfigReader;
import util.ExtentReportManager;

public class TestStatus04 {

	private TestCase04Page tc = new TestCase04Page(DriverFactory.getDriver());

	ConfigReader configReader = new ConfigReader();

	private ExtentTest test;

	{
		// Initialize a new test
		{
			this.test = ExtentReportManager.getTest();
		}
		test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
	}

	ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();





	@When("user clicks on network icon to verify Avg Trend up and down")
	public void user_clicks_on_network_icon_to_verify_avg_trend_up_and_down() {
		tc.network1();
		ExtentCucumberAdapter.addTestStepLog("user clicks on network icon ");
	}

	@Then("user clicks on page name for edit to verify Avg Trend up and down")
	public void user_clicks_on_page_name_for_edit_to_verify_avg_trend_up_and_down() {
		tc.clickvaripage();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user clicks on edit icon to verify Avg Trend up and down")
	public void user_clicks_on_edit_icon_to_verify_avg_trend_up_and_down() {
		tc.editpencil();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@When("user clicks on date input field to verify Avg Trend up and down")
	public void user_clicks_on_date_input_field_to_verify_avg_trend_up_and_down() {
		tc.date();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user clicks on time1 input field to verify Avg Trend up and down")
	public void user_clicks_on_time1_input_field_to_verify_avg_trend_up_and_down() {
		tc.time();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user enters subgroup size for one1 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_one1_to_verify_avg_trend_up_and_down() throws InterruptedException {
		tc.subgroup01();
		Thread.sleep(1000);
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user enters subgroup size for two2 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_two2_to_verify_avg_trend_up_and_down() {
		tc.subgroup02();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user clicks on save button for chart1 to verify Avg Trend up and down")
	public void user_clicks_on_save_button_for_chart1_to_verify_avg_trend_up_and_down() {
		tc.savechart01();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetches the 01 of the page to verify Avg Trend up and down")
	public void user_fetches_the_01_of_the_page_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(2000);
		tc.getText();
		ExtentCucumberAdapter.addTestStepLog("");

	}

	@When("user clicks on time2 input field to verify Avg Trend up and down")
	public void user_clicks_on_time2_input_field_to_verify_avg_trend_up_and_down() {
		tc.time2();
		ExtentCucumberAdapter.addTestStepLog("");

	}

	@Then("user enters subgroup size for one3 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_one3_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(1000);

		tc.subgroup11();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user enters subgroup size for two4 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_two4_to_verify_avg_trend_up_and_down() throws InterruptedException {
		tc.subgroup12();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetch the datavalues01 to verify testcase05")
	public void user_fetch_the_datavalues01_to_verify_testcase05() {
		tc.validateDataValues01();

	}

	@Then("user enters parameter entry Restricted value to verify Avg Trend up and down")
	public void user_enters_parameter_entry_restricted_value_to_verify_avg_trend_up_and_down() {
		tc.parameterdp3();
		ExtentCucumberAdapter.addTestStepLog("");

	}

	@Then("user clicks on save button for chart2 to verify Avg Trend up and down")
	public void user_clicks_on_save_button_for_chart2_to_verify_avg_trend_up_and_down() throws InterruptedException {
		tc.Savechart02();
		Thread.sleep(1000);
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetches the 02 of the page to verify Avg Trend up and down")
	public void user_fetches_the_02_of_the_page_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(2000);
		tc.GetText02();

		ExtentCucumberAdapter.addTestStepLog("");
	}

	@When("user clicks on time3 input field to verify Avg Trend up and down")
	public void user_clicks_on_time3_input_field_to_verify_avg_trend_up_and_down() {
		tc.time3();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user enters subgroup size for one5 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_one5_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(1000);

		tc.subgroup21();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user enters subgroup size for two6 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_two6_to_verify_avg_trend_up_and_down() {
		tc.subgroup22();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetch the datavalues02 to verify testcase05")
	public void user_fetch_the_datavalues02_to_verify_testcase05() {
		tc.validateDataValues02();
	}

	@Then("user clicks on save button for chart3 to verify Avg Trend up and down")
	public void user_clicks_on_save_button_for_chart3_to_verify_avg_trend_up_and_down() throws InterruptedException {
		tc.savechart331();
		Thread.sleep(1000);
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetches the 03 of the page to verify Avg Trend up and down")
	public void user_fetches_the_03_of_the_page_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(1000);
		tc.getText3();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@When("user clicks on time4 input field to verify Avg Trend up and down")
	public void user_clicks_on_time4_input_field_to_verify_avg_trend_up_and_down() {
		tc.time4();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user enters subgroup size for one7 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_one7_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(1000);

		tc.subgroup31();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user enters subgroup size for two8 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_two8_to_verify_avg_trend_up_and_down() {
		tc.subgroup32();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetch the datavalues03 to verify testcase05")
	public void user_fetch_the_datavalues03_to_verify_testcase05() {
		tc.validateDataValues03();
	}

	@Then("user clicks on save button for chart4 to verify Avg Trend up and down")
	public void user_clicks_on_save_button_for_chart4_to_verify_avg_trend_up_and_down() throws InterruptedException {
		tc.savechart4();
		Thread.sleep(1000);
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetches the 04 of the page to verify Avg Trend up and down")
	public void user_fetches_the_04_of_the_page_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(2000);
		tc.getText4();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@When("user clicks on time5 input field to verify Avg Trend up and down")
	public void user_clicks_on_time5_input_field_to_verify_avg_trend_up_and_down() {
		tc.time5();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user enters subgroup size for one9 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_one9_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(1000);

		tc.subgroup41();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user enters subgroup size for two10 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_two10_to_verify_avg_trend_up_and_down() {
		tc.subgroup42();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetch the datavalues04 to verify testcase05")
	public void user_fetch_the_datavalues04_to_verify_testcase05() {
		tc.validateDataValues04();
	}

	@Then("user clicks on save button for chart5 to verify Avg Trend up and down")
	public void user_clicks_on_save_button_for_chart5_to_verify_avg_trend_up_and_down() throws InterruptedException
	{

		tc.savechart5();
		Thread.sleep(2000);
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user clicks on ok button to verify Avg Trend up and down")
	public void user_clicks_on_ok_button_to_verify_avg_trend_up_and_down() throws InterruptedException {
		tc.OKCause();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user clicks on Causes dropdown to verify Avg Trend up and down")
	public void user_clicks_on_causes_dropdown_to_verify_avg_trend_up_and_down() throws InterruptedException {
		tc.CauseDropdown();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user clicks on submit button to verify Avg Trend up and down")
	public void user_clicks_on_submit_button_to_verify_avg_trend_up_and_down() throws InterruptedException {
		tc.submit01();
		Thread.sleep(1000);
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetches the 05 of the page to verify Avg Trend up and down")
	public void user_fetches_the_05_of_the_page_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(2000);
		tc.getText5();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@When("user clicks on time6 input field to verify Avg Trend up and down")
	public void user_clicks_on_time6_input_field_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(1000);

		tc.time6();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user enters subgroup size for one11 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_one11_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(2000);

		tc.subgroup61();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user enters subgroup size for two12 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_two12_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(1000);
		tc.subgroup62();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetch the datavalues05 to verify testcase05")
	public void user_fetch_the_datavalues05_to_verify_testcase05() {
		tc.validateDataValues05();
	}

	@Then("user clicks on save button for chart6 to verify Avg Trend up and down")
	public void user_clicks_on_save_button_for_chart6_to_verify_avg_trend_up_and_down() throws InterruptedException {
		tc.savechart6();
		ExtentCucumberAdapter.addTestStepLog("");
	}
	@Then("user clicks on ok button to verify chart06 verify Avg Trend up and down")
	public void user_clicks_on_ok_button_to_verify_chart06_verify_avg_trend_up_and_down() throws InterruptedException {
		tc.OKAction();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user clicks on Actions dropdown to verify Avg Trend up and down")
	public void user_clicks_on_actions_dropdown_to_verify_avg_trend_up_and_down() throws InterruptedException {
		tc.ActionDropdown();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user clicks on submit01 button to verify Avg Trend up and down")
	public void user_clicks_on_submit01_button_to_verify_avg_trend_up_and_down() throws InterruptedException {
		tc.submit02();
		Thread.sleep(1000);
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetches the 06 of the page to verify Avg Trend up and down")
	public void user_fetches_the_06_of_the_page_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(2000);
		tc.getText6();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@When("user clicks on time7 input field to verify Avg Trend up and down")
	public void user_clicks_on_time7_input_field_to_verify_avg_trend_up_and_down() {
		tc.time71();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user enters subgroup size for one13 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_one13_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(1000);

		tc.subgroup71();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user enters subgroup size for two14 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_two14_to_verify_avg_trend_up_and_down() {
		tc.subgroup72();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetch the datavalues06 to verify testcase05")
	public void user_fetch_the_datavalues06_to_verify_testcase05() {
		tc.validateDataValues06();
	}

	@Then("user clicks on save button for chart7 to verify Avg Trend up and down")
	public void user_clicks_on_save_button_for_chart7_to_verify_avg_trend_up_and_down() throws InterruptedException {
		tc.savechart71();
		Thread.sleep(1000);
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetches the 07 of the page to verify Avg Trend up and down")
	public void user_fetches_the_07_of_the_page_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(1000);
		tc.getText7();
		ExtentCucumberAdapter.addTestStepLog("");
	}


	@When("user clicks on time8 input field to verify Avg Trend up and down")
	public void user_clicks_on_time8_input_field_to_verify_avg_trend_up_and_down() {
		tc.time8();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user enters subgroup size for one15 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_one15_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(1000);

		tc.subgroup81();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user enters subgroup size for two16 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_two16_to_verify_avg_trend_up_and_down() {
		tc.subgroup82();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetch the datavalues07 to verify testcase05")
	public void user_fetch_the_datavalues07_to_verify_testcase05() {
		tc.validateDataValues07();
	}

	@Then("user clicks on save button for chart8 to verify Avg Trend up and down")
	public void user_clicks_on_save_button_for_chart8_to_verify_avg_trend_up_and_down() throws InterruptedException {
		tc.savechart81();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user click on cancel button to verify Avg Trend up and down")
	public void user_click_on_cancel_button_to_verify_avg_trend_up_and_down() throws InterruptedException {
		tc.Cancel8();
		Thread.sleep(1000);
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetches the 08 of the page to verify Avg Trend up and down")
	public void user_fetches_the_08_of_the_page_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(2000);
		tc.getText8();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@When("user clicks on time9 input field to verify Avg Trend up and down")
	public void user_clicks_on_time9_input_field_to_verify_avg_trend_up_and_down() {
		tc.time09();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user enters subgroup size for one17 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_one17_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(1000);

		tc.subgroup91();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user enters subgroup size for two18 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_two18_to_verify_avg_trend_up_and_down() {
		tc.subgroup92();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetch the datavalues08 to verify testcase05")
	public void user_fetch_the_datavalues08_to_verify_testcase05() {
		tc.validateDataValues08();
	}

	@Then("user clicks on save button for chart9 to verify Avg Trend up and down")
	public void user_clicks_on_save_button_for_chart9_to_verify_avg_trend_up_and_down() throws InterruptedException {
		tc.savechart9();
		Thread.sleep(1000);
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetches the 09 of the page to verify Avg Trend up and down")
	public void user_fetches_the_09_of_the_page_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(2000);
		tc.getText9();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@When("user clicks on time10 input field to verify Avg Trend up and down")
	public void user_clicks_on_time10_input_field_to_verify_avg_trend_up_and_down() {
		tc.time10();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user enters subgroup size for one19 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_one19_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(1000);

		tc.subgroup100();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user enters subgroup size for two20 to verify Avg Trend up and down")
	public void user_enters_subgroup_size_for_two20_to_verify_avg_trend_up_and_down() {
		tc.subgroup101();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetch the datavalues09 to verify testcase05")
	public void user_fetch_the_datavalues09_to_verify_testcase05() {
		tc.validateDataValues09();
	}

	@Then("user clicks on save button for chart10 to verify Avg Trend up and down")
	public void user_clicks_on_save_button_for_chart10_to_verify_avg_trend_up_and_down() throws InterruptedException {
		tc.savechart10();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user clicks on cancel button to verify Avg Trend up and down")
	public void user_clicks_on_cancel_button_to_verify_avg_trend_up_and_down() throws InterruptedException {
		tc.Cancel0();

		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetches the 10 of the page to verify Avg Trend up and down")
	public void user_fetches_the_10_of_the_page_to_verify_avg_trend_up_and_down() throws InterruptedException {
		Thread.sleep(2000);
		tc.getText10();
		ExtentCucumberAdapter.addTestStepLog("");
	}

	@Then("user fetch the datavalues10 to verify Avg Trend up and down")
	public void user_fetch_the_datavalues10_to_verify_avg_trend_up_and_down() {
		tc.validateDataValues10();
	}}