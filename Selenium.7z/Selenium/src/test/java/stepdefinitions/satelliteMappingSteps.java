package stepdefinitions;
import org.openqa.selenium.WebDriver;
import util.LoginUtil;
import util.UIActions;

import DriverFactory.DriverFactory;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import io.cucumber.java.en.Given;
import org.openqa.selenium.By;
import pages.GlobalPage;
import pages.LoginPage;
import util.ConfigReader;
import util.ExtentReportManager;

import java.util.Arrays;
import java.util.List;
import java.util.Properties;
public class satelliteMappingSteps {



    private GlobalPage tc = new GlobalPage(DriverFactory.getDriver());
    private ExtentTest test;
    private LoginPage loginPage;
    UIActions actions;
    {
        this.test = ExtentReportManager.getTest();
        test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
    }

    ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();


    @Given("when user maps the satellite")
    public void when_user_maps_the_satellite() {

        tc.satelliteadmin();
    }

    @Given("validate satellites for user {string}")
    public void validateSatellitesForUser(String userKey) throws InterruptedException {
        Properties prop = new ConfigReader().init_prop();
        String username = prop.getProperty(userKey);
        String password = prop.getProperty("password" + userKey.replaceAll("\\D+", ""));

        // Login
        LoginUtil.loginWithPopupHandling(DriverFactory.getDriver(), username, password);
        List<String> satellites = Arrays.asList(
                "Communication Satellites", "Navigation Satellites",
                "Weather Satellites", "Military Satellites", "Space Station Modules"
        );


        By dropdownBtn = By.xpath("//span[@class='satdrop']//img");
        By satelliteItems = By.xpath("//a[@class='dropdown-item']");

        GlobalPage page = new GlobalPage(DriverFactory.getDriver());
        tc.validateSatellitesIndividually();

    }


}






