package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.DriverFactory;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.TestCase09Page;
import util.ConfigReader;
import util.ExtentReportManager;



public class TestCase09Steps {
	
	private TestCase09Page tc = new TestCase09Page(DriverFactory.getDriver());

	ConfigReader configReader = new ConfigReader();

	 private ExtentTest test;

	  {
	        // Initialize a new test
		  {
		        this.test = ExtentReportManager.getTest();
		    }
	        test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
	    }

	  ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();

	@Given("the user is on the home page")
	public void the_user_is_on_the_home_page() {


	}

	@When("the user clicks on the Add Icon to start the process")
	public void the_user_clicks_on_the_add_icon_to_start_the_process() {
tc.addnew1();
	}

	@Then("the user clicks on the Add Characteristic link to open the form")
	public void the_user_clicks_on_the_add_characteristic_link_to_open_the_form() throws InterruptedException {
tc.AddCharLink();

	}

	@Then("the user expands the Data Group Name dropdown to view the list of data groups")
	public void the_user_expands_the_data_group_name_dropdown_to_view_the_list_of_data_groups() throws InterruptedException {
tc.DDN();

	}

	@Then("the user selects the desired data group from the dropdown")
	public void the_user_selects_the_desired_data_group_from_the_dropdown() throws InterruptedException {
tc.DG();

	}

	@Then("the user opens the Part dropdown to view the list of available parts")
	public void the_user_opens_the_part_dropdown_to_view_the_list_of_available_parts() throws InterruptedException {

tc.PN();
	}

	@Then("the user selects the appropriate part from the dropdown")
	public void the_user_selects_the_appropriate_part_from_the_dropdown() throws InterruptedException {
tc.PART();

	}

	@Then("the user enters the Characteristic Name in the respective input field")
	public void the_user_enters_the_characteristic_name_in_the_respective_input_field() throws InterruptedException {
tc.Char();

	}

	@Then("the user clicks the Add button to confirm the characteristic details")
	public void the_user_clicks_the_add_button_to_confirm_the_characteristic_details() throws InterruptedException {

tc.AD();
	}

	@Then("the user inputs the Upper Spec value in the corresponding input field")
	public void the_user_inputs_the_upper_spec_value_in_the_corresponding_input_field() throws InterruptedException {
		Thread.sleep(2000);
tc.upperspec();

	}
	@Then("the user enters the Lower Spec value in the respective input field")
	public void the_user_enters_the_lower_spec_value_in_the_respective_input_field() throws InterruptedException {
		tc.lowerspec();
	}
	

	@Then("the user specifies the Subgroup Size to define grouping")
	public void the_user_specifies_the_subgroup_size_to_define_grouping() throws InterruptedException {
tc.subsize();

	}

	@Then("the user clicks the Save button")
	public void the_user_clicks_the_save_button() throws InterruptedException {
		Thread.sleep(1000);
tc.savechar();

	}

	@Then("the user clicks on controlchart preferences")
	public void the_user_clicks_on_controlchart_preferences() throws InterruptedException {
tc.controlcahrt();

	}

	@Then("user clikcs on calculation tab")
	public void user_clikcs_on_calculation_tab() throws InterruptedException {
tc.claculation();

	}

	@Then("user change Control Limit calculation after value")
	public void user_change_control_limit_calculation_after_value() throws InterruptedException {

tc.Nostaus();
	}

	@Then("user clicks on save button to save chart preferences")
	public void user_clicks_on_save_button_to_save_chart_preferences() throws InterruptedException {

tc.saveDD();
	}

	@Then("the user clicks the Close button to exit charoverview")
	public void the_user_clicks_the_close_button_to_exit_charoverview() throws InterruptedException {
tc.closechar();

	}

	@Given("the user navigates to Settings by clicking the Configuration option")
	public void the_user_navigates_to_settings_by_clicking_the_configuration_option() {
tc.clickconfiguration01();

	}

	@When("the user initiates the parameter creation process by clicking on the Add Parameter")
	public void the_user_initiates_the_parameter_creation_process_by_clicking_on_the_add_parameter() throws InterruptedException {
Thread.sleep(2000);
tc.clickaddpara1();
	}

	@Then("the user enters a name in the Parameter Name input field")
	public void the_user_enters_a_name_in_the_parameter_name_input_field() {

tc.sendparaname01();
	}

	@Then("the user clicks on the allow user to add list check box")
	public void the_user_clicks_on_the_allow_user_to_add_list_check_box() {
tc.AllowUL();

	}

	@Then("the user enters parameter entry field01")
	public void the_user_enters_parameter_entry_field01() {
tc.order1();

	}

	@Then("the user clicks on add icon01")
	public void the_user_clicks_on_add_icon01() throws InterruptedException {
		Thread.sleep(2000);
tc.oop1();

	}

	@Then("the user enters parameter entry field02")
	public void the_user_enters_parameter_entry_field02() {

tc.order2();
	}

	@Then("the user clicks on add icon02")
	public void the_user_clicks_on_add_icon02() throws InterruptedException {
		Thread.sleep(2000);
tc.oop2();

	}

	@Then("the user enters parameter entry field03")
	public void the_user_enters_parameter_entry_field03() {
tc.order3();

	}

	@Then("the user clicks on add icon03")
	public void the_user_clicks_on_add_icon03() throws InterruptedException {
		Thread.sleep(2000);
tc.oop3();

	}

	@Then("the user saves the parameter configuration by clicking the Save button")
	public void the_user_saves_the_parameter_configuration_by_clicking_the_save_button() {

tc.save01();
	}

	@Then("the user finalizes the process by clicking the Close button")
	public void the_user_finalizes_the_process_by_clicking_the_close_button() {
tc.close01();

	}
	
	
	@When("the user starts the parameter creation process by selecting Add Parameter")
	public void the_user_starts_the_parameter_creation_process_by_selecting_add_parameter() throws InterruptedException {
	    Thread.sleep(1000);
		tc.clickaddpara12();
	}

	@Then("the user provides a name in the Parameter Name input field")
	public void the_user_provides_a_name_in_the_parameter_name_input_field() {
	   tc.sendparaname41();
	}

	@Then("the user enables the Order By List Created checkbox")
	public void the_user_enables_the_order_by_list_created_checkbox() {
	   tc.orderbyorder();
	}


	@Then("the user enters parameter entry field01 for order by list")
	public void the_user_enters_parameter_entry_field01_for_order_by_list() {
tc.ADDPARA1();

	}

	@Then("the user clicks on add icon01 for order by list")
	public void the_user_clicks_on_add_icon01_for_order_by_list() throws InterruptedException {
		Thread.sleep(2000);
tc.ppa1();

	}

	@Then("the user enters parameter entry field02 for order by list")
	public void the_user_enters_parameter_entry_field02_for_order_by_list() throws InterruptedException {
		
tc.ADDPARA2();

	}

	@Then("the user clicks on add icon02 for order by list")
	public void the_user_clicks_on_add_icon02_for_order_by_list() throws InterruptedException {
		Thread.sleep(2000);
tc.ppa2();

	}

	@Then("the user enters parameter entry field03 for order by list")
	public void the_user_enters_parameter_entry_field03_for_order_by_list() {

tc.ADDPARA3();
	}

	@Then("the user clicks on add icon03 for order by list")
	public void the_user_clicks_on_add_icon03_for_order_by_list() throws InterruptedException {
		Thread.sleep(2000);
tc.ppa3();

	}
	
	
	@Then("the user save the parameter configuration by clicking the Save button")
	public void the_user_save_the_parameter_configuration_by_clicking_the_save_button() {
	  tc.saveP();
	}

	@Then("the user finalize the process by clicking the Close button")
	public void the_user_finalize_the_process_by_clicking_the_close_button() {
	    tc.closeC();
	}
	
	
	

	@Then("the user clicks on the Files icon to initiate the process of adding a parameter to the part")
	public void the_user_clicks_on_the_files_icon_to_initiate_the_process_of_adding_a_parameter_to_the_part() {
tc.filesicon();

	}

	@Then("the user clicks on the Add icon to start the parameter addition process")
	public void the_user_clicks_on_the_add_icon_to_start_the_parameter_addition_process() {
tc.Addptp();

	}

	@Then("the user verifies the assignment by clicking on the Assign Parameter to Part link")
	public void the_user_verifies_the_assignment_by_clicking_on_the_assign_parameter_to_part_link() {
tc.Assignparaicon();

	}

	@Then("the user clicks on the Group dropdown to view the available groups")
	public void the_user_clicks_on_the_group_dropdown_to_view_the_available_groups() {
tc.datadropdown();

	}
	
	@Then("the user select the data group from the dropdown to specify the group")
	public void the_user_select_the_data_group_from_the_dropdown_to_specify_the_group() {
		tc.selectgrp();
	}

	@Then("the user clicks on the Part dropdown to view the available parts")
	public void the_user_clicks_on_the_part_dropdown_to_view_the_available_parts() {

tc.partdropdown();
	}
	
	
	@Then("the user select the part to which the parameter will be added")
	public void the_user_select_the_part_to_which_the_parameter_will_be_added() {
	   tc.selectpartpara();
	}



	@Then("the user drags and drops the previously used parameters into the part")
	public void the_user_drags_and_drops_the_previously_used_parameters_into_the_part() {
tc.checkallbox1();

	}
	@Then("the user drags and drop the required parameter into the part")
	public void the_user_drags_and_drop_the_required_parameter_into_the_part() {
	   tc.checkallbox();
	}

	@Then("the user confirms the addition of the parameter by clicking on the Save button")
	public void the_user_confirms_the_addition_of_the_parameter_by_clicking_on_the_save_button() {
tc.saveassign();

	}

	@Then("the user exits the parameter addition process by clicking the Close button")
	public void the_user_exits_the_parameter_addition_process_by_clicking_the_close_button() {
tc.closeassign();

	}
	
	
	//

	@Then("the user clicks on the Files button to navigate to the sequence section")
	public void the_user_clicks_on_the_files_button_to_navigate_to_the_sequence_section() {
tc.addseqlink();

	}

	@Then("the user clicks on the expand button next to the Files icon to reveal more options")
	public void the_user_clicks_on_the_expand_button_next_to_the_files_icon_to_reveal_more_options() {
tc.expand();

	}

	@Then("the user selects a group name from the grid by clicking on it")
	public void the_user_selects_a_group_name_from_the_grid_by_clicking_on_it() {
tc.DDG1();

	}

	@Then("the user clicks on the arrow icon to expand the available options")
	public void the_user_clicks_on_the_arrow_icon_to_expand_the_available_options() {

tc.DDd();
	}

	@Then("the user clicks on the Sequence link to open the sequence configuration page")
	public void the_user_clicks_on_the_sequence_link_to_open_the_sequence_configuration_page() {
tc.Sequenc();

	}

	@Then("the user right-clicks on the sequence name to access additional options")
	public void the_user_right_clicks_on_the_sequence_name_to_access_additional_options() throws InterruptedException {
tc.Sequenc1();

	}

	@Then("the user selects Edit Sequence by clicking on it")
	public void the_user_selects_edit_sequence_by_clicking_on_it() {
tc.editsequence();

	}

	@Then("the user rearranges the characteristics by dragging and dropping them into the desired order")
	public void the_user_rearranges_the_characteristics_by_dragging_and_dropping_them_into_the_desired_order() {
tc.draganddrop();

	}

	
	@Then("the user saves the change by clicking the Save button")
	public void the_user_saves_the_change_by_clicking_the_save_button() {
	   tc.save();
	}

	@Then("the user closes the sequence configuration by clicking the Close button")
	public void the_user_closes_the_sequence_configuration_by_clicking_the_close_button() {
tc.close1();

	}



}
