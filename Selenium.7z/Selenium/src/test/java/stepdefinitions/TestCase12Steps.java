	package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.DriverFactory;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.TestCase12Page;
import util.ConfigReader;
import util.ExtentManager;
import util.ExtentReportManager;
import util.StepHelper;

	public class TestCase12Steps {

	private TestCase12Page tc = new TestCase12Page(DriverFactory.getDriver());

	ConfigReader configReader = new ConfigReader();

	 private ExtentTest test;

	  {
	        // Initialize a new test
		  {
		        this.test = ExtentReportManager.getTest();
		    }
	        test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
	    }

	  ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();


	StepHelper stepHelper;

		{
			this.stepHelper = new StepHelper(ExtentManager.getTest()); // Pass ExtentTest from manager
		}
	
	
	
	@When("user is on home page to Verify Range Point Out")
	public void user_is_on_home_page_to_verify_range_point_out() {
		stepHelper.executeStep("User is on home page", () -> {
		});
	}

		@When("The user clicks on the Add Icon to start the process to Verify Range Point Out")
		public void the_user_clicks_on_the_add_icon_to_start_the_process_to_verify_range_point_out() {
			stepHelper.executeStep("User clicks on the add icon", () -> {
				tc.addnew1();
			});
			test.info("user clicks on the add icon to add characteristics");
		}

	@Then("The user clicks on the Add Characteristic link to open the form to Verify Range Point Out")
	public void the_user_clicks_on_the_add_characteristic_link_to_open_the_form_to_verify_range_point_out() throws InterruptedException {
		stepHelper.executeStep("User clicks on the Add Characteristic link", () -> {
            try {
                tc.AddCharLink();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        });

	}

	@Then("The user Expands the Data Group Name dropdown to view the list of data groups to Verify Range Point Out")
	public void the_user_expands_the_data_group_name_dropdown_to_view_the_list_of_data_groups_to_verify_range_point_out() throws InterruptedException {
tc.DDN();

	}

	@Then("The user Selects the desired data group from the dropdown to Verify Range Point Out")
	public void the_user_selects_the_desired_data_group_from_the_dropdown_to_verify_range_point_out() throws InterruptedException {
tc.DG();

	}

	@Then("The user Opens the Part dropdown to view the list of available parts to Verify Range Point Out")
	public void the_user_opens_the_part_dropdown_to_view_the_list_of_available_parts_to_verify_range_point_out() throws InterruptedException {
tc.PN();

	}

	@Then("The user Selects the appropriate part from the dropdown to Verify Range Point Out")
	public void the_user_selects_the_appropriate_part_from_the_dropdown_to_verify_range_point_out() throws InterruptedException {

tc.PART();
	}

	@Then("The userEnters the Characteristic Name in the respective input field to Verify Range Point Out")
	public void the_user_enters_the_characteristic_name_in_the_respective_input_field_to_verify_range_point_out() throws InterruptedException {
tc.Char();

	}

	@Then("The user Clicks the Add button to confirm the characteristic details to Verify Range Point Out")
	public void the_user_clicks_the_add_button_to_confirm_the_characteristic_details_to_verify_range_point_out() throws InterruptedException {
tc.AD();

	}

	@Then("The user Inputs the Upper Spec value in the corresponding input field to Verify Range Point Out")
	public void the_user_inputs_the_upper_spec_value_in_the_corresponding_input_field_to_verify_range_point_out() throws InterruptedException {
tc.upperspec();

	}

	@Then("The user Provides the Lower Spec value in the respective input field to Verify Range Point Out")
	public void the_user_provides_the_lower_spec_value_in_the_respective_input_field_to_verify_range_point_out() throws InterruptedException {
tc.lowerspec();

	}

	@Then("the user Specifies the Subgroup Size to define grouping to Verify Range Point Out")
	public void the_user_specifies_the_subgroup_size_to_define_grouping_to_verify_range_point_out() throws InterruptedException {
	   tc.subsize();
	}

	@Then("the user enters upperspec reasonable Limits to Verify Range Point Out")
	public void the_user_enters_upperspec_reasonable_limits_to_verify_range_point_out() throws InterruptedException {
	    tc.upperlimit();
	}

	@Then("the user enters lowerspec reasonable Limits to Verify Range Point Out")
	public void the_user_enters_lowerspec_reasonable_limits_to_verify_range_point_out() throws InterruptedException {
	   tc.lowerlimit();
	}




	@Then("user clicks on save button to save charteristics data to Verify Range Point Out")
	public void user_clicks_on_save_button_to_save_charteristics_data_to_verify_range_point_out() throws InterruptedException {
		tc.savechar();

	}

	@Then("user Clicks on close button to Verify Range Point Out")
	public void user_clicks_on_close_button_to_verify_range_point_out() throws InterruptedException {
	 tc.closechar();
	}


	

	@Then("the user clicks on the Files button to navigate to the sequence section  to Verify Range Point Out")
	public void the_user_clicks_on_the_files_button_to_navigate_to_the_sequence_section_to_verify_range_point_out() {
tc.addseqlink();

	}

	@Then("the user clicks on the expand button next to the Files icon to reveal more options to Verify Range Point Out")
	public void the_user_clicks_on_the_expand_button_next_to_the_files_icon_to_reveal_more_options_to_verify_range_point_out() {
tc.expand();

	}

	@Then("the user selects a group name from the grid by clicking on it to Verify Range Point Out")
	public void the_user_selects_a_group_name_from_the_grid_by_clicking_on_it_to_verify_range_point_out() {
tc.DDG1();

	}

	@Then("the user clicks on the arrow icon to expand the available options to Verify Range Point Out")
	public void the_user_clicks_on_the_arrow_icon_to_expand_the_available_options_to_verify_range_point_out() {
tc.DDd();

	}

	@Then("the user clicks on the Sequence link to open the sequence configuration page to Verify Range Point Out")
	public void the_user_clicks_on_the_sequence_link_to_open_the_sequence_configuration_page_to_verify_range_point_out() {
tc.Sequenc();

	}

	@Then("the user right-clicks on the sequence name to access additional options to Verify Range Point Out")
	public void the_user_right_clicks_on_the_sequence_name_to_access_additional_options_to_verify_range_point_out() throws InterruptedException {
tc.Sequenc1();

	}

	@Then("the user selects Edit Sequence by clicking on it to Verify Range Point Out")
	public void the_user_selects_edit_sequence_by_clicking_on_it_to_verify_range_point_out() {
tc.editsequence();

	}

	@Then("the user rearranges the characteristics by dragging and dropping them into the desired order to Verify Range Point Out")
	public void the_user_rearranges_the_characteristics_by_dragging_and_dropping_them_into_the_desired_order_to_verify_range_point_out() {
tc.draganddrop();

	}

	@Then("the user saves the changes by clicking the Save button to Verify Range Point Out")
	public void the_user_saves_the_changes_by_clicking_the_save_button_to_verify_range_point_out() {

tc.save();
	}

	@Then("the user closes the sequence configuration by clicking the Close button to Verify Range Point Out")
	public void the_user_closes_the_sequence_configuration_by_clicking_the_close_button_to_verify_range_point_out() {

tc.close1();
	}



}
