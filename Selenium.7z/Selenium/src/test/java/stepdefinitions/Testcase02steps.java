package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.DriverFactory;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.TestCase02Page;
import util.ConfigReader;
import util.ExtentReportManager;

public class Testcase02steps {


	private TestCase02Page tc = new TestCase02Page(DriverFactory.getDriver());

	ConfigReader configReader = new ConfigReader();

	private ExtentTest test;

	{
		// Initialize a new test
		{
			this.test = ExtentReportManager.getTest();
		}
		test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
	}

	ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();


//	chart

	@Then("user clicks on add icon to initiate the chart overview process")
	public void user_clicks_on_add_icon_to_initiate_the_chart_overview_process() {
		tc.addnew11();
	}

	@Then("user click on add charecterstics button to create the chart")
	public void user_click_on_add_charecterstics_button_to_create_the_chart() throws InterruptedException {
		tc.AddCharLink();
	}

	@Then("user clicks on the data group name dropdown to search available data groups")
	public void user_clicks_on_the_data_group_name_dropdown_to_search_available_data_groups() throws InterruptedException {
		tc.DDN();
	}

	@Then("user selects a data group from the dropdown to select destination datagroup")
	public void user_selects_a_data_group_from_the_dropdown_to_select_destination_datagroup() throws InterruptedException {
		tc.DG();
	}

	@Then("user clicks on the part dropdown to search available parts")
	public void user_clicks_on_the_part_dropdown_to_search_available_parts() throws InterruptedException {
		tc.PN();
	}

	@Then("user selects a part from the dropdown to add characteristic to part")
	public void user_selects_a_part_from_the_dropdown_to_add_characteristic_to_part() throws InterruptedException {
		tc.PART();
	}

	@Then("user enters the Characteristic Name in the Characteristic input field")
	public void user_enters_the_characteristic_name_in_the_characteristic_input_field() throws InterruptedException {
		tc.Char();
	}

	@Then("user click on add button to varify TestCase03")
	public void user_click_on_add_button_to_varify_test_case03() {
		tc.charaaddbutton();
		ExtentCucumberAdapter.addTestStepLog("user clicked on add button");
	}

	@Then("user enter upperspc to varify TestCase03")
	public void user_enter_upperspc_to_varify_test_case03() {
		tc.upperspec();

		ExtentCucumberAdapter.addTestStepLog("user entered upper spec value");
	}

	@Then("user enter lower spec to varify TestCase03")
	public void user_enter_lower_spec_to_varify_test_case03() {
		tc.lowerspec();
		ExtentCucumberAdapter.addTestStepLog("user entered lower spec value");
	}

	@Then("user enter Subgrop size to varify TestCase03")
	public void user_enter_subgrop_size_to_varify_test_case03() {
		tc.subsize();
		ExtentCucumberAdapter.addTestStepLog("user entered subgroup size value");
	}


	@Then("user click on save button to varify TestCase03")
	public void user_click_on_save_button_to_varify_test_case03() {
		tc.savechar();
		ExtentCucumberAdapter.addTestStepLog("user clicked on  save button to save charecterstics");

	}

	@Then("user clicks on cause tab to add cause to varify TestCase03")
	public void user_clicks_on_cause_tab_to_add_cause_to_varify_test_case03() {
		tc.cntab();
	}

	@Then("user clicks on add cause button to verify testcase03")
	public void user_clicks_on_add_cause_button_to_verify_testcase03() {
		tc.addicon();
	}

	@Then("user enters cause name to verify testcase03")
	public void user_enters_cause_name_to_verify_testcase03() {
		tc.Entercasue();
	}

	@Then("user clicks on save button to verify testcase03")
	public void user_clicks_on_save_button_to_verify_testcase03() {
		tc.savecause();
	}

	@Then("user clicks on alarms and restication tab to verify testcase03")
	public void user_clicks_on_alarms_and_restication_tab_to_verify_testcase03() {
		tc.alarmstab();
	}

	@Then("user clicks on Force cause note on out of control or alarm condition check box")
	public void user_clicks_on_force_cause_note_on_out_of_control_or_alarm_condition_check_box() {
		tc.restication();
	}

	@Then("user clicks on save button to save the alarms settings")
	public void user_clicks_on_save_button_to_save_the_alarms_settings() {
		tc.saverr();
	}

	@Then("user click on conntrol chart preferences to varify TestCase03")
	public void user_click_on_conntrol_chart_preferences_to_varify_test_case03() throws InterruptedException {
		Thread.sleep(1000);
		tc.controlcahrt();
		ExtentCucumberAdapter.addTestStepLog("user clicked on control chart preferences menu");

	}

	@Then("user click on analysis tab to varify TestCase03")
	public void user_click_on_analysis_tab_to_varify_test_case03() throws InterruptedException {
		Thread.sleep(1000);
		tc.Analisys();
		ExtentCucumberAdapter.addTestStepLog("user clicked on analisys tab");
	}

	@Then("user click on define run dropdown to varify TestCase03")
	public void user_click_on_define_run_dropdown_to_varify_test_case03() {
		tc.DefieRun();
		ExtentCucumberAdapter.addTestStepLog("user select define run from the dropdown");
	}

	@Then("user click on define trend dropdown to varify TestCase03")
	public void user_click_on_define_trend_dropdown_to_varify_test_case03() {
		tc.DefineTrend();
		ExtentCucumberAdapter.addTestStepLog("user select define trend down from dropdown");
	}


	@Then("user click on save to varify TestCase03")
	public void user_click_on_save_to_varify_test_case03() throws InterruptedException {
		Thread.sleep(1000);
		tc.saveDD();
		ExtentCucumberAdapter.addTestStepLog("user clicked on  save button to save control chart preferences");
	}



	@Then("user click on close button to varify TestCase03")
	public void user_click_on_close_button_to_varify_test_case03() throws InterruptedException {
		tc.closechar();
		ExtentCucumberAdapter.addTestStepLog("user clicked closed button after saving control chart preferences");
	}


	//use in function

	@Then("user click on configuration link to verify parameter use in fucntion")
	public void user_click_on_configuration_link_to_verify_parameter_use_in_fucntion() throws InterruptedException {
		Thread.sleep(1000);
		tc.clickconfiguration01();
		ExtentCucumberAdapter.addTestStepLog("user clicked on configuration link to create parameters ");
	}

	@Then("user click on add para link to verify parameter use in fucntion")
	public void user_click_on_add_para_link_to_verify_parameter_use_in_fucntion() throws InterruptedException {
		Thread.sleep(1000);
		tc.clickaddpara2();
		ExtentCucumberAdapter.addTestStepLog("user clicked on add parameetr icon to create parameters ");
	}

	@Then("user enter parameter name for check box")
	public void user_enter_parameter_name_for_check_box() {
		tc.sendparaname01();
		ExtentCucumberAdapter.addTestStepLog("user entered parameter name");
	}

	@Then("user click on use in fucntion check box")
	public void user_click_on_use_in_fucntion_check_box() {
		tc.Useinfunction();
		ExtentCucumberAdapter.addTestStepLog("user clicked on use in function check box ");
	}

	@Then("user click on save button for number in fucntion")
	public void user_click_on_save_button_for_number_in_fucntion() {
		tc.save01();
		ExtentCucumberAdapter.addTestStepLog("user clicked on save button to save parameter ");
	}

	@Then("user click on close button for number in fucntion")
	public void user_click_on_close_button_for_number_in_fucntion() {
		tc.close01();
		ExtentCucumberAdapter.addTestStepLog("user clicked on close button after saving parameter");
	}


	//require parameter entry

	@When("user click on add para link to verify require parameter entry")
	public void user_click_on_add_para_link_to_verify_require_parameter_entry() throws InterruptedException {
		Thread.sleep(1000);
		tc.clickaddpara3();
		ExtentCucumberAdapter.addTestStepLog("user clicked on add parameter link to create parameter");
	}

	@Then("user enter parameter name for require parameter entry")
	public void user_enter_parameter_name_for_require_parameter_entry() throws InterruptedException {
		tc.Sendparametername();
		ExtentCucumberAdapter.addTestStepLog("user entered parameter name in input textfiled ");
	}

	@Then("user click on require parameter entry check box")
	public void user_click_on_require_parameter_entry_check_box() {
		tc.requireparameter();
		ExtentCucumberAdapter.addTestStepLog("user clicked on require parameter entry check box ");
	}

	@Then("user click on save button for require parameter")
	public void user_click_on_save_button_for_require_parameter() {
		tc.save2();
		ExtentCucumberAdapter.addTestStepLog("user  clicked save buton to save require parameter entry ");

	}

	@Then("user click on close button for require parameter")
	public void user_click_on_close_button_for_require_parameter() throws InterruptedException {
		tc.close2();
		ExtentCucumberAdapter.addTestStepLog("user clicked on close button after saving parameter ");

	}


	//assing para to part

	@Then("user click on files icons to add parameter to part to verify TestCase03")
	public void user_click_on_files_icons_to_add_parameter_to_part_to_verify_test_case03() {
		tc.filesicon();
		ExtentCucumberAdapter.addTestStepLog("user clicked on files tab");
	}

	@Then("user click on add icon for adding para to part to verify TestCase03")
	public void user_click_on_add_icon_for_adding_para_to_part_to_verify_test_case03() {
		tc.Addptp();
		ExtentCucumberAdapter.addTestStepLog("user clicked on add icon to assign parameter to part");

	}

	@Then("user click on assign para to part to verify  TestCase03")
	public void user_click_on_assign_para_to_part_to_verify_test_case03() {
		tc.Assignparaicon();
		ExtentCucumberAdapter.addTestStepLog("user clicked on assign parameter to part to link");
	}

	@Then("user click on group dropdown to verify testcase02 to verify TestCase03")
	public void user_click_on_group_dropdown_to_verify_testcase02_to_verify_test_case03() {
		tc.datadropdown();
		ExtentCucumberAdapter.addTestStepLog("user clicked on datagroup dropdown to assign parameter");
	}

	@Then("user select data group to verify  TestCase03")
	public void user_select_data_group_to_verify_test_case03() {
		tc.selectgrp();
		ExtentCucumberAdapter.addTestStepLog("user selected  datagroup from dropdown");

	}

	@Then("user click on part dropdown to verify  TestCase03")
	public void user_click_on_part_dropdown_to_verify_test_case03() {
		tc.partdropdown();
		ExtentCucumberAdapter.addTestStepLog("user clicked on part dropdown ");

	}

	@Then("user clicks on part to assign parameters to part")
	public void user_clicks_on_part_to_assign_parameters_to_part() {
		tc.selectpartpara();
	}


	@Then("user drag and drop the privious parameters")
	public void user_drag_and_drop_the_privious_parameters() {
		tc.checkallbox();
	}

	@Then("user drag and drop the new parameters to part")
	public void user_drag_and_drop_the_new_parameters_to_part() {
		tc.checkallbox1();
	}

	@Then("user click on save button for adding para to part to verify TestCase03")
	public void user_click_on_save_button_for_adding_para_to_part_to_verify_test_case03() {
		tc.saveassign();
		ExtentCucumberAdapter.addTestStepLog("user clicked on save button to save parameter to part");
	}

	@Then("user clicks on assign button to save parameters verify testcase03")
	public void user_clicks_on_assign_button_to_save_parameters_verify_testcase03() throws InterruptedException {
		Thread.sleep(2000);
		tc.assignlink();
	}


	@Then("user click on close button  for adding para to part to verify TestCase03")
	public void user_click_on_close_button_for_adding_para_to_part_to_verify_test_case03() throws InterruptedException {
		tc.closeassign();
		ExtentCucumberAdapter.addTestStepLog("user clicked on close button after saving parameter to part");
	}


	//creating sequence


	@Then("the user clicks on the Files button to verify testcase03")
	public void the_user_clicks_on_the_files_button_to_verify_testcase03() {
		tc.addseqlink();

	}

	@Then("the user clicks the expand button next to the Files icon  to verify testcase03")
	public void the_user_clicks_the_expand_button_next_to_the_files_icon_to_verify_testcase03() {
		tc.expand();
	}

	@Then("user clicks on downarrow button in the grid")
	public void user_clicks_on_downarrow_button_in_the_grid() {
		tc.down();
	}

	@Then("user clicks on datagroup check box")
	public void user_clicks_on_datagroup_check_box() {
		tc.DDG();
	}

	@Then("user click on ok button to close the")
	public void user_click_on_ok_button_to_close_the() {
		tc.okg();
	}

	@Then("the user selects a group name in the grid by clicking on it  to verify testcase03")
	public void the_user_selects_a_group_name_in_the_grid_by_clicking_on_it_to_verify_testcase03() {
		tc.DDG1();
	}

	@Then("the user clicks on the arrow icon to expand the options  to verify testcase03")
	public void the_user_clicks_on_the_arrow_icon_to_expand_the_options_to_verify_testcase03() {
		tc.DDd();
	}

	@Then("the user clicks on the Sequence link to open it  to verify testcase03")
	public void the_user_clicks_on_the_sequence_link_to_open_it_to_verify_testcase03() {
		tc.Sequenc();
	}

	@Then("the user right-clicks on the sequence name to access additional options  to verify testcase03")
	public void the_user_right_clicks_on_the_sequence_name_to_access_additional_options_to_verify_testcase03() throws InterruptedException {
		tc.Sequenc1();
	}

	@Then("the user selects Edit Sequence by clicking on it  to verify testcase03")
	public void the_user_selects_edit_sequence_by_clicking_on_it_to_verify_testcase03() {
		tc.editsequence();
	}

	@Then("the user drags and drops the characteristics to rearrange them to verify testcase03")
	public void the_user_drags_and_drops_the_characteristics_to_rearrange_them_to_verify_testcase03() {
		tc.draganddrop();
	}


@Then("the user saves the changes by clicking the Save button  to verify testcase03")
public void the_user_saves_the_changes_by_clicking_the_save_button_to_verify_testcase03() {
    tc.save();
}

@Then("the user closes the sequence by clicking the Close button to verify testcase03")
public void the_user_closes_the_sequence_by_clicking_the_close_button_to_verify_testcase03() {
	tc.close1();


}
	
//cretaing network
	
	
	
	


	
	
	//edit01


@Then("user click on page name for edit and to verify testcase03")
public void user_click_on_page_name_for_edit_and_to_verify_testcase03() {
   
}
@Then("user click on edit icon to verify testcase03")
public void user_click_on_edit_icon_to_verify_testcase03() {
   
}

@Then("user enter  to verify testcase03")
public void user_enter_to_verify_testcase03() {
   
}

@Then("user click on date input field to verify testcase03")
public void user_click_on_date_input_field_to_verify_testcase03() {
    
 
}

@Then("user click on time input field to verify testcase03")
public void user_click_on_time_input_field_to_verify_testcase03() {
    
 
}

@Then("user select value from dropdown from parameter to verify testcase03")
public void user_select_value_from_dropdown_from_parameter_to_verify_testcase03() {
    
 
}

@Then("user enter alpha value for alpha validation to verify testcase03")
public void user_enter_alpha_value_for_alpha_validation_to_verify_testcase03() {
    
 
}

@Then("user enter subgroup size1 to verify testcase03")
public void user_enter_subgroup_size1_to_verify_testcase03() {
    
 
}

@Then("user enter subgroup size2 to verify testcase03")
public void user_enter_subgroup_size2_to_verify_testcase03() {
    
 
}

@Then("user click on save button for chart01 to verify testcase03")
public void user_click_on_save_button_for_chart01_to_verify_testcase03() {
    
 
}

@Then("user fetch the  of the page to verify testcase03")
public void user_fetch_the__of_the_page_to_verify_testcase03() {
    
	
	//2
 
}

@Then("user click on time2 input field to verify testcase03")
public void user_click_on_time2_input_field_to_verify_testcase03() {
    
 
}

@Then("user enter subgroup size12 to verify testcase03")
public void user_enter_subgroup_size12_to_verify_testcase03() {
    
 
}

@Then("user enter subgroup size22 to verify testcase03")
public void user_enter_subgroup_size22_to_verify_testcase03() {
    
 
}


@Then("user click on save button to varify require para entry")
public void user_click_on_save_button_to_varify_require_para_entry() {
  
}

@Then("user click on ok button on the popup")
public void user_click_on_ok_button_on_the_popup() {
   
}

@Then("user enter value for require parameter field")
public void user_enter_value_for_require_parameter_field() {
    
}



@Then("user click on save2 button for chart01 to verify testcase03")
public void user_click_on_save2_button_for_chart01_to_verify_testcase03() {
    
 
}

@Then("user fetch the 2 of the page  to verify testcase03")
public void user_fetch_the_2_of_the_page_to_verify_testcase03() {
    
 
}


//3

@Then("user click on time3 input field to verify  testcase03")
public void user_click_on_time3_input_field_to_verify_testcase03() {
    
 
}

@Then("user enter subgroup size3 to verify  testcase03")
public void user_enter_subgroup_size3_to_verify_testcase03() {
    
 
}

@Then("user enter subgroup size33 to verify  testcase03")
public void user_enter_subgroup_size33_to_verify_testcase03() {
    
 
}

@Then("user click on save3 button for chart01 to verify  testcase03")
public void user_click_on_save3_button_for_chart01_to_verify_testcase03() {
    
 
}

@Then("user fetch the 3 of the page  to verify  testcase03")
public void user_fetch_the_3_of_the_page_to_verify_testcase03() {
    
 
	
	//4
	
}

@Then("user click on time4 input field to verify testcase03")
public void user_click_on_time4_input_field_to_verify_testcase03() {
    
 
}

@Then("user enter subgroup size4 to verify testcase03")
public void user_enter_subgroup_size4_to_verify_testcase03() {
    
 
}

@Then("user enter subgroup size44 to verify testcase03")
public void user_enter_subgroup_size44_to_verify_testcase03() {
    
 
}

@Then("user click on save4 button for chart01 to verify testcase03")
public void user_click_on_save4_button_for_chart01_to_verify_testcase03() {
    
 
}

@Then("user fetch the 4 of the page  to verify testcase03")
public void user_fetch_the_4_of_the_page_to_verify_testcase03() {
    
 
	
	//5
}

@Then("user click on time5 input field to verify testcase03")
public void user_click_on_time5_input_field_to_verify_testcase03() {
    
 
}

@Then("user enter subgroup size5 to verify testcase03")
public void user_enter_subgroup_size5_to_verify_testcase03() {
    
 
}

@Then("user enter subgroup size55 to verify testcase03")
public void user_enter_subgroup_size55_to_verify_testcase03() {
    
 
}

@Then("user click on save5 button for chart01 to verify testcase03")
public void user_click_on_save5_button_for_chart01_to_verify_testcase03() {
    
 
}

@Then("user fetch the 5 of the page  to verify testcase03")
public void user_fetch_the_5_of_the_page_to_verify_testcase03() {
    
 
}


//6

@Then("user click on time6 inputfield to verify testcase03")
public void user_click_on_time6_inputfield_to_verify_testcase03() {
    
 
}

@Then("user enter subgroup size6  to verify testcase03")
public void user_enter_subgroup_size6_to_verify_testcase03() {
    
 
}

@Then("user enter subgroup size66  to verify testcase03")
public void user_enter_subgroup_size66_to_verify_testcase03() {
    
 
}

@Then("user click on save6 button for chart01 to verify testcase03")
public void user_click_on_save6_button_for_chart01_to_verify_testcase03() {
    
 
}

@Then("user fetch the 6 of the page  to verify testcase03")
public void user_fetch_the_6_of_the_page_to_verify_testcase03() {
    
 
}



//7

@Then("user click on time7 input field to verify testcase03")
public void user_click_on_time7_input_field_to_verify_testcase03() {
    
 
}

@Then("user enter subgroup size7  to verify testcase03")
public void user_enter_subgroup_size7_to_verify_testcase03() {
    
 
}

@Then("user enter subgroup size77  to verify testcase03")
public void user_enter_subgroup_size77_to_verify_testcase03() {
    
 
}

@Then("user click on save7 button for chart01 to verify testcase03")
public void user_click_on_save7_button_for_chart01_to_verify_testcase03() {
    
 
}

@Then("user fetch the 7 of the page  to verify testcase03")
public void user_fetch_the_7_of_the_page_to_verify_testcase03() {
    
 
}

	
	
	
@Then("user click on save button for dropdown values to varify TestCase03")
public void user_click_on_save_button_for_dropdown_values_to_varify_test_case03() {
    
   
}}
