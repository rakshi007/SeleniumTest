package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.DriverFactory;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.TestCase07Page;
import util.ConfigReader;
import util.ExtentReportManager;

public class TestStatus07 {

	
	private TestCase07Page tc = new TestCase07Page(DriverFactory.getDriver());

	ConfigReader configReader = new ConfigReader();

	 private ExtentTest test;

	  {
	        // Initialize a new test
		  {
		        this.test = ExtentReportManager.getTest();
		    }
	        test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
	    }

	  ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();

	
	
	
	
	
	
	@When("user clicks on network icon to verify  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_network_icon_to_verify_to_verify_shift_up(Integer int1, Integer int2) {
		
tc.network1();

	}

	@Then("user clicks on page name for edit to verify  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_page_name_for_edit_to_verify_to_verify_shift_up(Integer int1, Integer int2) {
		tc.clickvaripage();

	}

	@Then("user clicks on edit icon to verify  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_edit_icon_to_verify_to_verify_shift_up(Integer int1, Integer int2) {

		tc.edit07();
	}

	@When("user clicks on date input field  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_date_input_field_to_verify_shift_up(Integer int1, Integer int2) {
		tc.date();

	}

	@Then("user clicks on time1 input field  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_time1_input_field_to_verify_shift_up(Integer int1, Integer int2) {
		tc.time();

	}

	@Then("user enters subgroup size for one11  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_one11_to_verify_shift_up(Integer int1, Integer int2) {

		tc.subgroup01();
	}

	@Then("user enters subgroup size for two12  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_two12_to_verify_shift_up(Integer int1, Integer int2) {

tc.subgroup02();
	}

	@Then("user enters subgroup size for one13 to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_one13_to_verify_shift_up(Integer int1, Integer int2) {
tc.subgroup03();

	}

	@Then("user enters subgroup size for two14 to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_two14_to_verify_shift_up(Integer int1, Integer int2) {

tc.subgroup04();
	}

	@Then("user enters lookup source value A to verify Shift {int}\\/{int} Up")
	public void user_enters_lookup_source_value_a_to_verify_shift_up(Integer int1, Integer int2) {
tc.sourceA();

	}

	@Then("user fetch the lookup source value A to verify Shift {int}\\/{int} Up")
	public void user_fetch_the_lookup_source_value_a_to_verify_shift_up(Integer int1, Integer int2) {
tc.sourceAget();

	}

	@Then("user clicks on save button for chart1  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_save_button_for_chart1_to_verify_shift_up(Integer int1, Integer int2) {
tc.savechart01();

	}

	@Then("user fetches the 01 of the page  to verify Shift {int}\\/{int} Up")
	public void user_fetches_the_01_of_the_page_to_verify_shift_up(Integer int1, Integer int2) {
tc.getText();

	}
	
	
	
	
	
	

	@When("user clicks on time2 input field  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_time2_input_field_to_verify_shift_up(Integer int1, Integer int2) {
tc.time2();

	}

	@Then("user enters subgroup size for one21  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_one21_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		Thread.sleep(2000);
tc.subgroup11();

	}

	@Then("user enters subgroup size for two22 to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_two22_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
tc.subgroup12();

	}

	@Then("user enters subgroup size for one23  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_one23_to_verify_shift_up(Integer int1, Integer int2) {
tc.subgroup13();

	}

	@Then("user enters subgroup size for two24 to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_two24_to_verify_shift_up(Integer int1, Integer int2) {

tc.subgroup14();
	}

	@Then("user enters lookup source value B to verify Shift {int}\\/{int} Up")
	public void user_enters_lookup_source_value_b_to_verify_shift_up(Integer int1, Integer int2) {
tc.sourceB();

	}

	@Then("user fetch the lookup source value B to verify Shift {int}\\/{int} Up")
	public void user_fetch_the_lookup_source_value_b_to_verify_shift_up(Integer int1, Integer int2) {
tc.sourceBget();

	}

	@Then("user fetches the validation data01  to verify Shift {int}\\/{int} Up")
	public void user_fetches_the_validation_data01_to_verify_shift_up(Integer int1, Integer int2) {
tc.validateDataValues01();

	}

	@Then("user clicks on save button for chart2  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_save_button_for_chart2_to_verify_shift_up(Integer int1, Integer int2) {
tc.Savechart02();

	}

	@Then("user fetches the 02 of the page  to verify Shift {int}\\/{int} Up")
	public void user_fetches_the_02_of_the_page_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		Thread.sleep(2000);
tc.GetText02();

	}

	
	
	
	
	@When("user clicks on time3 input field  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_time3_input_field_to_verify_shift_up(Integer int1, Integer int2) {
tc.time3();

	}

	@Then("user enters subgroup size for one31  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_one31_to_verify_shift_up(Integer int1, Integer int2) {

tc.subgroup21();
	}

	@Then("user enters subgroup size for two32 to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_two32_to_verify_shift_up(Integer int1, Integer int2) {

tc.subgroup22();
	}

	@Then("user enters subgroup size for one33  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_one33_to_verify_shift_up(Integer int1, Integer int2) {
tc.subgroup23();

	}

	@Then("user enters subgroup size for two34  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_two34_to_verify_shift_up(Integer int1, Integer int2) {

tc.subgroup24();
	}

	@Then("user enters lookup source value C to verify Shift {int}\\/{int} Up")
	public void user_enters_lookup_source_value_c_to_verify_shift_up(Integer int1, Integer int2) {

tc.sourceC();
	}

	@Then("user fetch the lookup source value C to verify Shift {int}\\/{int} Up")
	public void user_fetch_the_lookup_source_value_c_to_verify_shift_up(Integer int1, Integer int2) {
tc.sourceCget();

	}

	@Then("user fetches the validation data02  to verify Shift {int}\\/{int} Up")
	public void user_fetches_the_validation_data02_to_verify_shift_up(Integer int1, Integer int2) {
tc.validateDataValues02();

	}

	@Then("user clicks on save button for chart3  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_save_button_for_chart3_to_verify_shift_up(Integer int1, Integer int2) {

tc.savechart331();
	}

	@Then("user fetches the 03 of the page  to verify Shift {int}\\/{int} Up")
	public void user_fetches_the_03_of_the_page_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		Thread.sleep(2000);
tc.getText3();
	}
	
	
	
	

	@When("user clicks on time4 input field  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_time4_input_field_to_verify_shift_up(Integer int1, Integer int2) {
tc.time4();

	}

	@Then("user enters subgroup size for one41  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_one41_to_verify_shift_up(Integer int1, Integer int2) {

tc.subgroup31();
	}

	@Then("user enters subgroup size for two42  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_two42_to_verify_shift_up(Integer int1, Integer int2) {
tc.subgroup32();

	}

	@Then("user enters subgroup size for one43  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_one43_to_verify_shift_up(Integer int1, Integer int2) {
tc.subgroup33();

	}

	@Then("user enters subgroup size for two44  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_two44_to_verify_shift_up(Integer int1, Integer int2) {
tc.subgroup34();

	}

	@Then("user fetches the validation data03  to verify Shift {int}\\/{int} Up")
	public void user_fetches_the_validation_data03_to_verify_shift_up(Integer int1, Integer int2) {
tc.validateDataValues03();

	}

	@Then("user enters lookup source value D to verify Shift {int}\\/{int} Up")
	public void user_enters_lookup_source_value_d_to_verify_shift_up(Integer int1, Integer int2) {

tc.sourceD();
	}

	@Then("user fetch the lookup source value D to verify Shift {int}\\/{int} Up")
	public void user_fetch_the_lookup_source_value_d_to_verify_shift_up(Integer int1, Integer int2) {

tc.sourceDget();
	}

	@Then("user clicks on save button for chart4  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_save_button_for_chart4_to_verify_shift_up(Integer int1, Integer int2) {

tc.savechart4();
	}

	@Then("user fetches the 04 of the page  to verify Shift {int}\\/{int} Up")
	public void user_fetches_the_04_of_the_page_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		Thread.sleep(2000);
tc.getText4();

	}

	
	
	
	@When("user clicks on time5 input field  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_time5_input_field_to_verify_shift_up(Integer int1, Integer int2) {
tc.time5();

	}

	@Then("user enters subgroup size for one51  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_one51_to_verify_shift_up(Integer int1, Integer int2) {
tc.subgroup41();

	}

	@Then("user enters subgroup size for two52  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_two52_to_verify_shift_up(Integer int1, Integer int2) {
tc.subgroup42();

	}
	
	@Then("user enters subgroup size for two53  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_two53_to_verify_shift_up(Integer int1, Integer int2) {
		tc.subgroup43(); 
	}

	@Then("user enters subgroup size for two54  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_two54_to_verify_shift_up(Integer int1, Integer int2) {
		tc.subgroup44();
	}




	@Then("user fetches the validation data53  to verify Shift {int}\\/{int} Up")
	public void user_fetches_the_validation_data53_to_verify_shift_up(Integer int1, Integer int2) {
tc.validateDataValues04();

	}

	@Then("user clicks on save button for chart54  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_save_button_for_chart54_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
tc.savechart5();
		
	}

	@Then("user fetches the 05 of the page  to verify Shift {int}\\/{int} Up")
	public void user_fetches_the_05_of_the_page_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		Thread.sleep(2000);
tc.getText5();

	}
	
	
	
	
	
	
	
	
	
	

	@When("user clicks on time6 input field  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_time6_input_field_to_verify_shift_up(Integer int1, Integer int2) {
tc.time6();

	}

	@Then("user enters subgroup size for one61  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_one61_to_verify_shift_up(Integer int1, Integer int2) {

tc.subgroup61();
	}

	@Then("user enters subgroup size for two62  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_two62_to_verify_shift_up(Integer int1, Integer int2) {
tc.subgroup62();

	}

	@Then("user enters subgroup size for one63  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_one63_to_verify_shift_up(Integer int1, Integer int2) {
		tc.subgroup63();

	}

	@Then("user enters subgroup size for two64  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_two64_to_verify_shift_up(Integer int1, Integer int2) {

		tc.subgroup64();
	}

	@Then("user fetches the validation data05  to verify Shift {int}\\/{int} Up")
	public void user_fetches_the_validation_data05_to_verify_shift_up(Integer int1, Integer int2) {
tc.validateDataValues05();

	}

	@Then("user clicks on save button for chart6  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_save_button_for_chart6_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
tc.savechart6();

	}

	
	@Then("user clicks on cancel button to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_cancel_button_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		Thread.sleep(2000);
	   tc.Cancel8();
	}




	@Then("user fetches the 06 of the page  to verify Shift {int}\\/{int} Up")
	public void user_fetches_the_06_of_the_page_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		Thread.sleep(2000);
tc.getText6();
	}

	
	
	@When("user clicks on time7 input field  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_time7_input_field_to_verify_shift_up(Integer int1, Integer int2) {
tc.time7();

	}

	@Then("user enters subgroup size for one71  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_one71_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
Thread.sleep(1000);
tc.subgroup71();
	}

	@Then("user enters subgroup size for two72  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_two72_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		Thread.sleep(1000);
		tc.subgroup72();

	}

	@Then("user enters subgroup size for one73  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_one73_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		Thread.sleep(1000);
		tc.subgroup73();
	}

	@Then("user enters subgroup size for two74  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_two74_to_verify_shift_up(Integer int1, Integer int2) {
		tc.subgroup74();

	}
	
	@Then("user fetches the validation data06  to verify Shift {int}\\/{int} Up")
	public void user_fetches_the_validation_data06_to_verify_shift_up(Integer int1, Integer int2) {

tc.validateDataValues07();
	}
	
	@Then("user clicks on save button to save 7th subgroup to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_save_button_to_save_7th_subgroup_to_verify_shift_up(Integer int1, Integer int2) {
	    tc.savechart71();
	}

	@Then("user clicks on cancel07 button to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_cancel07_button_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
	    tc.Cancel8();
	}
	
	

	@Then("user fetches the 07 of the page  to verify Shift {int}\\/{int} Up")
	public void user_fetches_the_07_of_the_page_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		Thread.sleep(2000);
tc.getText7();
	}

	
	
	@When("user clicks on time08 input field  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_time08_input_field_to_verify_shift_up(Integer int1, Integer int2) {
tc.time8();

	}

	@Then("user enters subgroup size for one81  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_one81_to_verify_shift_up(Integer int1, Integer int2) {
tc.subgroup81();

	}

	@Then("user enters subgroup size for two82  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_two82_to_verify_shift_up(Integer int1, Integer int2) {
		tc.subgroup82();


	}

	@Then("user enters subgroup size for one83  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_one83_to_verify_shift_up(Integer int1, Integer int2) {
		tc.subgroup83();


	}

	@Then("user enters subgroup size for two84  to verify Shift {int}\\/{int} Up")
	public void user_enters_subgroup_size_for_two84_to_verify_shift_up(Integer int1, Integer int2) {
		tc.subgroup84();


	}

	@Then("user fetches the validation data07  to verify Shift {int}\\/{int} Up")
	public void user_fetches_the_validation_data07_to_verify_shift_up(Integer int1, Integer int2) {
tc.validateDataValues07();

	}

	@Then("user clicks on save button for chart8  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_save_button_for_chart8_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
tc.savechart81();

	}

	@Then("user clicks on cancel button for chart08  to verify Shift {int}\\/{int} Up")
	public void user_clicks_on_cancel_button_for_chart08_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {

tc.Cancel8();
	}

	@Then("user fetches the 08 of the page  to verify Shift {int}\\/{int} Up")
	public void user_fetches_the_08_of_the_page_to_verify_shift_up(Integer int1, Integer int2) throws InterruptedException {
		Thread.sleep(2000);
tc.getText8();
	}

	@Then("user fetches the validation data08  to verify Shift {int}\\/{int} Up")
	public void user_fetches_the_validation_data08_to_verify_shift_up(Integer int1, Integer int2) {

tc.validateDataValues08();
	}
	
}
