package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.DriverFactory;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.TestCase03Page;
import util.ConfigReader;
import util.ExtentReportManager;

public class TestStatus03 {

	
	
	private TestCase03Page tc = new TestCase03Page(DriverFactory.getDriver());

	ConfigReader configReader = new ConfigReader();
	
	 private ExtentTest test;

	  {
	        // Initialize a new test
		  {
		        this.test = ExtentReportManager.getTest();
		    }
	        test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
	    }
	
	  ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();




	@When("user clicks on network icon to verify test")
	public void user_clicks_on_network_icon_to_verify_test() {
		tc.network1();
	}

	@Then("user clicks on page name for edit")
	public void user_clicks_on_page_name_for_edit() {
	  tc.clickvaripage();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on page name to enter data");
	}

	@Then("user clicks on edit icon")
	public void user_clicks_on_edit_icon() {
	  tc.editpencil();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on edit icon button");
	}

	@When("user clicks on date input field")
	public void user_clicks_on_date_input_field() {
	  tc.date();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on date input field");
	}

	@Then("user clicks on time input field")
	public void user_clicks_on_time_input_field() {
	  tc.time();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on time input field");
	}

	@Then("user enters subgroup size for one")
	public void user_enters_subgroup_size_for_one() {
	  tc.subgroup01();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data one");
	}

	@Then("user enters subgroup size for two")
	public void user_enters_subgroup_size_for_two() {
	  tc.subgroup02();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data two");
	}

	@Then("user enters subgroup size for three")
	public void user_enters_subgroup_size_for_three() {
	  tc.subgroup03();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data three");
	}

	@Then("user enters subgroup size for four")
	public void user_enters_subgroup_size_for_four() {
	  tc.subgroup04();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data four");
	}

	@Then("user enters value for highlights on content")
	public void user_enters_value_for_highlights_on_content() {
	  tc.Highlites01();
	  ExtentCucumberAdapter.addTestStepLog("user entered values highlights on content");
	}

	@Then("user hovers over the highlights on the content field")
	public void user_hovers_over_the_highlights_on_the_content_field() {
	  tc.mouse();
	  ExtentCucumberAdapter.addTestStepLog("user hovers over on the highlights on content ");
	}


	@Then("user clicks on save button for chart1")
	public void user_clicks_on_save_button_for_chart1() throws InterruptedException {
	   tc.savechart01();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on save button");
	}

	@Then("user fetches the  of the page")
	public void user_fetches_the__of_the_page() {
	  tc.getText();
	   ExtentCucumberAdapter.addTestStepLog("user fetch the  of subgroup 1");
	}
	
	
	

	



	
	
	//edit02
	
	

	@When("user clicks on time2 input field")
	public void user_clicks_on_time2_input_field() throws InterruptedException {
		Thread.sleep(1000);
	  tc.time2();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on time input field");
	}

	@Then("user enters subgroup size for one for chart2")
	public void user_enters_subgroup_size_for_one_for_chart2() throws InterruptedException {
		Thread.sleep(1000);
	  tc.subgroup11();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data one");
	}

	@Then("user enters subgroup size for two for chart2")
	public void user_enters_subgroup_size_for_two_for_chart2() throws InterruptedException {
	  tc.subgroup12();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data two");
	}

	@Then("user enters subgroup size for three for chart2")
	public void user_enters_subgroup_size_for_three_for_chart2() {
	  tc.subgroup113();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data three");
	}

	@Then("user enters subgroup size for four for chart2")
	public void user_enters_subgroup_size_for_four_for_chart2() throws InterruptedException {
	  tc.subgroup14();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data four");
	}

	@Then("user fetch the datavalues01 to verify testcase04")
	public void user_fetch_the_datavalues01_to_verify_testcase04() {
	   tc.validateDataValues01();
	}

	@Then("user clicks on save2 button for chart2")
	public void user_clicks_on_save2_button_for_chart2() {
	   tc.savechart2();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on save button");
	}

	@Then("user fetches the 2 of the page")
	public void user_fetches_the_2_of_the_page() throws InterruptedException {
		Thread.sleep(2000);
	 tc.getText2();
	   ExtentCucumberAdapter.addTestStepLog("user fetch the  of subgroup 2");
	}

	
	
	//edit03
	
	
	
	
	
	
	@When("user clicks on time3 input field")
	public void user_clicks_on_time3_input_field() {
	  
	 tc.time3();
	 ExtentCucumberAdapter.addTestStepLog("user clicked on time input field");
	}

	@Then("user enters subgroup size for one for chart3")
	public void user_enters_subgroup_size_for_one_for_chart3() {
	  tc.subgroup21();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data one");
	}

	@Then("user enters subgroup size for two for chart3")
	public void user_enters_subgroup_size_for_two_for_chart3() {
	  tc.subgroup22();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data two");
	}

	@Then("user enters subgroup size for three for chart3")
	public void user_enters_subgroup_size_for_three_for_chart3() {
	 tc.subgroup23();
	 ExtentCucumberAdapter.addTestStepLog("user entered value for sample data three");
	}

	@Then("user enters subgroup size for four for chart3")
	public void user_enters_subgroup_size_for_four_for_chart3() {
	  tc.subgroup24();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data four");
	}
	@Then("user fetch the datavalues02 to verify testcase04")
	public void user_fetch_the_datavalues02_to_verify_testcase04() {
	   tc.validateDataValues02();
	}

	@Then("user clicks on save3 button for chart3")
	public void user_clicks_on_save3_button_for_chart3() {
	   tc.savechart3();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on save button");
	}

	@Then("user fetches the 3 of the page")
	public void user_fetches_the_3_of_the_page() throws InterruptedException {
		Thread.sleep(2000);
	  tc.getText3();
	   ExtentCucumberAdapter.addTestStepLog("user fetch the  of subgroup 3");
	}

	
	
	//04
	
	
	@When("user clicks on time4 input field")
	public void user_clicks_on_time4_input_field() throws InterruptedException {
		Thread.sleep(1000);
	  tc.time4();
	  ExtentCucumberAdapter.addTestStepLog("user clicked on time input field");
	}

	@Then("user enters subgroup size for one for chart4")
	public void user_enters_subgroup_size_for_one_for_chart4() {
	  tc.subgroup31();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data one");
	 
	}

	@Then("user enters subgroup size for two for chart4")
	public void user_enters_subgroup_size_for_two_for_chart4() {
	 tc.subgroup32();
	 ExtentCucumberAdapter.addTestStepLog("user entered value for sample data two");
	}

	@Then("user enters subgroup size for three for chart4")
	public void user_enters_subgroup_size_for_three_for_chart4() {
	 tc.subgroup33();
	 ExtentCucumberAdapter.addTestStepLog("user entered value for sample data three");
	}

	@Then("user enters subgroup size for four for chart4")
	public void user_enters_subgroup_size_for_four_for_chart4() {
	  tc.subgroup34();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data four");
	}
	
	@Then("user fetch the datavalues03 to verify testcase04")
	public void user_fetch_the_datavalues03_to_verify_testcase04() {
	    tc.validateDataValues03();
	}
	
	@Then("user clicks on save button for chart4")
	public void user_clicks_on_save_button_for_chart4() throws InterruptedException {
		Thread.sleep(1000);
	   tc.savechart4();
	   ExtentCucumberAdapter.addTestStepLog("user clicked on save button");
	}
	@Then("user fetches the  of the page4")
	public void user_fetches_the__of_the_page4() throws InterruptedException {
		Thread.sleep(2000);
	  tc.getText4();
	   ExtentCucumberAdapter.addTestStepLog("user fetch the  of subgroup 4");
	}


	
//05
	@When("user clicks on time5 input field")
	public void user_clicks_on_time5_input_field() {
		 ExtentCucumberAdapter.addTestStepLog("user clicked on time input field");
	 tc.time5();
	}
	@Then("user fetch the datavalues04 to verify testcase04")
	public void user_fetch_the_datavalues04_to_verify_testcase04() {
	  tc.validateDataValues04();
	}
	
	@Then("user enters subgroup size for one for chart5")
	public void user_enters_subgroup_size_for_one_for_chart5() {
	  tc.subgroup41();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data one");
	}
	

	@Then("user enters subgroup size for two for chart5")
	public void user_enters_subgroup_size_for_two_for_chart5() {
	  tc.subgroup42();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data two");
	}

	@Then("user enters subgroup size for three for chart5")
	public void user_enters_subgroup_size_for_three_for_chart5() {
	  tc.subgroup43();
	  ExtentCucumberAdapter.addTestStepLog("user entered value for sample data three");
	}

	@Then("user enters subgroup size for four for chart5")
	public void user_enters_subgroup_size_for_four_for_chart5() {
	 tc.subgroup444();
	 ExtentCucumberAdapter.addTestStepLog("user entered value for sample data four");
	}

	
	

	@Then("user clicks on save button for chart5")
	public void user_clicks_on_save_button_for_chart5() throws InterruptedException {
	    tc.savechart5();
	    ExtentCucumberAdapter.addTestStepLog("user clicked on save button");
	}

	@Then("user clicks on ok button")
	public void user_clicks_on_ok_button() throws InterruptedException {
		tc.okbutton();
	}

	@Then("user select action note from action dropdown")
	public void user_select_action_note_from_action_dropdown() throws InterruptedException {
		tc.Actionselect();
	}

	@Then("user click on sumbit button")
	public void user_click_on_sumbit_button() throws InterruptedException {
		tc.submitcauses();
	}


@Then("user fetch the staus5 of the page")
public void user_fetch_the_staus5_of_the_page() {
   tc.getText05();
   ExtentCucumberAdapter.addTestStepLog("user fetch the  of subgroup 5");  
}
	
	
@Then("user fetch the datavalues05 to verify testcase04")
public void user_fetch_the_datavalues05_to_verify_testcase04() {
   tc.validateDataValues05();
}


}
