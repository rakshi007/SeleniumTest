package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.DriverFactory;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.TestCase04Page;
import util.ConfigReader;
import util.ExtentReportManager;

public class TestCase04Steps 


{
private TestCase04Page tc = new TestCase04Page(DriverFactory.getDriver());

ConfigReader configReader = new ConfigReader();

 private ExtentTest test;

  {
        // Initialize a new test
	  {
	        this.test = ExtentReportManager.getTest();
	    }
        test = ExtentReportManager.createTest("Login Test", "Testing login functionality");
    }

  ExtentTest test1 = ExtentCucumberAdapter.getCurrentStep();






	@When("the user initiates the addition of a characteristic by clicking the add icon")
	public void the_user_initiates_the_addition_of_a_characteristic_by_clicking_the_add_icon() {
	   tc.addnew1();
		
	}

	@Then("the user navigates to the characteristic form by clicking the Add Characteristic link")
	public void the_user_navigates_to_the_characteristic_form_by_clicking_the_add_characteristic_link() throws InterruptedException {
		tc.AddCharLink();
	}

	@Then("the user expands the data group name dropdown to view the available data groups")
	public void the_user_expands_the_data_group_name_dropdown_to_view_the_available_data_groups() throws InterruptedException {
	  tc.DDN();
	}

	@Then("the user selects a data group from the dropdown to associate it with the characteristic")
	public void the_user_selects_a_data_group_from_the_dropdown_to_associate_it_with_the_characteristic() throws InterruptedException {
	  tc.DG();
	}

	@Then("the user opens the part dropdown to view the available parts")
	public void the_user_opens_the_part_dropdown_to_view_the_available_parts() throws InterruptedException {
	 tc.PN();
	}

	@Then("the user selects a part from the dropdown to link it with the characteristic")
	public void the_user_selects_a_part_from_the_dropdown_to_link_it_with_the_characteristic() throws InterruptedException {
	    tc.PART();
	   
	}

	@Then("the user inputs the Characteristic Name in the provided input field")
	public void the_user_inputs_the_characteristic_name_in_the_provided_input_field() throws InterruptedException {
	    tc.Char();
	   
	}

	@Then("the user confirms the characteristic details by clicking the add button")
	public void the_user_confirms_the_characteristic_details_by_clicking_the_add_button() throws InterruptedException {
	    tc.AD();
	   
	}

	@Then("the user enters the Upper Spec value in the corresponding input field")
	public void the_user_enters_the_upper_spec_value_in_the_corresponding_input_field() throws InterruptedException {
	    Thread.sleep(2000);
	   tc.upperspec();
	}

	@Then("the user provides the Lower Spec value in the respective input field")
	public void the_user_provides_the_lower_spec_value_in_the_respective_input_field() throws InterruptedException {
	    tc.lowerspec();
	   
	}

	@Then("the user specifies the Subgroup Size value to define grouping")
	public void the_user_specifies_the_subgroup_size_value_to_define_grouping() throws InterruptedException {
	    tc.subsize();
	   
	}

	@Then("the user saves the characteristic by clicking the save button")
	public void the_user_saves_the_characteristic_by_clicking_the_save_button() throws InterruptedException {
	    tc.savechar();
	   
	}

	
	@Then("the user clicks on the Cause Note icon")
	public void the_user_clicks_on_the_cause_note_icon() throws InterruptedException {
	  tc.causeicon();
		
		
	}

	@Then("the user clicks on the Add Cause icon")
	public void the_user_clicks_on_the_add_cause_icon() throws InterruptedException {
	  
		tc.addcause();
	}

	@Then("the user enters the local cause in the input field")
	public void the_user_enters_the_local_cause_in_the_input_field() throws InterruptedException {
	  tc.inputtext1();
	}

	@Then("the user clicks on the Save button to save the cause")
	public void the_user_clicks_on_the_save_button_to_save_the_cause() throws InterruptedException {
	  tc.add();
	}

	@Then("the user clicks on the Add Cause icon again")
	public void the_user_clicks_on_the_add_cause_icon_again() throws InterruptedException {
	  
		tc.addcause1();
	}

	@Then("the user enters another local cause")
	public void the_user_enters_another_local_cause() throws InterruptedException {
	  tc.inputtext11();
	}

	@Then("the user clicks on the Save button to save the new cause")
	public void the_user_clicks_on_the_save_button_to_save_the_new_cause() throws InterruptedException {
	  tc.add1();
	}

	@Then("the user clicks on the Action Note icon")
	public void the_user_clicks_on_the_action_note_icon() throws InterruptedException {
	
	  tc.Acionicon();
	}
	
	
	@Then("user click on add action button")
	public void user_click_on_add_action_button() throws InterruptedException {
		Thread.sleep(1000);
	  tc.addaction();
	}

	@Then("the user enters the local action in the input field")
	public void the_user_enters_the_local_action_in_the_input_field() throws InterruptedException {
	  tc.action1();
	}

	@Then("the user clicks on the Save button to save the action")
	public void the_user_clicks_on_the_save_button_to_save_the_action() throws InterruptedException {
	  tc.saveaction();
	}

	@Then("the user clicks on the Add Action icon")
	public void the_user_clicks_on_the_add_action_icon() throws InterruptedException {
	  tc.addaction1();
	}

	@Then("the user enters another local action")
	public void the_user_enters_another_local_action() throws InterruptedException {
	  tc.action2();
	}

	@Then("the user clicks on the Save button to save the new action")
	public void the_user_clicks_on_the_save_button_to_save_the_new_action() throws InterruptedException {
	  tc.add2();
	  Thread.sleep(1000);
	}
	
	
	

	
	
	@Then("the user configures chart settings by clicking on Control Chart Preferences")
	public void the_user_configures_chart_settings_by_clicking_on_control_chart_preferences() throws InterruptedException {
	   tc.controlcahrt(); 
	   
	}

	@Then("the user accesses analysis options by clicking on the Analysis tab")
	public void the_user_accesses_analysis_options_by_clicking_on_the_analysis_tab() throws InterruptedException {
	    tc.Analisys();
	   
	}

	@Then("the user specifies run preferences by clicking on the Define Run dropdown")
	public void the_user_specifies_run_preferences_by_clicking_on_the_define_run_dropdown() throws InterruptedException {
	    tc.DefieRun();
	   
	}

	@Then("the user configures trend settings by selecting the Define Trend Down option")
	public void the_user_configures_trend_settings_by_selecting_the_define_trend_down_option() throws InterruptedException {
	    tc.DefineTrend();
	   
	}

	@Then("the user saves the chart preferences by clicking the save button")
	public void the_user_saves_the_chart_preferences_by_clicking_the_save_button() throws InterruptedException {
	    tc.saveDD();
	   
	}

	@Then("the user exits the configuration page by clicking the close button")
	public void the_user_exits_the_configuration_page_by_clicking_the_close_button() throws InterruptedException {
	   tc.closechar();
	}

		
//		hjnbhjjjjjjjjjjj


	@Then("the user accesses settings by clicking on the Configuration option")
	public void the_user_accesses_settings_by_clicking_on_the_configuration_option() {
	    tc.clickconfiguration01();
	   
	}

	@Then("the user adds a new parameter by clicking the Add Parameter link")
	public void the_user_adds_a_new_parameter_by_clicking_the_add_parameter_link() throws InterruptedException {
		Thread.sleep(1000);
	    tc.clickaddpara1();
	   
	}

	@Then("the user enters the parameter name in the designated input field")
	public void the_user_enters_the_parameter_name_in_the_designated_input_field() {
	    tc.sendparaname01();
	   
	}

	@Then("the user enables the Parameter Entry Restricted option by clicking the checkbox")
	public void the_user_enables_the_parameter_entry_restricted_option_by_clicking_the_checkbox() {
	    tc.EntryResticted();
	   
	}

	@Then("the user inputs the minimum value in the respective field")
	public void the_user_inputs_the_minimum_value_in_the_respective_field() {
	    tc.minvalue();
	   
	}

	@Then("the user inputs the maximum value in the respective field")
	public void the_user_inputs_the_maximum_value_in_the_respective_field() {
	    tc.Maxvalue();
	   
	}

	@Then("the user saves the automated function parameter by clicking the save button")
	public void the_user_saves_the_automated_function_parameter_by_clicking_the_save_button() {
	    tc.save01();
	   
	}

	@Then("the user exits the parameter configuration by clicking the close button")
	public void the_user_exits_the_parameter_configuration_by_clicking_the_close_button() {
	    tc.close01();
	   
	}

	@When("the user initiates the parameter creation process by clicking the Add Parameter link")
	public void the_user_initiates_the_parameter_creation_process_by_clicking_the_add_parameter_link() {
	    tc.clickaddpara2();
	   
	}

	@Then("the user enters the parameter name in the Parameter Name input field")
	public void the_user_enters_the_parameter_name_in_the_parameter_name_input_field() {
	    tc.sendparaname41();
	   
	}

	@Then("the user enables function automation by selecting the function radio button")
	public void the_user_enables_function_automation_by_selecting_the_function_radio_button() throws InterruptedException {
	    
	   tc.FunctionRadio();
	}

	@Then("the user proceeds with the parameter configuration by clicking the Go button")
	public void the_user_proceeds_with_the_parameter_configuration_by_clicking_the_go_button() throws InterruptedException {
	    tc.go();
	   
	}

	@Then("the user selects the LSL link under variables")
	public void the_user_selects_the_lsl_link_under_variables() throws InterruptedException {
	    tc.lsl();
	   
	}

	@Then("the user saves the function-automated parameter by clicking the save button")
	public void the_user_saves_the_function_automated_parameter_by_clicking_the_save_button() {
	    
	   tc.saveP();
	}

	@Then("the user finalizes and exits the parameter configuration by clicking the close button")
	public void the_user_finalizes_and_exits_the_parameter_configuration_by_clicking_the_close_button() {
	    tc.closeC();
	}

	
	/////assign para to part
	
	@Then("the user clicks on the Files icon to initiate adding a parameter to the part")
	public void the_user_clicks_on_the_files_icon_to_initiate_adding_a_parameter_to_the_part() throws InterruptedException {
		Thread.sleep(1000);
	   tc.filesicon();
	   
	}

	@Then("the user clicks on the Add icon to begin the parameter addition process")
	public void the_user_clicks_on_the_add_icon_to_begin_the_parameter_addition_process() throws InterruptedException {
		Thread.sleep(1000);
	   tc.Addptp();
	   
	}

	@Then("the user clicks on the Assign Parameter to Part link to verify the assignment")
	public void the_user_clicks_on_the_assign_parameter_to_part_link_to_verify_the_assignment() {
	   tc.Assignparaicon();
	   
	}

	@Then("the user clicks on the Group dropdown to view available groups")
	public void the_user_clicks_on_the_group_dropdown_to_view_available_groups() {
	   tc.datadropdown();
	   
	}

	@Then("the user selects the data group from the dropdown to specify the group")
	public void the_user_selects_the_data_group_from_the_dropdown_to_specify_the_group() {
	   tc.selectgrp();
	   
	}

	@Then("the user clicks on the Part dropdown to view available parts")
	public void the_user_clicks_on_the_part_dropdown_to_view_available_parts() {
	   tc.partdropdown();
	   
	}

	@Then("the user selects the part to which the parameter will be added")
	public void the_user_selects_the_part_to_which_the_parameter_will_be_added() {
	   tc.selectpartpara();
	   
	}



	@Then("the user drags and drops previously used parameters into the part")
	public void the_user_drags_and_drops_previously_used_parameters_into_the_part() {
	    tc.checkallbox1();
	}




	@Then("the user drags and drops the required parameter into the part")
	public void the_user_drags_and_drops_the_required_parameter_into_the_part() {
	   
	   tc.checkallbox();
	}

	@Then("the user clicks on the Save button to confirm adding the parameter to the part")
	public void the_user_clicks_on_the_save_button_to_confirm_adding_the_parameter_to_the_part() {
	   tc.saveassign();
	   
	}

	@Then("the user clicks on the Close button to exit the parameter addition process")
	public void the_user_clicks_on_the_close_button_to_exit_the_parameter_addition_process() throws InterruptedException {
		Thread.sleep(2000);
	   tc.closeassign();
	   
	}

	
	
	
	
	

	///adding sequence

	
	
	@Given("the user clicks on the Files button.")
	public void the_user_clicks_on_the_files_button() {
		  tc.addseqlink();
	}
	

	@When("the user expands the Files menu by clicking the expand button next to the Files icon.")
	public void the_user_expands_the_files_menu_by_clicking_the_expand_button_next_to_the_files_icon() {
		 tc.expand();
	}

	@Then("the user selects a group name from the grid by clicking on it for adding sequence")
	public void the_user_selects_a_group_name_from_the_grid_by_clicking_on_it_for_adding_sequence() {
	  tc.DDG1();
	}
	
	@Then("expands the options by clicking the arrow icon.")
	public void expands_the_options_by_clicking_the_arrow_icon() {
		 tc.DDd();
	}
	

	@Then("the user opens the sequence by clicking the Sequence link.")
	public void the_user_opens_the_sequence_by_clicking_the_sequence_link() {
	    tc.Sequenc();
	}

	@Then("accesses additional options by right-clicking on the sequence name.")
	public void accesses_additional_options_by_right_clicking_on_the_sequence_name() throws InterruptedException {
	   tc.Sequenc1();
	}
	@Then("the user selects Edit Sequence from the context menu.")
	public void the_user_selects_edit_sequence_from_the_context_menu() {
	   tc.editsequence();
	}
	@Then("rearranges the characteristics by dragging and dropping them.")
	public void rearranges_the_characteristics_by_dragging_and_dropping_them() {
	    tc.draganddrop();
	}


	@Then("the user saves the changes by clicking the Save button")
	public void the_user_saves_the_changes_by_clicking_the_save_button() {
	   tc.save();
	}

	@Then("completes the process by clicking the Close button.")
	public void completes_the_process_by_clicking_the_close_button() {
	   tc.close1();
	}

}

















