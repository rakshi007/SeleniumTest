package Hooks;

import java.io.File;
import java.time.Duration;
import java.util.Base64;
import java.util.Properties;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeOptions;

import DriverFactory.DriverFactory;
import io.cucumber.java.*;
import pages.LoginPage;
import util.ConfigReader;
import util.EmailSender;
import util.UIActions;


public class ApplicationHooks {

    private WebDriver driver;
    private Properties prop;
    UIActions actions;

    private static boolean anyScenarioFailed = false;

    // STEP 1: Load config properties
    @Before(order = 0)
    public void loadProperties() {
        ConfigReader configReader = new ConfigReader();
        prop = configReader.init_prop();

        if (prop == null) {
            throw new RuntimeException("Properties file could not be loaded.");
        }
    }

    // STEP 2: Launch browser
    @Before(order = 1)
    public void launchBrowser() {
        String browserName = prop.getProperty("browser");

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--disable-extensions", "--disable-gpu", "--no-sandbox", "--disable-dev-shm-usage", "--remote-allow-origins=*");

        DriverFactory.initDriver(browserName, options);
        driver = DriverFactory.getDriver();
        if (driver == null) {
            throw new RuntimeException("Browser could not be launched. Driver is null.");
        }

        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(60));
        driver.manage().timeouts().scriptTimeout(Duration.ofSeconds(30));

        this.actions = new UIActions(driver);


    }

    // STEP 3: Login as superuser and switch to Hub before test starts
    @Before(order = 2)
    public void loginAsSuperUserAndSwitchToHub(Scenario scenario) throws InterruptedException {
        if (scenario.getSourceTagNames().contains("@NoAutoLogin")) {
            return; // Skip login for NoAutoLogin scenarios
        }

        String username = prop.getProperty("username");  // superuser
        String password = prop.getProperty("password");
        String url = prop.getProperty("url");

        driver.get(url);
        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterusername(username);
        loginPage.enterpassword(password);
        loginPage.loginbtn();

        Thread.sleep(2000);

        // Handle popups
        if (loginPage.isElementPresent(By.xpath("//h5[text()='Session Timed Out']"))) {
            loginPage.continuebtn();
            Thread.sleep(1000);

            if (loginPage.isElementPresent(By.xpath("//div[contains(text(),'No Satellite Found')]"))) {
                loginPage.oksatellite();
                Thread.sleep(1000);
            }
        }

        // Switch to Hub
        loginPage.UserIcon();
        Thread.sleep(1000);
        loginPage.stw();
        Thread.sleep(1000);

        System.out.println("✅ Superuser login and switched to Hub complete.");
    }

    // STEP 4: Capture screenshot after each step
    @AfterStep
    public void takeScreenshotAfterStep(Scenario scenario) {
        driver = DriverFactory.getDriver();
        if (driver != null && scenario != null) {
            try {
                byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
                scenario.attach(screenshot, "image/png", "Step Screenshot");

                ExtentTest test = ExtentCucumberAdapter.getCurrentStep();
                if (test != null) {
                    test.addScreenCaptureFromBase64String(Base64.getEncoder().encodeToString(screenshot), "Screenshot");
                    test.info("Step screenshot captured.");
                }

            } catch (Exception e) {
                System.out.println("Screenshot capture failed: " + e.getMessage());
            }
        }
    }

    // STEP 5: Capture failure screenshot after scenario
    @After(order = 1)
    public void tearDown(Scenario scenario) {
        driver = DriverFactory.getDriver();

        if (driver != null && scenario != null && scenario.isFailed()) {
            anyScenarioFailed = true;

            try {
                byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
                scenario.attach(screenshot, "image/png", "Failure Screenshot");

                ExtentTest test = ExtentCucumberAdapter.getCurrentStep();
                if (test != null) {
                    test.fail("Scenario failed. Screenshot captured.");
                }
            } catch (Exception e) {
                System.out.println("Error capturing failure screenshot: " + e.getMessage());
            }
        }
    }

    // STEP 6: Email report after all tests
    @AfterAll
    public static void afterAllTests() {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException ignored) {}

        String reportPath = "test-output/SparkReport/ExtentHtml.html";
        EmailSender.sendTestReport(reportPath, anyScenarioFailed);
    }
}
