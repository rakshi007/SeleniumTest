package Hooks;

import DriverFactory.DriverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pages.LoginPage;
import util.ConfigReader;

public class LoginUtil {

    public static void loginAs(String username, String password, boolean switchToHubAdmin) {
        WebDriver driver = DriverFactory.getDriver();
        LoginPage loginPage = new LoginPage(driver);

        ConfigReader configReader = new ConfigReader();
        driver.get(configReader.getAppUrl());


        try {
            Thread.sleep(2000);
            loginPage.enterusername(username);
            Thread.sleep(1000);
            loginPage.enterpassword(password);
            Thread.sleep(1000);
            loginPage.loginbtn();
            Thread.sleep(2000);

            // Handle session timeout
            if (loginPage.isElementPresent(By.xpath("//h5[text()='Session Timed Out']"))) {
                loginPage.continuebtn();
                Thread.sleep(1000);

                if (loginPage.isElementPresent(By.xpath("//div[contains(text(),'No Satellite Found')]"))) {
                    loginPage.oksatellite();
                    Thread.sleep(1000);
                }

                if (switchToHubAdmin) {
                    loginPage.UserIcon();
                    Thread.sleep(1000);
                    loginPage.stw(); // switch to hub admin
                    Thread.sleep(1000);
                }
            }

        } catch (InterruptedException e) {
            throw new RuntimeException("Login interrupted: " + e.getMessage());
        }
    }
}
